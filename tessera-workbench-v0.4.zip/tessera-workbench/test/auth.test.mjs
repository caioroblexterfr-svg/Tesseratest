import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createPkce, createAuth, parseCookies } from '../apps/bff/src/auth.mjs';

function fakeRes() {
  return {
    status: 0, headers: {}, body: '',
    writeHead(s, h = {}) { this.status = s; this.headers = h; },
    setHeader() {}, end(b = '') { this.body = b; },
  };
}

test('PKCE: challenge = BASE64URL(SHA256(verifier))', () => {
  const { verifier, challenge } = createPkce();
  assert.equal(challenge, createHash('sha256').update(verifier).digest('base64url'));
  assert.ok(verifier.length >= 43);
});

test('sem configuração, /auth/login devolve 503', async () => {
  const auth = createAuth({});
  const res = fakeRes();
  await auth.handle({ method: 'GET', headers: {} }, res, new URL('http://x/auth/login'));
  assert.equal(res.status, 503);
});

test('login redireciona com PKCE S256, state e cookie HttpOnly', async () => {
  const auth = createAuth({
    authorizeUrl: 'https://idp.example/authorize', tokenUrl: 'https://idp.example/token',
    clientId: 'cid', redirectUri: 'http://localhost/auth/callback',
  });
  const res = fakeRes();
  await auth.handle({ method: 'GET', headers: {} }, res, new URL('http://x/auth/login'));
  assert.equal(res.status, 303);
  const loc = new URL(res.headers.Location);
  assert.equal(loc.searchParams.get('response_type'), 'code');
  assert.equal(loc.searchParams.get('code_challenge_method'), 'S256');
  assert.ok(loc.searchParams.get('code_challenge'));
  assert.ok(loc.searchParams.get('state'));
  assert.match(res.headers['Set-Cookie'], /HttpOnly/);
  assert.match(res.headers['Set-Cookie'], /Secure/);
});

test('callback rejeita state sem cookie correspondente (CSRF de login)', async () => {
  const auth = createAuth({
    authorizeUrl: 'https://idp.example/authorize', tokenUrl: 'https://idp.example/token',
    clientId: 'cid', redirectUri: 'http://localhost/auth/callback',
  });
  const r1 = fakeRes();
  await auth.handle({ method: 'GET', headers: {} }, r1, new URL('http://x/auth/login'));
  const state = new URL(r1.headers.Location).searchParams.get('state');
  const r2 = fakeRes();
  await auth.handle({ method: 'GET', headers: {} }, r2, new URL(`http://x/auth/callback?code=abc&state=${state}`));
  assert.equal(r2.status, 400);
});

test('/auth/session nunca expõe tokens', async () => {
  const auth = createAuth({});
  const res = fakeRes();
  await auth.handle({ method: 'GET', headers: {} }, res, new URL('http://x/auth/session'));
  assert.deepEqual(JSON.parse(res.body), { authenticated: false });
});

test('logout exige POST do mesmo site', async () => {
  const auth = createAuth({});
  const res = fakeRes();
  await auth.handle({ method: 'POST', headers: { 'sec-fetch-site': 'cross-site' } }, res, new URL('http://x/auth/logout'));
  assert.equal(res.status, 403);
});

test('parseCookies', () => {
  assert.deepEqual(parseCookies('a=1; b=x%20y'), { a: '1', b: 'x y' });
});
