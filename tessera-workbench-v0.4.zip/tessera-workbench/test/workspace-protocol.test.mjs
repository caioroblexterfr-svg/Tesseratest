import test from 'node:test';
import assert from 'node:assert/strict';
import { createWorkspaceHandler, WORKSPACE_STORE_ID } from '../apps/pwa/public/workspace/assets/workspace-protocol.js';
import { createMemoryStore } from '../apps/pwa/public/workspace/assets/persistence.js';

const mkHandler = (store = createMemoryStore(), replicaId = 'aaaa') => createWorkspaceHandler({ store, replicaId });
let seq = 0;
const req = (h, op, args = {}) => h.handle({ id: ++seq, op, ...args });
const ok = async (h, op, args) => {
  const r = await req(h, op, args);
  assert.equal(r.ok, true, `${op}: ${r.error}`);
  return r.result;
};

test('fluxo completo: criar, listar, caminhos, mover, renomear, apagar', async () => {
  const h = mkHandler();
  const { id: src } = await ok(h, 'ws.create', { name: 'src', kind: 'dir' });
  const { id: main } = await ok(h, 'ws.create', { parentId: src, name: 'main.rs' });
  assert.deepEqual(await ok(h, 'ws.children', {}), [{ id: src, name: 'src', kind: 'dir' }]);
  assert.equal(await ok(h, 'ws.path', { nodeId: main }), '/src/main.rs');
  assert.equal(await ok(h, 'ws.resolve', { path: '/src/main.rs' }), main);
  assert.equal(await ok(h, 'ws.resolve', { path: '/' }), 'root');
  assert.deepEqual(await ok(h, 'ws.rename', { nodeId: main, name: 'lib.rs' }), { renamed: true });
  assert.deepEqual(await ok(h, 'ws.rename', { nodeId: main, name: 'lib.rs' }), { renamed: false });
  assert.deepEqual(await ok(h, 'ws.move', { nodeId: main, parentId: 'root' }), { moved: true });
  assert.equal(await ok(h, 'ws.path', { nodeId: main }), '/lib.rs');
  assert.deepEqual(await ok(h, 'ws.remove', { nodeId: main }), { removed: true });
  assert.equal(await ok(h, 'ws.path', { nodeId: main }), '/.trash/lib.rs');
  assert.equal((await ok(h, 'ws.get', { nodeId: main })).inTrash, true);
  assert.equal(await ok(h, 'ws.get', { nodeId: 'zzzz-1' }), null);
  assert.equal(await ok(h, 'ws.path', { nodeId: 'zzzz-1' }), null);
});

test('o id do pedido volta intacto (os nós usam nodeId, não colidem com o envelope)', async () => {
  const h = mkHandler();
  const { id: node } = await ok(h, 'ws.create', { name: 'a' });
  const r = await h.handle({ id: 777, op: 'ws.path', nodeId: node });
  assert.deepEqual(r, { id: 777, ok: true, result: '/a' });
  assert.deepEqual(await h.handle({ id: 778, op: 'ws.children' }), { id: 778, ok: true, result: [{ id: node, name: 'a', kind: 'file' }] });
});

test('erros de validação chegam como { ok: false, error } e não alteram o estado', async () => {
  const h = mkHandler();
  const { id: a } = await ok(h, 'ws.create', { name: 'a', kind: 'dir' });
  const { id: b } = await ok(h, 'ws.create', { parentId: a, name: 'b', kind: 'dir' });
  const bad = [
    ['ws.create', { name: '../x' }, /nome/],
    ['ws.create', { name: 'a' }, /já existe/],
    ['ws.create', { name: 'x', kind: 'link' }, /tipo/],
    ['ws.create', { parentId: 'zzzz-9', name: 'x' }, /desconhecida/],
    ['ws.move', { nodeId: a, parentId: b }, /ciclo/],
    ['ws.move', { nodeId: a }, /destino|desconhecida/],
    ['ws.move', { nodeId: 'zzzz-9', parentId: 'root' }, /desconhecido/],
    ['ws.rename', { nodeId: a, name: 5 }, /string/],
    ['ws.remove', { nodeId: 'root' }, /desconhecido/],
    ['ws.import', { ops: 'x' }, /inválidas/],
    ['ws.nope', {}, /desconhecida/],
    ['ws.__proto__', {}, /desconhecida/],
    ['__proto__', {}, /desconhecida/],
  ];
  for (const [op, args, re] of bad) {
    const r = await req(h, op, args);
    assert.equal(r.ok, false, op);
    assert.match(r.error, re, op);
  }
  assert.equal((await h.handle(null)).ok, false);
  assert.equal(await ok(h, 'ws.path', { nodeId: b }), '/a/b');
});

test('persistência: flush grava o registo e uma nova sessão (outra réplica) recupera tudo', async () => {
  const store = createMemoryStore();
  const h1 = mkHandler(store, 'aaaa');
  assert.deepEqual(await ok(h1, 'ws.flush'), { saved: false }); // nada para gravar
  const { id: d } = await ok(h1, 'ws.create', { name: 'd', kind: 'dir' });
  const { id: f } = await ok(h1, 'ws.create', { parentId: d, name: 'f.txt' });
  assert.equal(h1.isDirty(), true);
  assert.deepEqual(await ok(h1, 'ws.flush'), { saved: true });
  assert.equal(h1.isDirty(), false);
  assert.deepEqual(await ok(h1, 'ws.flush'), { saved: false });
  const stored = JSON.parse(await store.load(WORKSPACE_STORE_ID));
  assert.equal(stored.v, 1);
  assert.equal(stored.ops.length, 2);

  const h2 = mkHandler(store, 'bbbb');
  assert.equal(await ok(h2, 'ws.path', { nodeId: f }), '/d/f.txt');
  const { id: g } = await ok(h2, 'ws.create', { parentId: d, name: 'g.txt' });
  assert.ok(Number(g.split('-')[1]) > 2, 'o relógio continua acima do que foi carregado');
  await ok(h2, 'ws.flush');
  const h3 = mkHandler(store, 'cccc');
  assert.deepEqual((await ok(h3, 'ws.children', { nodeId: d })).map((c) => c.name), ['f.txt', 'g.txt']);
});

test('registo corrompido: as operações falham (nada é descartado) e há nova tentativa depois de reparar', async () => {
  const store = createMemoryStore();
  const h = mkHandler(store);
  const goodOps = mkHandler();
  await ok(goodOps, 'ws.create', { name: 'x' });
  const valid = (await ok(goodOps, 'ws.export')).ops;

  for (const [text, re] of [
    ['{nao json', /ilegível/],
    [JSON.stringify({ v: 2, ops: [] }), /formato/],
    [JSON.stringify({ v: 1, ops: 'x' }), /formato/],
    [JSON.stringify({ v: 1, ops: [...valid, { r: 'x' }] }), /corrompido \(1/],
  ]) {
    await store.save(WORKSPACE_STORE_ID, text);
    const r = await req(h, 'ws.children', {});
    assert.equal(r.ok, false);
    assert.match(r.error, re);
  }
  await store.save(WORKSPACE_STORE_ID, JSON.stringify({ v: 1, ops: valid }));
  assert.deepEqual((await ok(h, 'ws.children', {})).map((c) => c.name), ['x']);
});

test('primeiras chamadas simultâneas partilham um só carregamento', async () => {
  const inner = createMemoryStore();
  let loads = 0;
  const store = { ...inner, load: async (id) => { loads++; await new Promise((r) => setTimeout(r, 5)); return inner.load(id); } };
  const h = mkHandler(store);
  const rs = await Promise.all([1, 2, 3, 4, 5].map((i) => req(h, 'ws.create', { name: `f${i}` })));
  assert.ok(rs.every((r) => r.ok));
  assert.equal(loads, 1);
  assert.equal((await ok(h, 'ws.children', {})).length, 5);
});

test('falha ao gravar mantém o estado «sujo» para nova tentativa', async () => {
  const inner = createMemoryStore();
  let fail = true;
  const store = { ...inner, save: async (id, t) => { if (fail) throw new Error('disco cheio'); return inner.save(id, t); } };
  const h = mkHandler(store);
  await ok(h, 'ws.create', { name: 'a' });
  const r = await req(h, 'ws.flush');
  assert.deepEqual([r.ok, r.error], [false, 'disco cheio']);
  assert.equal(h.isDirty(), true);
  fail = false;
  assert.deepEqual(await ok(h, 'ws.flush'), { saved: true });
  assert.equal(h.isDirty(), false);
});

test('sincronizar duas sessões por export/import; recusas são contadas', async () => {
  const a = mkHandler(createMemoryStore(), 'aaaa');
  const b = mkHandler(createMemoryStore(), 'bbbb');
  const { id: d } = await ok(a, 'ws.create', { name: 'd', kind: 'dir' });
  await ok(a, 'ws.create', { parentId: d, name: 'f' });
  const { ops } = await ok(a, 'ws.export');
  const r = await ok(b, 'ws.import', { ops: [...ops, { nope: 1 }, { ...ops[0], c: 9, node: 'aaaa-9', name: '..' }] });
  assert.equal(r.applied, 2);
  assert.equal(r.rejectedCount, 2);
  assert.equal(r.rejected.length, 2);
  assert.deepEqual(await ok(b, 'ws.import', { ops }), { applied: 0, duplicates: 2, rejectedCount: 0, rejected: [] });
  assert.equal(await ok(b, 'ws.path', { nodeId: d }), '/d');
  assert.equal(b.isDirty(), true);
});

test('o protocolo de documentos reserva o prefixo __ (o registo do espaço de trabalho não colide)', async () => {
  const { createCoreHandler } = await import('../apps/pwa/public/workspace/assets/protocol.js');
  const { FakeRope } = await import('../test-support/fake-rope.mjs');
  const core = createCoreHandler({ createRope: (t) => new FakeRope(t), store: createMemoryStore() });
  for (const docId of ['__workspace__', '__x', '__']) assert.equal((await core.handle({ id: 1, op: 'open', docId })).ok, false, docId);
  assert.equal((await core.handle({ id: 1, op: 'open', docId: 'a__b', text: '' })).ok, true);
});
