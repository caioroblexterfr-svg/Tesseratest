import test from 'node:test';
import assert from 'node:assert/strict';
import {
  snapBoundary, prevBoundary, nextBoundary, backspaceBoundary,
  wordLeft, wordRight, wordRangeAt, __fallback,
} from '../apps/pwa/public/workspace/assets/text-boundaries.js';

const FAMILY = '👨\u200d👩\u200d👧'; // 8 unidades UTF-16, 1 cluster
const FLAG = '🇵🇹'; // 4 unidades, 1 cluster
const KEYCAP = '1\ufe0f\u20e3'; // 3 unidades, 1 cluster

test('ASCII e pares substitutos simples', () => {
  assert.equal(nextBoundary('abc', 0), 1);
  assert.equal(prevBoundary('abc', 3), 2);
  assert.equal(nextBoundary('a😀b', 1), 3);
  assert.equal(prevBoundary('a😀b', 3), 1);
  assert.equal(snapBoundary('a😀b', 2), 1);
  assert.equal(snapBoundary('abc', 99), 3);
  assert.equal(prevBoundary('abc', 0), 0);
  assert.equal(nextBoundary('abc', 3), 3);
});

test('clusters: acento combinado, ZWJ, bandeira, caixa de tecla', () => {
  assert.equal(nextBoundary('e\u0301x', 0), 2);
  assert.equal(prevBoundary('e\u0301x', 2), 0);
  assert.equal(snapBoundary('e\u0301x', 1), 0);
  assert.equal(nextBoundary(`${FAMILY}x`, 0), 8);
  assert.equal(prevBoundary(`${FAMILY}x`, 8), 0);
  assert.equal(snapBoundary(`${FAMILY}x`, 5), 0);
  assert.equal(nextBoundary(`${FLAG}x`, 0), 4);
  assert.equal(nextBoundary(`${KEYCAP}x`, 0), 3);
});

test('Backspace: emoji compostos por inteiro; acento só o combinador; par substituto inteiro', () => {
  assert.equal(backspaceBoundary(`a${FAMILY}`, 9), 1);
  assert.equal(backspaceBoundary(`a${FLAG}`, 5), 1);
  assert.equal(backspaceBoundary(`a${KEYCAP}`, 4), 1);
  assert.equal(backspaceBoundary('ae\u0301', 3), 2); // deixa o "e"
  assert.equal(backspaceBoundary('a😀', 3), 1);
  assert.equal(backspaceBoundary('abc', 3), 2);
  assert.equal(backspaceBoundary('abc', 0), 0);
});

// Referência: segmentação da string inteira.
function reference(s) {
  const b = [...new Intl.Segmenter(undefined, { granularity: 'grapheme' }).segment(s)].map((x) => x.index);
  b.push(s.length);
  return b;
}
function mulberry32(a) {
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

test('propriedade: caminho rápido/janela coincide com a segmentação da string inteira', () => {
  const pieces = ['a', 'b', ' ', 'é', 'e\u0301', '😀', '👍🏽', FLAG, FAMILY, KEYCAP, '日', '\u200d', '\u0301', 'x'];
  const rnd = mulberry32(42);
  for (let n = 0; n < 300; n++) {
    let s = '';
    for (let i = 0, k = Math.floor(rnd() * 12); i < k; i++) s += pieces[Math.floor(rnd() * pieces.length)];
    const b = reference(s);
    for (let col = 0; col <= s.length; col++) {
      const isB = b.includes(col);
      const snap = Math.max(...b.filter((x) => x <= col));
      assert.equal(snapBoundary(s, col), snap, `snap ${JSON.stringify(s)}@${col}`);
      if (!isB) continue; // prev/next assumem uma fronteira de partida
      const prev = Math.max(0, ...b.filter((x) => x < col));
      const next = Math.min(s.length, ...b.filter((x) => x > col));
      assert.equal(prevBoundary(s, col), prev, `prev ${JSON.stringify(s)}@${col}`);
      assert.equal(nextBoundary(s, col), next, `next ${JSON.stringify(s)}@${col}`);
    }
  }
});

test('linha muito longa: a janela não parte clusters a meio da linha', () => {
  const s = 'a'.repeat(1000) + FAMILY + 'b'.repeat(1000);
  assert.equal(nextBoundary(s, 1000), 1008);
  assert.equal(prevBoundary(s, 1008), 1000);
  assert.equal(snapBoundary(s, 1004), 1000);
  assert.equal(nextBoundary(s, 5), 6);
});

test('palavras: wordLeft / wordRight', () => {
  assert.equal(wordLeft('foo bar', 7), 4);
  assert.equal(wordLeft('foo bar', 4), 0);
  assert.equal(wordLeft('foo bar', 0), 0);
  assert.equal(wordLeft('foo bar', 5), 4);
  assert.equal(wordLeft('a, b', 4), 3);
  assert.equal(wordLeft('a, b', 3), 0);
  assert.equal(wordRight('foo bar', 0), 3);
  assert.equal(wordRight('foo bar', 3), 7);
  assert.equal(wordRight('foo bar', 7), 7);
  assert.equal(wordRight('a, b', 1), 4);
  assert.equal(wordRight('', 0), 0);
  assert.equal(wordLeft('olá mundo', 9), 4);
  assert.equal(wordRight('foo_bar baz', 0), 7); // "_" liga palavras
  assert.equal(wordLeft('  x', 3), 2);
});

test('wordRangeAt: palavra, fim de palavra, espaços, linha vazia, fim da linha', () => {
  assert.deepEqual(wordRangeAt('foo bar', 1), { start: 0, end: 3 });
  assert.deepEqual(wordRangeAt('foo bar', 3), { start: 0, end: 3 }); // logo após a palavra
  assert.deepEqual(wordRangeAt('foo bar', 4), { start: 4, end: 7 });
  assert.deepEqual(wordRangeAt('foo bar', 7), { start: 4, end: 7 });
  assert.deepEqual(wordRangeAt('foo  bar', 4), { start: 3, end: 5 });
  assert.deepEqual(wordRangeAt('', 0), { start: 0, end: 0 });
  assert.deepEqual(wordRangeAt('a😀b', 1), { start: 0, end: 1 }); // logo após "a"
  assert.deepEqual(wordRangeAt('a😀b', 3), { start: 3, end: 4 });
});

test('alternativa sem Intl.Segmenter: pontos de código e palavras simples', () => {
  assert.deepEqual([...__fallback.graphemes('a😀b')].map((s) => s.index), [0, 1, 3]);
  const w = [...__fallback.words('foo, bar_1  é')];
  assert.deepEqual(w.map((s) => [s.index, s.segment, s.isWordLike]), [
    [0, 'foo', true], [3, ',', false], [4, ' ', false], [5, 'bar_1', true], [10, '  ', false], [12, 'é', true],
  ]);
});
