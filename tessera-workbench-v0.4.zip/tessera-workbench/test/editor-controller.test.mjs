import test from 'node:test';
import assert from 'node:assert/strict';
import { createCoreHandler } from '../apps/pwa/public/workspace/assets/protocol.js';
import { createMemoryStore } from '../apps/pwa/public/workspace/assets/persistence.js';
import { createEditorController } from '../apps/pwa/public/workspace/assets/editor-controller.js';
import { FakeRope } from '../test-support/fake-rope.mjs';

async function setup(text = '') {
  const h = createCoreHandler({ createRope: (t) => new FakeRope(t), store: createMemoryStore() });
  const call = async (op, args = {}) => {
    const r = await h.handle({ id: 1, op, ...args });
    if (!r.ok) throw new Error(r.error);
    return r.result;
  };
  await call('open', { docId: 'd', text });
  const c = createEditorController({ call, docId: 'd' });
  await c.init();
  const doc = async () => (await call('lines', { docId: 'd', startRow: 0, endRow: 1e6 })).join('\n');
  const caret = () => c.getSelection().head;
  return { c, doc, caret, call };
}

test('inserir texto e quebra de linha atualiza o caret', async () => {
  const { c, doc, caret } = await setup();
  await c.insertText('olá');
  assert.deepEqual(caret(), { row: 0, col: 3 });
  await c.insertText('\nmundo');
  assert.equal(await doc(), 'olá\nmundo');
  assert.deepEqual(caret(), { row: 1, col: 5 });
  await c.insertLineBreak();
  assert.deepEqual(caret(), { row: 2, col: 0 });
});

test('colar várias linhas normaliza \\r\\n e posiciona o caret', async () => {
  const { c, doc, caret } = await setup('a');
  await c.insertText('x\r\ny\nz');
  assert.equal(await doc(), 'x\ny\nza');
  assert.deepEqual(caret(), { row: 2, col: 1 });
});

test('Backspace apaga um emoji inteiro (par substituto)', async () => {
  const { c, doc, caret } = await setup('a😀');
  await c.setCaret(0, 3);
  await c.deleteBackward();
  assert.equal(await doc(), 'a');
  assert.deepEqual(caret(), { row: 0, col: 1 });
});

test('Backspace no início da linha junta com a anterior; no início do documento não faz nada', async () => {
  const { c, doc, caret } = await setup('ab\ncd');
  await c.setCaret(1, 0);
  await c.deleteBackward();
  assert.equal(await doc(), 'abcd');
  assert.deepEqual(caret(), { row: 0, col: 2 });
  await c.setCaret(0, 0);
  await c.deleteBackward();
  assert.equal(await doc(), 'abcd');
});

test('Delete: junta no fim da linha, apaga emoji inteiro, nada no fim do documento', async () => {
  const a = await setup('ab\ncd');
  await a.c.setCaret(0, 2);
  await a.c.deleteForward();
  assert.equal(await a.doc(), 'abcd');

  const b = await setup('a😀b');
  await b.c.setCaret(0, 1);
  await b.c.deleteForward();
  assert.equal(await b.doc(), 'ab');

  await b.c.setCaret(0, 2);
  await b.c.deleteForward();
  assert.equal(await b.doc(), 'ab');
});

test('selecionar e escrever substitui a seleção', async () => {
  const { c, doc, caret } = await setup('hello world');
  await c.setCaret(0, 0);
  await c.setCaret(0, 5, true);
  await c.insertText('HI');
  assert.equal(await doc(), 'HI world');
  assert.deepEqual(caret(), { row: 0, col: 2 });
});

test('seleção invertida (cabeça antes da âncora) também funciona', async () => {
  const { c, doc } = await setup('abcdef');
  await c.setCaret(0, 4);
  await c.setCaret(0, 1, true);
  await c.deleteBackward();
  assert.equal(await doc(), 'aef');
});

test('shift+setas estende; Backspace apaga a seleção', async () => {
  const { c, doc, caret } = await setup('abcdef');
  await c.setCaret(0, 1);
  for (let i = 0; i < 3; i++) await c.move('right', true);
  await c.deleteBackward();
  assert.equal(await doc(), 'aef');
  assert.deepEqual(caret(), { row: 0, col: 1 });
});

test('setas esquerda/direita colapsam a seleção para o respetivo extremo', async () => {
  const { c, caret } = await setup('abcdefgh');
  await c.setCaret(0, 2);
  await c.setCaret(0, 5, true);
  await c.move('left');
  assert.deepEqual(caret(), { row: 0, col: 2 });
  await c.setCaret(0, 5, true);
  await c.move('right');
  assert.deepEqual(caret(), { row: 0, col: 5 });
});

test('esquerda/direita saltam pares substitutos e mudam de linha', async () => {
  const { c, caret } = await setup('a😀\nb');
  await c.setCaret(0, 3);
  await c.move('left');
  assert.equal(caret().col, 1);
  await c.move('left');
  await c.move('left'); // no início do documento: fica
  assert.deepEqual(caret(), { row: 0, col: 0 });
  await c.move('right');
  await c.move('right');
  assert.deepEqual(caret(), { row: 0, col: 3 });
  await c.move('right'); // fim da linha → início da seguinte
  assert.deepEqual(caret(), { row: 1, col: 0 });
});

test('cima/baixo mantêm a coluna preferida; extremos vão para início/fim', async () => {
  const { c, caret } = await setup('abcdef\nab\nabcdef');
  await c.setCaret(0, 5);
  await c.move('down');
  assert.deepEqual(caret(), { row: 1, col: 2 });
  await c.move('down');
  assert.deepEqual(caret(), { row: 2, col: 5 });
  await c.move('down'); // última linha → fim
  assert.deepEqual(caret(), { row: 2, col: 6 });
  await c.setCaret(0, 3);
  await c.move('up'); // primeira linha → início
  assert.deepEqual(caret(), { row: 0, col: 0 });
});

test('movimento vertical nunca aterra a meio de um emoji', async () => {
  const { c, caret } = await setup('abcd\na😀b');
  await c.setCaret(0, 2);
  await c.move('down'); // coluna 2 está a meio do emoji → recua para 1
  assert.deepEqual(caret(), { row: 1, col: 1 });
});

test('Home/End', async () => {
  const { c, caret } = await setup('olá mundo');
  await c.setCaret(0, 4);
  await c.move('end');
  assert.equal(caret().col, 9);
  await c.move('home');
  assert.equal(caret().col, 0);
});

test('selectAll + inserir substitui o documento todo', async () => {
  const { c, doc, call } = await setup('um\ndois\ntrês');
  await c.selectAll();
  await c.insertText('novo');
  assert.equal(await doc(), 'novo');
  assert.equal((await call('open', { docId: 'd' })).lines, 1);
  assert.equal(c.lineCount(), 1);
});

test('operações concorrentes são serializadas pela ordem de chamada', async () => {
  const { c, doc } = await setup();
  await Promise.all([c.insertText('a'), c.insertText('b'), c.insertText('c'), c.deleteBackward(), c.insertText('d')]);
  assert.equal(await doc(), 'abd');
});

test('setCaret limita linha e coluna e não parte pares substitutos', async () => {
  const { c, caret } = await setup('a😀b');
  await c.setCaret(99, 99);
  assert.deepEqual(caret(), { row: 0, col: 4 });
  await c.setCaret(0, 2);
  assert.equal(caret().col, 1);
});

test('direção inválida é rejeitada e não rebenta a fila', async () => {
  const { c, doc } = await setup();
  await assert.rejects(c.move('diagonal'), TypeError);
  await c.insertText('ok');
  assert.equal(await doc(), 'ok');
});

// ---------- histórico (undo/redo) e texto da seleção ----------

test('undo/redo: escrita contínua agrupa-se numa só entrada', async () => {
  const { c, doc, caret } = await setup();
  for (const ch of 'olá') await c.insertText(ch);
  assert.equal(await doc(), 'olá');
  assert.equal(await c.undo(), true);
  assert.equal(await doc(), '');
  assert.deepEqual(caret(), { row: 0, col: 0 });
  assert.equal(await c.undo(), false);
  assert.equal(await c.redo(), true);
  assert.equal(await doc(), 'olá');
  assert.deepEqual(caret(), { row: 0, col: 3 });
  assert.equal(await c.redo(), false);
});

test('mover o caret interrompe o agrupamento', async () => {
  const { c, doc } = await setup();
  await c.insertText('a');
  await c.insertText('b');
  await c.move('left');
  await c.move('right');
  await c.insertText('c');
  await c.undo();
  assert.equal(await doc(), 'ab');
  await c.undo();
  assert.equal(await doc(), '');
});

test('undo repõe o texto apagado (Backspace repetido agrupa) e a seleção anterior', async () => {
  const { c, doc, caret } = await setup('abcdef');
  await c.setCaret(0, 4);
  await c.deleteBackward();
  await c.deleteBackward();
  assert.equal(await doc(), 'abef');
  await c.undo();
  assert.equal(await doc(), 'abcdef');
  assert.deepEqual(caret(), { row: 0, col: 4 });
});

test('Delete repetido agrupa-se e o undo repõe tudo', async () => {
  const { c, doc, caret } = await setup('abcdef');
  await c.setCaret(0, 1);
  await c.deleteForward();
  await c.deleteForward();
  assert.equal(await doc(), 'adef');
  await c.undo();
  assert.equal(await doc(), 'abcdef');
  assert.deepEqual(caret(), { row: 0, col: 1 });
});

test('undo de substituição de seleção multi-linha repõe texto e seleção', async () => {
  const { c, doc, caret } = await setup('um\ndois\ntrês');
  await c.setCaret(0, 1);
  await c.setCaret(2, 2, true);
  await c.insertText('X');
  assert.equal(await doc(), 'uXês');
  await c.undo();
  assert.equal(await doc(), 'um\ndois\ntrês');
  assert.deepEqual(c.getSelection(), { anchor: { row: 0, col: 1 }, head: { row: 2, col: 2 } });
  await c.redo();
  assert.equal(await doc(), 'uXês');
  assert.deepEqual(caret(), { row: 0, col: 2 });
});

test('undo de colar várias linhas e de emoji', async () => {
  const { c, doc } = await setup('a😀b');
  await c.setCaret(0, 3);
  await c.insertText('x\ny');
  assert.equal(await doc(), 'a😀x\nyb');
  await c.undo();
  assert.equal(await doc(), 'a😀b');
  await c.setCaret(0, 3);
  await c.deleteBackward(); // apaga o emoji inteiro
  await c.undo();
  assert.equal(await doc(), 'a😀b');
});

test('uma edição nova limpa o redo', async () => {
  const { c, doc } = await setup();
  await c.insertText('a');
  await c.undo();
  assert.equal(c.canRedo(), true);
  await c.insertText('b');
  assert.equal(c.canRedo(), false);
  assert.equal(await c.redo(), false);
  assert.equal(await doc(), 'b');
});

test('getSelectedText: uma linha, várias linhas, invertida e vazia', async () => {
  const { c } = await setup('um\ndois\ntrês');
  assert.equal(await c.getSelectedText(), '');
  await c.setCaret(0, 1);
  await c.setCaret(0, 2, true);
  assert.equal(await c.getSelectedText(), 'm');
  await c.setCaret(2, 2);
  await c.setCaret(0, 1, true);
  assert.equal(await c.getSelectedText(), 'm\ndois\ntr');
  await c.selectAll();
  assert.equal(await c.getSelectedText(), 'um\ndois\ntrês');
});

test('cut devolve o texto, apaga-o e é desfazível', async () => {
  const { c, doc } = await setup('hello world');
  await c.setCaret(0, 0);
  await c.setCaret(0, 5, true);
  assert.equal(await c.cut(), 'hello');
  assert.equal(await doc(), ' world');
  assert.equal(await c.cut(), ''); // sem seleção: não faz nada
  await c.undo();
  assert.equal(await doc(), 'hello world');
});

test('undo/redo seguem a ordem das operações serializadas', async () => {
  const { c, doc } = await setup();
  await Promise.all([c.insertText('a'), c.insertText('b'), c.undo(), c.insertText('z')]);
  assert.equal(await doc(), 'z');
});

// ---------- grapheme clusters, palavras, duplo/triplo clique ----------

const FAMILY = '👨\u200d👩\u200d👧';

test('setas e Delete tratam acentos combinados e emoji compostos como uma unidade', async () => {
  const { c, doc, caret } = await setup(`e\u0301${FAMILY}x`);
  await c.move('right');
  assert.equal(caret().col, 2);
  await c.move('right');
  assert.equal(caret().col, 10);
  await c.move('left');
  assert.equal(caret().col, 2);
  await c.setCaret(0, 0);
  await c.deleteForward(); // apaga "é" decomposto inteiro
  assert.equal(await doc(), `${FAMILY}x`);
  await c.deleteForward(); // e a família inteira
  assert.equal(await doc(), 'x');
});

test('Backspace: família por inteiro (undo repõe); acento apaga só o combinador', async () => {
  const a = await setup(`a${FAMILY}`);
  await a.c.setCaret(0, 9);
  await a.c.deleteBackward();
  assert.equal(await a.doc(), 'a');
  await a.c.undo();
  assert.equal(await a.doc(), `a${FAMILY}`);

  const b = await setup('ae\u0301');
  await b.c.setCaret(0, 3);
  await b.c.deleteBackward();
  assert.equal(await b.doc(), 'ae');
});

test('setCaret e movimento vertical não aterram a meio de um cluster', async () => {
  const { c, caret } = await setup(`abcdef\nx${FAMILY}y`);
  await c.setCaret(1, 4);
  assert.equal(caret().col, 1);
  await c.setCaret(0, 4);
  await c.move('down'); // coluna 4 cai dentro da família → recua para o início
  assert.deepEqual(caret(), { row: 1, col: 1 });
});

test('Ctrl+setas: movimento por palavra, com extensão e através de linhas', async () => {
  const { c, caret } = await setup('foo bar\nbaz');
  await c.move('wordRight');
  assert.equal(caret().col, 3);
  await c.move('wordRight');
  assert.equal(caret().col, 7);
  await c.move('wordRight'); // fim da linha → início da seguinte
  assert.deepEqual(caret(), { row: 1, col: 0 });
  await c.move('wordLeft'); // início da linha → fim da anterior
  assert.deepEqual(caret(), { row: 0, col: 7 });
  await c.move('wordLeft');
  assert.equal(caret().col, 4);
  await c.move('wordLeft', true);
  assert.deepEqual(c.getSelection(), { anchor: { row: 0, col: 4 }, head: { row: 0, col: 0 } });
});

test('docStart / docEnd', async () => {
  const { c, caret } = await setup('um\ndois\ntrês');
  await c.move('docEnd');
  assert.deepEqual(caret(), { row: 2, col: 4 });
  await c.move('docStart', true);
  assert.deepEqual(c.getSelection(), { anchor: { row: 2, col: 4 }, head: { row: 0, col: 0 } });
});

test('Ctrl+Backspace / Ctrl+Delete apagam por palavra e juntam linhas nas pontas', async () => {
  const { c, doc, caret } = await setup('foo bar baz\nqux');
  await c.setCaret(0, 11);
  await c.deleteWordBackward();
  assert.equal(await doc(), 'foo bar \nqux');
  assert.equal(caret().col, 8);
  await c.deleteWordBackward();
  assert.equal(await doc(), 'foo \nqux');
  await c.setCaret(0, 0);
  await c.deleteWordForward();
  assert.equal(await doc(), ' \nqux');
  await c.setCaret(0, 1);
  await c.deleteWordForward(); // fim da linha → junta
  assert.equal(await doc(), ' qux');
  await c.setCaret(0, 0);
  await c.deleteWordBackward(); // início do documento → nada
  assert.equal(await doc(), ' qux');
  await c.undo();
  assert.equal(await doc(), ' \nqux');
});

test('selectWordAt e selectLineAt (duplo/triplo clique)', async () => {
  const { c, doc } = await setup('foo bar\nbaz\nqux');
  await c.selectWordAt(0, 5);
  assert.deepEqual(c.getSelection(), { anchor: { row: 0, col: 4 }, head: { row: 0, col: 7 } });
  assert.equal(await c.getSelectedText(), 'bar');
  await c.selectLineAt(1);
  assert.equal(await c.getSelectedText(), 'baz\n');
  await c.insertText('X');
  assert.equal(await doc(), 'foo bar\nXqux');
  await c.selectLineAt(1); // última linha: sem '\n' final
  assert.equal(await c.getSelectedText(), 'Xqux');
  await c.selectLineAt(99); // limitado ao último índice
  assert.equal(await c.getSelectedText(), 'Xqux');
});
