import test from 'node:test';
import assert from 'node:assert/strict';
import { createClickCounter } from '../apps/pwa/public/workspace/assets/click-counter.js';

test('cliques rápidos e próximos contam 1, 2, 3 e voltam a 1', () => {
  const k = createClickCounter();
  assert.equal(k.register({ time: 0, x: 10, y: 10 }), 1);
  assert.equal(k.register({ time: 200, x: 11, y: 10 }), 2);
  assert.equal(k.register({ time: 400, x: 10, y: 11 }), 3);
  assert.equal(k.register({ time: 600, x: 10, y: 10 }), 1);
});

test('demora, distância ou relógio a recuar reiniciam a contagem', () => {
  const k = createClickCounter({ interval: 300, distance: 3 });
  k.register({ time: 0, x: 0, y: 0 });
  assert.equal(k.register({ time: 301, x: 0, y: 0 }), 1);
  assert.equal(k.register({ time: 400, x: 10, y: 0 }), 1);
  assert.equal(k.register({ time: 450, x: 10, y: 0 }), 2);
  assert.equal(k.register({ time: 100, x: 10, y: 0 }), 1);
  k.reset();
  assert.equal(k.register({ time: 110, x: 10, y: 0 }), 1);
});
