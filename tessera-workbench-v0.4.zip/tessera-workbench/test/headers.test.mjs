import test from 'node:test';
import assert from 'node:assert/strict';
import { newNonce, workspaceHeaders, assetHeaders, authHeaders, previewHeaders } from '../apps/pwa/server/headers.mjs';

const csp = (h) => h['Content-Security-Policy'];

test('nonces são únicos e imprevisíveis', () => {
  const set = new Set(Array.from({ length: 200 }, newNonce));
  assert.equal(set.size, 200);
});

test('workspace: CSP estrita, Trusted Types e isolamento', () => {
  const n = newNonce();
  const h = workspaceHeaders(n, { previewOrigin: 'https://p.example' });
  const c = csp(h);
  assert.match(c, new RegExp(`script-src 'nonce-${n.replace(/[+/=]/g, '\\$&')}' 'strict-dynamic' 'wasm-unsafe-eval'`));
  assert.ok(!c.includes('unsafe-inline'));
  assert.ok(!/'unsafe-eval'/.test(c));
  assert.ok(c.includes("object-src 'none'") && c.includes("base-uri 'none'"));
  assert.ok(c.includes("require-trusted-types-for 'script'"));
  assert.ok(c.includes('trusted-types tessera-sanitize tessera-worker'));
  assert.ok(c.includes('upgrade-insecure-requests'));
  assert.equal(h['Cross-Origin-Opener-Policy'], 'same-origin');
  assert.equal(h['Cross-Origin-Embedder-Policy'], 'credentialless');
});

test('workspace em dev não força upgrade-insecure-requests', () => {
  assert.ok(!csp(workspaceHeaders('x', { dev: true })).includes('upgrade-insecure-requests'));
});

test('workspace sem preview bloqueia frames', () => {
  assert.ok(csp(workspaceHeaders('x')).includes("frame-src 'none'"));
});

test('/auth/*: sem COEP nem COOP restritivo; sem Trusted Types obrigatório', () => {
  const h = authHeaders('x');
  assert.equal(h['Cross-Origin-Embedder-Policy'], undefined);
  assert.equal(h['Cross-Origin-Opener-Policy'], undefined);
  assert.ok(!csp(h).includes('wasm-unsafe-eval'));
  assert.ok(!csp(h).includes('unsafe-inline'));
});

test('preview: política própria, sem unsafe-*, embutível', () => {
  const h = previewHeaders('abc');
  assert.ok(!csp(h).includes('unsafe-'));
  assert.equal(h['Cross-Origin-Resource-Policy'], 'cross-origin');
  assert.equal(h['Cross-Origin-Embedder-Policy'], 'credentialless');
});

test('ativos: COEP e CSP restritiva para Workers', () => {
  const h = assetHeaders();
  assert.equal(h['Cross-Origin-Embedder-Policy'], 'credentialless');
  assert.ok(!csp(h).includes('unsafe-inline'));
  assert.ok(!/'unsafe-eval'/.test(csp(h)));
  assert.ok(csp(h).includes("script-src 'self' 'wasm-unsafe-eval'"));
});
