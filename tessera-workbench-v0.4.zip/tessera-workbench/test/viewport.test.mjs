import test from 'node:test';
import assert from 'node:assert/strict';
import { computeWindow, MAX_SCROLL_PX } from '../apps/pwa/public/workspace/assets/viewport.js';

const base = { viewportHeight: 200, lineHeight: 20, overscan: 5 };

test('topo: começa na linha 0 e inclui overscan abaixo', () => {
  const w = computeWindow({ ...base, scrollTop: 0, lineCount: 1000 });
  assert.equal(w.first, 0);
  assert.equal(w.last, 10 + 5);
  assert.equal(w.offsetTop, 0);
  assert.equal(w.scale, 1);
  assert.equal(w.scrollHeight, 20_000);
});

test('meio: overscan dos dois lados e offset = first * lineHeight', () => {
  const w = computeWindow({ ...base, scrollTop: 2000, lineCount: 1000 });
  assert.equal(w.first, 100 - 5);
  assert.equal(w.last, 110 + 5);
  assert.equal(w.offsetTop, w.first * 20);
});

test('fim: não passa de lineCount', () => {
  const w = computeWindow({ ...base, scrollTop: 1e9, lineCount: 1000 });
  assert.equal(w.last, 1000);
  assert.ok(w.first < 1000);
});

test('documento vazio e pequeno', () => {
  const e = computeWindow({ ...base, scrollTop: 0, lineCount: 0 });
  assert.deepEqual([e.first, e.last], [0, 0]);
  const s = computeWindow({ ...base, scrollTop: 0, lineCount: 3 });
  assert.deepEqual([s.first, s.last], [0, 3]);
});

test('documentos enormes: altura limitada e linha visível coerente', () => {
  const lineCount = 100_000_000; // 2e9 px lógicos
  const top = computeWindow({ ...base, scrollTop: 0, lineCount });
  assert.ok(top.scrollHeight <= MAX_SCROLL_PX + 1);
  assert.ok(top.scale < 1);

  // a meio da barra de scroll cai a meio do documento
  const mid = computeWindow({ ...base, scrollTop: top.scrollHeight / 2, lineCount });
  assert.ok(Math.abs(mid.first - lineCount / 2) < lineCount * 0.01);

  // no fim da barra, a última linha é alcançável
  const end = computeWindow({ ...base, scrollTop: top.scrollHeight, lineCount });
  assert.equal(end.last, lineCount);
});

test('com escala, o bloco acompanha o scroll (posição fracionária da primeira linha visível)', () => {
  const lineCount = 100_000_000;
  const scrollTop = 123_456.7;
  const w = computeWindow({ ...base, scrollTop, lineCount });
  const logicalTop = scrollTop / w.scale;
  const r = Math.floor(logicalTop / 20);
  const y = w.offsetTop + (r - w.first) * 20; // posição, no ecrã, da linha r
  assert.ok(Math.abs(y - (scrollTop - (logicalTop - r * 20))) < 1e-6);
});

test('parâmetros inválidos', () => {
  assert.throws(() => computeWindow({ ...base, scrollTop: -1, lineCount: 1 }), RangeError);
  assert.throws(() => computeWindow({ ...base, lineHeight: 0, scrollTop: 0, lineCount: 1 }), RangeError);
  assert.throws(() => computeWindow({ ...base, scrollTop: 0, lineCount: 1.5 }), RangeError);
});

import { edgeScrollDelta } from '../apps/pwa/public/workspace/assets/viewport.js';

test('edgeScrollDelta: zero no meio; negativo em cima; positivo em baixo; satura', () => {
  const box = { top: 100, bottom: 300 };
  assert.equal(edgeScrollDelta({ ...box, y: 200 }), 0);
  assert.equal(edgeScrollDelta({ ...box, y: 124 }), 0); // exatamente no limite da zona
  assert.equal(edgeScrollDelta({ ...box, y: 123 }), -2);
  assert.ok(edgeScrollDelta({ ...box, y: 105 }) < edgeScrollDelta({ ...box, y: 120 }));
  assert.equal(edgeScrollDelta({ ...box, y: 0 }), -32);
  assert.equal(edgeScrollDelta({ ...box, y: 900 }), 32);
  assert.equal(edgeScrollDelta({ ...box, y: 277 }), 2);
});

test('edgeScrollDelta: zona limitada a metade em contentores pequenos e entradas inválidas', () => {
  assert.equal(edgeScrollDelta({ top: 0, bottom: 20, y: 5 }), -Math.ceil((5 / 10) * 32));
  assert.equal(edgeScrollDelta({ top: 0, bottom: 0, y: 5 }), 0);
  assert.equal(edgeScrollDelta({ top: 0, bottom: 100, y: NaN }), 0);
});
