// Teste de fumo da cola DOM com um DOM falso mínimo: confirma que os eventos chegam ao controlador
// (teclas, colar, copiar/cortar, cliques simples/duplo/triplo, arrasto com auto-scroll).
// NÃO substitui testar em navegadores reais (IME, realce, Clipboard, hit-testing verdadeiro).
import test from 'node:test';
import assert from 'node:assert/strict';

class FakeEl {
  constructor(tag = 'div') {
    this.tag = tag; this.listeners = {}; this.style = {}; this.dataset = {};
    this.className = ''; this.hidden = false; this.value = '';
    this.clientWidth = 300; this.clientHeight = 200; this.clientLeft = 0; this.clientTop = 0;
    this.scrollTop = 0; this.scrollLeft = 0; this.focused = false;
  }
  addEventListener(type, fn) { (this.listeners[type] ??= []).push(fn); }
  fire(type, e = {}) {
    const ev = { preventDefault() { this.prevented = true; }, ...e };
    for (const fn of this.listeners[type] ?? []) fn(ev);
    return ev;
  }
  append() {}
  setAttribute() {}
  focus() { this.focused = true; }
  getBoundingClientRect() { return { left: 0, top: 0, right: 300, bottom: 200, width: 300, height: 200 }; }
  querySelector() { return null; }
  querySelectorAll() { return []; }
  contains() { return true; }
  setPointerCapture() {}
  releasePointerCapture() {}
}

const lineEl = Object.assign(new FakeEl(), { nodeType: 1, textContent: 'hello world', dataset: { row: '7' } });
lineEl.closest = () => lineEl;
const textNode = { nodeType: 3, parentElement: lineEl };

globalThis.Node = { ELEMENT_NODE: 1, TEXT_NODE: 3 };
globalThis.document = {
  createElement: (t) => new FakeEl(t),
  caretPositionFromPoint: () => ({ offsetNode: textNode, offset: 3 }),
};
globalThis.requestAnimationFrame = (fn) => setTimeout(() => fn(0), 0);
const written = [];
Object.defineProperty(globalThis, 'navigator', {
  configurable: true,
  value: { clipboard: { write: async (items) => written.push(items) } },
});
globalThis.ClipboardItem = class { constructor(data) { this.data = data; } };

const { attachEditor } = await import('../apps/pwa/public/workspace/assets/editor-input.js');

function harness() {
  const calls = [];
  const rec = (name, ret) => (...a) => { calls.push([name, ...a]); return Promise.resolve(ret); };
  const controller = new Proxy({
    getSelection: () => ({ anchor: { row: 0, col: 0 }, head: { row: 0, col: 0 } }),
    getSelectedText: rec('getSelectedText', 'sel'),
    cut: rec('cut', 'cortado'),
  }, {
    get: (t, k) => (k in t ? t[k] : rec(String(k), true)),
  });
  const view = { setOnRender() {}, renderNow: async () => {}, reveal() {}, refresh() {} };
  const container = new FakeEl();
  attachEditor({ container, controller, view });
  return { calls, container, controller, view };
}

// O textarea é o primeiro elemento criado por attachEditor; apanhamo-lo via createElement.
function harnessWithInput() {
  const created = [];
  const orig = document.createElement;
  document.createElement = (t) => { const el = orig(t); created.push(el); return el; };
  const h = harness();
  document.createElement = orig;
  return { ...h, input: created.find((e) => e.tag === 'textarea') };
}
const tick = (ms = 5) => new Promise((r) => setTimeout(r, ms));

test('teclas: atalhos chegam ao controlador e fazem preventDefault; o resto fica ao navegador', async () => {
  const { calls, input } = harnessWithInput();
  const press = (e) => input.fire('keydown', { keyCode: 0, isComposing: false, getModifierState: () => false, ...e });

  assert.equal(press({ key: 'Backspace' }).prevented, true);
  assert.equal(press({ key: 'ArrowLeft', ctrlKey: true, shiftKey: true }).prevented, true);
  assert.equal(press({ key: 'z', metaKey: true }).prevented, true);
  assert.equal(press({ key: 'c', ctrlKey: true }).prevented, undefined); // copiar → evento `copy`
  assert.equal(press({ key: 'Tab' }).prevented, undefined);
  assert.equal(press({ key: 'x', keyCode: 229 }).prevented, undefined); // IME
  await tick();
  assert.deepEqual(calls.map((c) => c[0]), ['deleteBackward', 'move', 'undo']);
  assert.deepEqual(calls[1], ['move', 'wordLeft', true]);
});

test('texto normal (input) e colar inserem; copiar/cortar escrevem na área de transferência', async () => {
  const { calls, input } = harnessWithInput();
  input.value = 'abc';
  input.fire('input', { isComposing: false });
  input.fire('paste', { clipboardData: { getData: () => 'colado' } });
  await tick();
  assert.deepEqual(calls.filter((c) => c[0] === 'insertText').map((c) => c[1]), ['abc', 'colado']);
  assert.equal(input.value, '');

  written.length = 0;
  assert.equal(input.fire('copy', {}).prevented, true);
  input.fire('cut', {});
  await tick();
  assert.equal(written.length, 2);
  const blob = await written[0][0].data['text/plain'];
  assert.equal(await blob.text(), 'sel');
  assert.equal(await (await written[1][0].data['text/plain']).text(), 'cortado');
});

test('cliques: 1 = caret, 2 = palavra, 3 = linha; shift+clique estende', async () => {
  const { calls, container } = harnessWithInput();
  const down = (t, extra = {}) =>
    container.fire('pointerdown', { target: container, button: 0, clientX: 10, clientY: 10, timeStamp: t, shiftKey: false, pointerType: 'mouse', pointerId: 1, ...extra });
  down(0); container.fire('pointerup', { pointerId: 1 });
  down(100); container.fire('pointerup', { pointerId: 1 });
  down(200); container.fire('pointerup', { pointerId: 1 });
  down(5000, { shiftKey: true }); container.fire('pointerup', { pointerId: 1 });
  await tick(20);
  assert.deepEqual(calls.filter((c) => /^(setCaret|selectWordAt|selectLineAt)$/.test(c[0])), [
    ['setCaret', 7, 3, false],
    ['selectWordAt', 7, 3],
    ['selectLineAt', 7],
    ['setCaret', 7, 3, true],
  ]);
});

test('arrastar para fora do contentor estende a seleção e faz scroll até largar o botão', async () => {
  const { calls, container } = harnessWithInput();
  container.fire('pointerdown', { target: container, button: 0, clientX: 10, clientY: 10, timeStamp: 0, pointerType: 'mouse', pointerId: 1 });
  container.fire('pointermove', { clientX: 10, clientY: 500, pointerId: 1 });
  await tick(30);
  assert.ok(container.scrollTop > 0, 'auto-scroll para baixo');
  assert.ok(calls.some((c) => c[0] === 'setCaret' && c[3] === true), 'estende a seleção');
  container.fire('pointerup', { pointerId: 1 });
  await tick(10);
  const top = container.scrollTop;
  await tick(30);
  assert.equal(container.scrollTop, top, 'parou depois de largar');
  // toque não arrasta
  const before = calls.length;
  container.fire('pointerdown', { target: container, button: 0, clientX: 10, clientY: 10, timeStamp: 9000, pointerType: 'touch', pointerId: 2 });
  container.fire('pointermove', { clientX: 10, clientY: 500, pointerId: 2 });
  await tick(20);
  assert.equal(calls.slice(before).filter((c) => c[3] === true).length, 0);
});
