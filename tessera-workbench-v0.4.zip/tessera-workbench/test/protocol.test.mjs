import test from 'node:test';
import assert from 'node:assert/strict';
import { createCoreHandler } from '../apps/pwa/public/workspace/assets/protocol.js';
import { createMemoryStore, createOpfsStore } from '../apps/pwa/public/workspace/assets/persistence.js';

import { FakeRope } from '../test-support/fake-rope.mjs';
const mk = (store = createMemoryStore()) => ({ store, h: createCoreHandler({ createRope: (t) => new FakeRope(t), store }) });
let n = 0;
const req = (h, op, args = {}) => h.handle({ id: ++n, op, ...args });

test('open/replace/slice/ponto', async () => {
  const { h } = mk();
  assert.deepEqual((await req(h, 'open', { docId: 'a', text: 'olá\nmundo' })).result, { len: 10, lines: 2, restored: false });
  assert.equal((await req(h, 'slice', { docId: 'a', start: 5, end: 10 })).result, 'mundo');
  assert.deepEqual((await req(h, 'offsetToPoint', { docId: 'a', offset: 8 })).result, { row: 1, column: 3 });
  assert.equal((await req(h, 'pointToOffset', { docId: 'a', row: 1, column: 3 })).result, 8);
  const r = await req(h, 'replace', { docId: 'a', start: 5, end: 10, text: 'Tessera' });
  assert.equal(r.result.len, 12);
});

test('a resposta ecoa o id do pedido', async () => {
  const { h } = mk();
  const res = await h.handle({ id: 'xyz', op: 'flush' });
  assert.equal(res.id, 'xyz');
});

test('validação: docId, intervalos, tipos e operações desconhecidas', async () => {
  const { h } = mk();
  for (const docId of ['../x', 'a/b', '..', '', 'x'.repeat(65), 42, undefined, '__workspace__', '__x']) {
    const r = await req(h, 'open', { docId });
    assert.equal(r.ok, false, `docId ${String(docId)} devia falhar`);
  }
  await req(h, 'open', { docId: 'a', text: 'abc' });
  assert.equal((await req(h, 'replace', { docId: 'a', start: 2, end: 1, text: '' })).ok, false);
  assert.equal((await req(h, 'replace', { docId: 'a', start: -1, end: 1, text: '' })).ok, false);
  assert.equal((await req(h, 'replace', { docId: 'a', start: 0, end: 1.5, text: '' })).ok, false);
  assert.equal((await req(h, 'replace', { docId: 'a', start: 0, end: 1, text: 5 })).ok, false);
  assert.equal((await req(h, 'slice', { docId: 'nunca-aberto', start: 0, end: 0 })).ok, false);
  assert.equal((await req(h, 'constructor')).ok, false);
  assert.equal((await req(h, '__proto__')).ok, false);
  assert.equal((await h.handle(null)).ok, false);
});

test('erros do núcleo viram respostas ok:false (sem rebentar o Worker)', async () => {
  const { h } = mk();
  await req(h, 'open', { docId: 'a', text: 'abc' });
  const r = await req(h, 'replace', { docId: 'a', start: 0, end: 99, text: '' });
  assert.equal(r.ok, false);
  assert.match(r.error, /limites/);
});

test('flush persiste e reabrir restaura', async () => {
  const { h, store } = mk();
  await req(h, 'open', { docId: 'd1', text: 'um' });
  await req(h, 'replace', { docId: 'd1', start: 2, end: 2, text: ' dois' });
  assert.equal(h.dirtyCount(), 1);
  assert.equal((await req(h, 'flush')).result.saved, 1);
  assert.equal(h.dirtyCount(), 0);
  assert.equal(await store.load('d1'), 'um dois');

  const second = createCoreHandler({ createRope: (t) => new FakeRope(t), store });
  const r = await second.handle({ id: 1, op: 'open', docId: 'd1', text: 'IGNORADO' });
  assert.deepEqual(r.result, { len: 7, lines: 1, restored: true });
});

test('se o save falhar, o documento continua sujo', async () => {
  const store = { async load() { return null; }, async save() { throw new Error('disco cheio'); } };
  const { h } = mk(store);
  await req(h, 'open', { docId: 'a', text: 'x' });
  const r = await req(h, 'flush');
  assert.equal(r.ok, false);
  assert.equal(h.dirtyCount(), 1);
});

// --- OPFS com sistema de ficheiros falso ---
function fakeOpfs() {
  const files = new Map();
  const notFound = () => Object.assign(new Error('nf'), { name: 'NotFoundError' });
  const dir = {
    async getFileHandle(name, { create } = {}) {
      if (!files.has(name)) { if (!create) throw notFound(); files.set(name, Buffer.alloc(0)); }
      // handle "vivo": lê sempre o ficheiro atual
      return {
        async createSyncAccessHandle() {
          const live = {
            getSize: () => files.get(name).length,
            read(buf, { at }) { files.get(name).copy(buf, 0, at); },
            truncate(size) { files.set(name, files.get(name).subarray(0, size)); },
            write(data, { at }) {
              const cur = files.get(name);
              const out = Buffer.alloc(Math.max(cur.length, at + data.length));
              cur.copy(out); Buffer.from(data).copy(out, at);
              files.set(name, out); return data.length;
            },
            flush() {}, close() {},
          };
          return live;
        },
      };
    },
  };
  return { root: { async getDirectoryHandle() { return dir; } }, files };
}

test('OPFS store: load inexistente → null; save/load com UTF-8; save mais curto trunca', async () => {
  const { root, files } = fakeOpfs();
  const store = createOpfsStore(async () => root);
  assert.equal(await store.load('nada'), null);
  await store.save('doc', 'olá mundo — 日本語');
  assert.equal(await store.load('doc'), 'olá mundo — 日本語');
  await store.save('doc', 'curto');
  assert.equal(await store.load('doc'), 'curto');
  assert.equal(files.get('doc.txt').length, 5);
});

// --- operação `lines` e adaptador de edição ---
import { createLineSource, toByteEdit } from '../apps/pwa/public/workspace/assets/edit-adapter.js';

const callOf = (h) => async (op, args = {}) => {
  const r = await h.handle({ id: 1, op, ...args });
  if (!r.ok) throw new Error(r.error);
  return r.result;
};

test('lines: intervalos, fim sem \\n, linhas vazias, além do fim', async () => {
  const { h } = mk();
  const call = callOf(h);
  await call('open', { docId: 'l', text: 'a\n\nccc\ndd' });
  assert.deepEqual(await call('lines', { docId: 'l', startRow: 0, endRow: 4 }), ['a', '', 'ccc', 'dd']);
  assert.deepEqual(await call('lines', { docId: 'l', startRow: 1, endRow: 3 }), ['', 'ccc']);
  assert.deepEqual(await call('lines', { docId: 'l', startRow: 3, endRow: 99 }), ['dd']);
  assert.deepEqual(await call('lines', { docId: 'l', startRow: 4, endRow: 9 }), []);
  assert.deepEqual(await call('lines', { docId: 'l', startRow: 2, endRow: 2 }), []);
  await call('open', { docId: 'vazio' });
  assert.deepEqual(await call('lines', { docId: 'vazio', startRow: 0, endRow: 1 }), ['']);
  await call('open', { docId: 'nl', text: 'x\n' });
  assert.deepEqual(await call('lines', { docId: 'nl', startRow: 0, endRow: 5 }), ['x', '']);
});

test('lines: pedidos inválidos', async () => {
  const { h } = mk();
  await req(h, 'open', { docId: 'l', text: 'a' });
  assert.equal((await req(h, 'lines', { docId: 'l', startRow: 2, endRow: 1 })).ok, false);
  assert.equal((await req(h, 'lines', { docId: 'l', startRow: -1, endRow: 1 })).ok, false);
});

test('adaptador: seleção UTF-16 com emoji → bytes UTF-8 corretos e edição aplicada', async () => {
  const { h } = mk();
  const call = callOf(h);
  await call('open', { docId: 'e', text: 'olá\na😀b\nfim' });
  const source = createLineSource(call, 'e');

  // seleciona "😀" na linha 1: colunas UTF-16 1..3
  const edit = await toByteEdit(source, { startRow: 1, startCol: 1, endRow: 1, endCol: 3, text: 'X' });
  assert.equal(await call('slice', { docId: 'e', start: edit.start, end: edit.end }), '😀');
  await call('replace', { docId: 'e', ...edit });
  assert.deepEqual(await call('lines', { docId: 'e', startRow: 0, endRow: 3 }), ['olá', 'aXb', 'fim']);

  // seleção multi-linha: do fim de "olá" (col 3) ao início de "fim" (col 0)
  const multi = await toByteEdit(source, { startRow: 0, startCol: 3, endRow: 2, endCol: 0, text: ' ' });
  await call('replace', { docId: 'e', ...multi });
  assert.deepEqual(await call('lines', { docId: 'e', startRow: 0, endRow: 9 }), ['olá fim']);
});

test('adaptador: rejeita coluna a meio de par substituto, intervalo invertido e linha inexistente', async () => {
  const { h } = mk();
  const call = callOf(h);
  await call('open', { docId: 'e', text: 'a😀b' });
  const source = createLineSource(call, 'e');
  await assert.rejects(toByteEdit(source, { startRow: 0, startCol: 2, endRow: 0, endCol: 3, text: '' }), RangeError);
  await assert.rejects(toByteEdit(source, { startRow: 0, startCol: 3, endRow: 0, endCol: 1, text: '' }), RangeError);
  await assert.rejects(toByteEdit(source, { startRow: 5, startCol: 0, endRow: 5, endCol: 0, text: '' }), RangeError);
});
