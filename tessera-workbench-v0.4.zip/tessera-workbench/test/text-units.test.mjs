import test from 'node:test';
import assert from 'node:assert/strict';
import { utf8Length, utf16ToUtf8, utf8ToUtf16 } from '../apps/pwa/public/workspace/assets/text-units.js';

const SAMPLES = ['', 'abc', 'olá', '日本語', 'a😀b', '😀😀', 'x\u0301y', '\u{10FFFF}'];

test('utf8Length coincide com TextEncoder', () => {
  for (const s of SAMPLES) assert.equal(utf8Length(s), new TextEncoder().encode(s).length, s);
  // surrogate isolado → U+FFFD (3 bytes), igual ao TextEncoder
  assert.equal(utf8Length('\ud800'), new TextEncoder().encode('\ud800').length);
});

test('ida e volta em todas as fronteiras válidas', () => {
  for (const s of SAMPLES) {
    let idx = 0;
    for (const ch of s) {
      const b = utf16ToUtf8(s, idx);
      assert.equal(utf8ToUtf16(s, b), idx, `${s} @${idx}`);
      idx += ch.length;
    }
    assert.equal(utf8ToUtf16(s, utf16ToUtf8(s, s.length)), s.length);
  }
});

test('utf16ToUtf8 rejeita índice a meio de par substituto e fora dos limites', () => {
  assert.throws(() => utf16ToUtf8('a😀b', 2), RangeError);
  assert.equal(utf16ToUtf8('a😀b', 1), 1);
  assert.equal(utf16ToUtf8('a😀b', 3), 5);
  for (const bad of [-1, 99, 1.5, NaN]) assert.throws(() => utf16ToUtf8('abc', bad), RangeError);
});

test('utf8ToUtf16 rejeita offsets a meio de carácter e fora dos limites', () => {
  assert.throws(() => utf8ToUtf16('olá', 3), RangeError); // a meio de "á"
  assert.throws(() => utf8ToUtf16('a😀', 3), RangeError);
  assert.throws(() => utf8ToUtf16('abc', 4), RangeError);
  assert.throws(() => utf8ToUtf16('abc', -1), RangeError);
});
