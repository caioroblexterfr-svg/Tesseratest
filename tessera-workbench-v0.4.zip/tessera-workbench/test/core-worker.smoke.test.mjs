// Teste de fumo da composição do Worker: arranque, encaminhamento `ws.*` vs documentos e protocolo de mensagens.
// Corre o ficheiro real do Worker em Node com um `self` falso (sem OPFS nem WASM → contingência em memória).
import test from 'node:test';
import assert from 'node:assert/strict';

const posted = [];
const listeners = [];
globalThis.self = {
  addEventListener: (type, fn) => listeners.push([type, fn]),
  postMessage: (m) => posted.push(m),
};
// O Worker usa setInterval para o autosave: não deixar o processo de teste preso.
const realSetInterval = globalThis.setInterval;
globalThis.setInterval = (fn, ms) => { const t = realSetInterval(fn, ms); t.unref?.(); return t; };

await import('../apps/pwa/public/workspace/assets/core.worker.js');

const send = async (data) => {
  const before = posted.length;
  for (const [type, fn] of listeners) if (type === 'message') await fn({ data });
  return posted.slice(before);
};

test('arranque: anuncia armazenamento e estado do núcleo', () => {
  assert.equal(posted[0].type, 'ready');
  assert.match(posted[0].storage, /memória/);
  assert.equal(posted[0].core, 'indisponível'); // tessera_wasm.js só existe depois de scripts/build-wasm.sh
});

test('operações ws.* funcionam sem o WASM e usam o id do pedido', async () => {
  const [r1] = await send({ id: 41, op: 'ws.create', name: 'demo', kind: 'dir' });
  assert.equal(r1.id, 41);
  assert.equal(r1.ok, true);
  const [r2] = await send({ id: 42, op: 'ws.path', nodeId: r1.result.id });
  assert.deepEqual(r2, { id: 42, ok: true, result: '/demo' });
  const [r3] = await send({ id: 43, op: 'ws.create', name: '../fuga' });
  assert.equal(r3.ok, false);
  assert.match(r3.error, /nome/);
  const [r4] = await send({ id: 44, op: 'ws.flush' });
  assert.deepEqual(r4, { id: 44, ok: true, result: { saved: true } });
});

test('as restantes operações vão para o protocolo de documentos', async () => {
  const [r] = await send({ id: 50, op: 'open', docId: 'x', text: 'a' });
  assert.equal(r.id, 50);
  assert.equal(r.ok, false);
  assert.match(r.error, /núcleo WASM indisponível/); // erro do createRope: prova o encaminhamento
  const [bad] = await send({ id: 51, op: 'ws.__proto__' });
  assert.equal(bad.ok, false);
  const [nul] = await send(null);
  assert.equal(nul.ok, false);
});
