// Suite do WorkspaceGraph. Serve também de TESTE DE CONFORMIDADE para a futura versão sobre
// LoroMovableTree (ADR-009): as invariantes e os cenários de convergência têm de continuar a valer.
import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createWorkspaceGraph, validateName, validateOp, ROOT, TRASH,
} from '../apps/pwa/public/workspace/assets/workspace-graph.js';

const mk = (id) => createWorkspaceGraph({ replicaId: id });
const sync = (a, b) => { b.importOps(a.exportOps()); a.importOps(b.exportOps()); };
const throwsRange = (fn, re) => assert.throws(fn, (e) => e instanceof RangeError && (!re || re.test(e.message)), String(re));

// ---------------------------------------------------------------- básico

test('criar, caminhos, resolver, renomear, mover, apagar e restaurar', () => {
  const g = mk('aaaa');
  const src = g.create({ name: 'src', kind: 'dir' });
  const main = g.create({ parentId: src.id, name: 'main.rs' });
  assert.equal(src.id, 'aaaa-1');
  assert.equal(g.pathOf(main.id), '/src/main.rs');
  assert.equal(g.resolve('/src/main.rs'), main.id);
  assert.equal(g.resolve('/src/'), src.id);
  assert.equal(g.resolve('/'), ROOT);
  assert.equal(g.pathOf(ROOT), '/');
  assert.deepEqual(g.children(), [{ id: src.id, name: 'src', kind: 'dir' }]);

  g.rename(main.id, 'lib.rs');
  assert.equal(g.pathOf(main.id), '/src/lib.rs');
  const docs = g.create({ name: 'docs', kind: 'dir' });
  g.move(main.id, docs.id);
  assert.equal(g.pathOf(main.id), '/docs/lib.rs');
  g.move(main.id, ROOT, 'top.rs');
  assert.equal(g.pathOf(main.id), '/top.rs');
  assert.equal(g.move(main.id, ROOT), null); // nada a fazer

  g.remove(main.id);
  assert.equal(g.pathOf(main.id), '/.trash/top.rs');
  assert.equal(g.resolve('/.trash/top.rs'), main.id);
  assert.equal(g.isInTrash(main.id), true);
  assert.deepEqual(g.children().map((c) => c.name), ['docs', 'src']);
  assert.deepEqual(g.children(TRASH).map((c) => c.name), ['top.rs']);

  g.move(main.id, docs.id); // restaurar
  assert.equal(g.pathOf(main.id), '/docs/top.rs');
  assert.equal(g.get(main.id).inTrash, false);
  assert.equal(g.pathOf('zzzz-9'), null);
  assert.equal(g.get('zzzz-9'), null);
  assert.deepEqual(g.children('zzzz-9'), []);
});

test('resolve: segmentos perigosos nunca resolvem', () => {
  const g = mk('aaaa');
  const a = g.create({ name: 'a', kind: 'dir' });
  g.create({ parentId: a.id, name: 'f' });
  for (const p of ['a/f', '/a/../a/f', '/a/./f', '//a/f', '/a//f', '/..', '/a/f/..', '', '/nope', 5, null, '/.trash/nope']) {
    assert.equal(g.resolve(p), null, String(p));
  }
  assert.notEqual(g.resolve('/a/f'), null);
});

// ---------------------------------------------------------------- validação local

test('movimentos inválidos: ciclo, ficheiro como pasta, lixo, raiz', () => {
  const g = mk('aaaa');
  const a = g.create({ name: 'a', kind: 'dir' });
  const b = g.create({ parentId: a.id, name: 'b', kind: 'dir' });
  const f = g.create({ name: 'f' });
  throwsRange(() => g.move(a.id, a.id), /ciclo/);
  throwsRange(() => g.move(a.id, b.id), /ciclo/);
  throwsRange(() => g.create({ parentId: f.id, name: 'x' }), /pasta/);
  throwsRange(() => g.move(a.id, f.id), /pasta/);
  throwsRange(() => g.create({ parentId: 'zzzz-9', name: 'x' }), /desconhecida/);
  throwsRange(() => g.create({ parentId: TRASH, name: 'x' }), /remove/);
  throwsRange(() => g.move(a.id, TRASH), /remove/);
  throwsRange(() => g.move(ROOT, a.id), /desconhecido/);
  throwsRange(() => g.remove(ROOT), /desconhecido/);
  throwsRange(() => g.remove(TRASH), /desconhecido/);
  throwsRange(() => g.create({ name: 'x', kind: 'link' }), /tipo/);
  assert.equal(g.pathOf(b.id), '/a/b'); // nada mudou
});

test('nomes duplicados (sem distinguir maiúsculas), lixo e restauro', () => {
  const g = mk('aaaa');
  const d = g.create({ name: 'd', kind: 'dir' });
  g.create({ name: 'A.txt' });
  throwsRange(() => g.create({ name: 'a.txt' }), /já existe/);
  const x = g.create({ parentId: d.id, name: 'a.txt' });
  throwsRange(() => g.move(x.id, ROOT), /já existe/);
  g.move(x.id, ROOT, 'b.txt');
  throwsRange(() => g.rename(x.id, 'A.TXT'), /já existe/);
  g.remove(d.id);
  throwsRange(() => g.create({ parentId: d.id, name: 'y' }), /lixo/);
  throwsRange(() => g.remove(d.id), /lixo/);
  throwsRange(() => g.rename(d.id, 'e'), /lixo/);
  g.rename(x.id, 'b.txt'); // mesmo nome → sem operação, sem erro
});

const BAD_NAMES = [
  '', '.', '..', 'a/b', 'a\\b', '../x', '..\\x', '/etc/passwd', 'x\0y', 'a:b', 'a*b', 'a?b', 'a|b', 'a"b', 'a<b', 'a>b',
  'CON', 'nul.txt', 'com1', 'LPT9.log', 'Aux', 'CONIN$', 'conout$.txt', 'COM\u00b9', 'lpt\u00b2.x', 'a.', 'a ', ' a', '\t', 'a\n', '\u007f', '.trash', '.TRASH',
  'a\u202eb', 'a\u2066b', 'a\ud800b', '\udc00', 'x'.repeat(256), 'é'.repeat(128),
];
const GOOD_NAMES = [
  'a', 'main.rs', '.gitignore', 'a b', 'Café', 'файл', '日本語.txt', '😀', 'x'.repeat(255), 'é'.repeat(127),
  'archive.tar.gz', 'console', 'conf.d', 'conin', 'com10', 'price$', '..a', 'a..b', 'trash', '.trashy',
];

test('validateName: tentativas de path traversal e nomes problemáticos', () => {
  for (const n of BAD_NAMES) assert.throws(() => validateName(n), RangeError, JSON.stringify(n));
  for (const n of GOOD_NAMES) assert.equal(validateName(n), n.normalize('NFC'), JSON.stringify(n));
  assert.equal(validateName('e\u0301'), '\u00e9');
  for (const t of [5, null, undefined, {}, ['a']]) assert.throws(() => validateName(t), TypeError);
  const g = mk('aaaa');
  for (const n of BAD_NAMES) assert.throws(() => g.create({ name: n }), RangeError, JSON.stringify(n));
  assert.equal(g.size(), 0);
});

// ---------------------------------------------------------------- validação de operações remotas

test('operações remotas inválidas são recusadas sem alterar o estado', () => {
  const src = mk('aaaa');
  const { op } = src.create({ name: 'a' });
  const g = mk('bbbb');
  const bad = [
    null, 5, 'x', [], {}, { ...op, r: 'x' }, { ...op, r: 5 }, { ...op, c: 0 }, { ...op, c: 1.5 }, { ...op, c: -1 },
    { ...op, c: 2 ** 60 }, { ...op, c: '1' }, { ...op, node: ROOT }, { ...op, node: TRASH }, { ...op, node: '__proto__' },
    { ...op, node: 'aaaa-1x' }, { ...op, parent: 'x' }, { ...op, parent: undefined }, { ...op, kind: 'link' },
    { ...op, name: '../x' }, { ...op, name: 'e\u0301' }, { ...op, name: '' }, { ...op, name: 7 },
  ];
  for (const b of bad) assert.throws(() => g.apply(b), (e) => e instanceof TypeError || e instanceof RangeError, JSON.stringify(b));
  assert.equal(g.size(), 0);
  assert.deepEqual(g.exportOps(), []);
});

test('apply é idempotente; campos extra são descartados; importOps relata o que recusa', () => {
  const src = mk('aaaa');
  const { op } = src.create({ name: 'a' });
  const g = mk('bbbb');
  assert.equal(g.apply({ ...op, evil: 1, __proto__: { x: 1 } }), true);
  assert.equal(g.apply(op), false);
  assert.deepEqual(g.exportOps(), [op]);
  const r = g.importOps([op, { ...op, c: 2, node: 'aaaa-2', name: '..' }, null, { ...op, c: 3, node: 'aaaa-3', name: 'b' }]);
  assert.deepEqual({ applied: r.applied, duplicates: r.duplicates, bad: r.rejected.map((x) => x.index) }, { applied: 1, duplicates: 1, bad: [1, 2] });
  assert.equal(g.size(), 2);
  assert.deepEqual(validateOp({ ...op, evil: 1 }), op);
});

// ---------------------------------------------------------------- convergência (cenários)

test('ciclo concorrente (A move X→Y, B move Y→X): converge sem ciclo', () => {
  const a = mk('aaaa');
  const b = mk('bbbb');
  const x = a.create({ name: 'X', kind: 'dir' });
  const y = a.create({ name: 'Y', kind: 'dir' });
  sync(a, b);
  a.move(x.id, y.id);
  b.move(y.id, x.id);
  sync(a, b);
  assert.deepEqual(a.snapshot(), b.snapshot());
  // mesmo contador: desempata a réplica «aaaa» → a sua operação vem primeiro e vence; a de B é ineficaz.
  assert.equal(a.pathOf(x.id), '/Y/X');
  assert.equal(a.pathOf(y.id), '/Y');
  assert.equal(b.pathOf(x.id), '/Y/X');
});

test('mesmo nó movido para pastas diferentes: um só pai (o da última operação)', () => {
  const a = mk('aaaa');
  const b = mk('bbbb');
  const d1 = a.create({ name: 'd1', kind: 'dir' });
  const d2 = a.create({ name: 'd2', kind: 'dir' });
  const f = a.create({ name: 'f' });
  sync(a, b);
  a.move(f.id, d1.id);
  b.move(f.id, d2.id);
  sync(a, b);
  assert.deepEqual(a.snapshot(), b.snapshot());
  assert.equal(a.pathOf(f.id), '/d2/f');
  assert.equal(a.children(d1.id).length + a.children(d2.id).length + a.children().filter((c) => c.name === 'f').length, 1);
});

test('mover vs apagar: ganha a operação de maior timestamp, nos dois sentidos', () => {
  for (const [bumpA, expected] of [[false, '/.trash/f'], [true, '/d/f']]) {
    const a = mk('aaaa');
    const b = mk('bbbb');
    const d = a.create({ name: 'd', kind: 'dir' });
    const f = a.create({ name: 'f' });
    sync(a, b);
    if (bumpA) { a.create({ name: 'tmp1' }); a.create({ name: 'tmp2' }); }
    a.move(f.id, d.id);
    b.remove(f.id);
    sync(a, b);
    assert.deepEqual(a.snapshot(), b.snapshot());
    assert.equal(a.pathOf(f.id), expected);
  }
});

test('criar numa pasta apagada em concorrência: o ficheiro fica no lixo, não se perde', () => {
  const a = mk('aaaa');
  const b = mk('bbbb');
  const d = a.create({ name: 'd', kind: 'dir' });
  sync(a, b);
  const f = a.create({ parentId: d.id, name: 'f.txt' });
  b.remove(d.id);
  sync(a, b);
  assert.deepEqual(a.snapshot(), b.snapshot());
  assert.equal(a.pathOf(f.id), '/.trash/d/f.txt');
  assert.deepEqual(a.children(), []);
  a.move(d.id, ROOT); // restaurar a pasta traz o ficheiro de volta
  assert.equal(a.pathOf(f.id), '/d/f.txt');
});

test('irmãos com o mesmo nome criados em concorrência coexistem, de forma determinística', () => {
  const a = mk('aaaa');
  const b = mk('bbbb');
  const na = a.create({ name: 'note.txt' });
  const nb = b.create({ name: 'note.txt' });
  sync(a, b);
  const names = (g) => g.children().map((c) => [c.id, c.name]);
  assert.deepEqual(names(a), [[na.id, 'note.txt'], [nb.id, 'note.txt (2)']]);
  assert.deepEqual(names(b), names(a));
  assert.equal(a.resolve('/note.txt (2)'), nb.id);
  // outra réplica, ordem de entrega inversa
  const c = mk('cccc');
  for (const op of a.exportOps().reverse()) c.apply(op);
  assert.deepEqual(names(c), names(a));
});

test('nomes que só diferem em maiúsculas e colisão com um nome «(2)» real', () => {
  const a = mk('aaaa');
  const b = mk('bbbb');
  a.create({ name: 'Readme.md' });
  b.create({ name: 'README.md' });
  a.create({ name: 'x' });
  a.create({ name: 'x (2)' });
  b.create({ name: 'x' });
  sync(a, b);
  // ordem por unidades de código (determinística): maiúsculas antes de minúsculas
  assert.deepEqual(a.children().map((c) => c.name), ['README.md (2)', 'Readme.md', 'x', 'x (2)', 'x (3)']);
  assert.deepEqual(b.children(), a.children());
});

test('entrega fora de ordem (filho antes do pai) converge', () => {
  const a = mk('aaaa');
  const d = a.create({ name: 'd', kind: 'dir' });
  const f = a.create({ parentId: d.id, name: 'f' });
  a.rename(f.id, 'g');
  const e = a.create({ name: 'e', kind: 'dir' });
  a.move(f.id, e.id);
  a.remove(d.id);
  const c = mk('cccc');
  for (const op of a.exportOps().reverse()) c.apply(op);
  assert.deepEqual(c.snapshot(), a.snapshot());
  assert.equal(c.pathOf(f.id), '/e/g');
  assert.equal(c.pathOf(d.id), '/.trash/d');
});

test('relógio de Lamport: operações locais depois de importar têm contador maior', () => {
  const a = mk('aaaa');
  for (let i = 0; i < 5; i++) a.create({ name: `f${i}` });
  const b = mk('bbbb');
  b.importOps(a.exportOps());
  const { op } = b.create({ name: 'novo' });
  assert.equal(op.c, 6);
  a.apply(op);
  assert.deepEqual(a.snapshot(), b.snapshot());
});

test('operações remotas bem formadas mas hostis são ineficazes (e podem tornar-se eficazes se chegar o pai)', () => {
  const g = mk('aaaa');
  const f = g.create({ name: 'f' });
  const d = g.create({ name: 'd', kind: 'dir' });
  const before = g.snapshot();
  const hostile = [
    { r: 'evil', c: 10, node: 'evil-1', parent: f.id, name: 'x', kind: 'file' }, // pai é um ficheiro
    { r: 'evil', c: 11, node: f.id, parent: ROOT, name: 'f', kind: 'dir' }, // troca o tipo de um nó
    { r: 'evil', c: 12, node: 'evil-2', parent: 'zzzz-77', name: 'x', kind: 'file' }, // pai desconhecido
    { r: 'evil', c: 13, node: d.id, parent: d.id, name: 'd', kind: 'dir' }, // pai de si próprio
  ];
  assert.deepEqual(g.importOps(hostile), { applied: 4, duplicates: 0, rejected: [] });
  assert.deepEqual(g.snapshot(), before); // estado intacto…
  assert.equal(g.exportOps().length, 6); // …mas as operações ficam no registo
  assert.equal(g.pathOf('evil-1'), null);
  // o pai desconhecido aparece depois, com timestamp anterior: a operação 12 passa a ser eficaz
  g.apply({ r: 'zzzz', c: 5, node: 'zzzz-77', parent: ROOT, name: 'late', kind: 'dir' });
  assert.equal(g.pathOf('evil-2'), '/late/x');
  assert.equal(g.pathOf('evil-1'), null); // um ficheiro continua a não poder ter filhos
  checkInvariants(g);
  assert.deepEqual(g.snapshot(), replay(g.exportOps()));
});

test('persistência: exportar → JSON → importar reproduz o estado e continua a funcionar', () => {
  const a = mk('aaaa');
  const d = a.create({ name: 'd', kind: 'dir' });
  const f = a.create({ parentId: d.id, name: 'f' });
  a.rename(f.id, 'g');
  a.remove(d.id);
  const saved = JSON.stringify({ v: 1, ops: a.exportOps() });
  const b = mk('bbbb');
  const r = b.importOps(JSON.parse(saved).ops);
  assert.equal(r.rejected.length, 0);
  assert.deepEqual(b.snapshot(), a.snapshot());
  assert.deepEqual(b.exportOps(), a.exportOps());
  const n = b.create({ name: 'depois' });
  assert.ok(n.op.c > 4);
  a.apply(n.op);
  assert.deepEqual(a.snapshot(), b.snapshot());
});

// ---------------------------------------------------------------- fuzz contra um oráculo

function mulberry32(a) {
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const cmpOp = (a, b) => a.c - b.c || (a.r < b.r ? -1 : a.r > b.r ? 1 : 0);

/** Oráculo: o estado é a dobragem das operações ordenadas por timestamp (sem desfazer/refazer). */
function replay(ops) {
  const tree = new Map();
  for (const op of [...ops].sort(cmpOp)) {
    const cur = tree.get(op.node);
    let ok = true;
    if (cur && cur.kind !== op.kind) ok = false;
    if (ok && op.parent !== ROOT && op.parent !== TRASH) {
      const p = tree.get(op.parent);
      if (!p || p.kind !== 'dir') ok = false;
      else for (let q = op.parent; q !== undefined && q !== ROOT && q !== TRASH; q = tree.get(q)?.parent) {
        if (q === op.node) { ok = false; break; }
      }
    }
    if (ok) tree.set(op.node, { parent: op.parent, name: op.name, kind: op.kind });
  }
  return [...tree].map(([id, e]) => [id, e.parent, e.name, e.kind]).sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0));
}

function checkInvariants(g) {
  const snap = g.snapshot();
  const byId = new Map(snap.map(([id, parent, name, kind]) => [id, { parent, name, kind }]));
  for (const [id, { parent }] of byId) {
    // sem ciclos: a cadeia de pais termina na raiz ou no lixo
    let cur = id;
    for (let i = 0; i <= byId.size; i++) {
      if (cur === ROOT || cur === TRASH) break;
      const e = byId.get(cur);
      assert.ok(e, `pai em falta na cadeia de ${id}`);
      cur = e.parent;
      assert.ok(i < byId.size, `ciclo a partir de ${id}`);
    }
    if (parent !== ROOT && parent !== TRASH) assert.equal(byId.get(parent)?.kind, 'dir', `pai de ${id} não é pasta`);
  }
  // sem duplicados nem órfãos: percorrer a árvore visita cada nó exatamente uma vez
  const visited = new Set();
  const walk = (id) => {
    const names = new Set();
    for (const c of g.children(id)) {
      assert.ok(!visited.has(c.id), `${c.id} visto duas vezes`);
      visited.add(c.id);
      assert.ok(!names.has(c.name.toLowerCase()), `nome repetido: ${c.name}`);
      names.add(c.name.toLowerCase());
      walk(c.id);
    }
  };
  walk(ROOT);
  walk(TRASH);
  assert.equal(visited.size, snap.length);
  const ops = g.exportOps();
  for (let i = 1; i < ops.length; i++) assert.ok(cmpOp(ops[i - 1], ops[i]) < 0, 'registo fora de ordem');
}

function shuffle(arr, rnd) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function runFuzz(seed, { steps = 70, replicas = 3 } = {}) {
  const rnd = mulberry32(seed);
  const pick = (arr) => arr[Math.floor(rnd() * arr.length)];
  const gs = Array.from({ length: replicas }, (_, i) => mk(`r${i}${'abcd'[i]}${seed % 10}x`));
  const NAMES = ['a', 'b', 'c', 'A', 'b (2)', 'd'];
  const usedHostile = new Set();
  for (let step = 0; step < steps; step++) {
    const g = pick(gs);
    const snap = g.snapshot();
    const dirs = [ROOT, ...snap.filter((n) => n[3] === 'dir').map((n) => n[0])];
    const any = snap.map((n) => n[0]);
    const roll = rnd();
    try {
      if (rnd() < 0.12) {
        // par válido mas hostil: pai ficheiro/desconhecido, tipo trocado, ciclos… (chaves (r,c) únicas)
        const r = pick(['hxhx', 'hyhy', 'hzhz']);
        const c = 1 + Math.floor(rnd() * steps);
        if (usedHostile.has(`${r}.${c}`)) continue;
        usedHostile.add(`${r}.${c}`);
        const fresh = () => `hnew-${1 + Math.floor(rnd() * 12)}`;
        g.apply({
          r, c,
          node: rnd() < 0.6 && any.length ? pick(any) : fresh(),
          parent: pick([...any, ROOT, TRASH, fresh()]),
          name: pick(NAMES),
          kind: rnd() < 0.5 ? 'dir' : 'file',
        });
        checkInvariants(g);
        assert.deepEqual(g.snapshot(), replay(g.exportOps()), `oráculo após op hostil (seed ${seed})`);
        continue;
      }
      if (roll < 0.30 || any.length === 0) g.create({ parentId: pick(dirs), name: pick(NAMES), kind: rnd() < 0.5 ? 'dir' : 'file' });
      else if (roll < 0.55) g.move(pick(any), pick(dirs), rnd() < 0.3 ? pick(NAMES) : undefined);
      else if (roll < 0.65) g.rename(pick(any), pick(NAMES));
      else if (roll < 0.75) g.remove(pick(any));
      else {
        const dst = pick(gs.filter((x) => x !== g));
        let ops = g.exportOps().filter(() => rnd() < 0.6);
        ops = shuffle([...ops, ...ops.filter(() => rnd() < 0.2)], rnd); // fora de ordem e com duplicados
        const r = dst.importOps(ops);
        assert.equal(r.rejected.length, 0);
        assert.deepEqual(dst.snapshot(), replay(dst.exportOps()), `oráculo (seed ${seed}, passo ${step})`);
        checkInvariants(dst);
      }
    } catch (err) {
      if (!(err instanceof RangeError)) throw err; // só recusas de validação local são esperadas
    }
  }
  // sincronização total, por ordem aleatória
  for (let round = 0; round < 2; round++) {
    for (const a of shuffle([...gs], rnd)) for (const b of shuffle([...gs], rnd)) if (a !== b) b.importOps(shuffle(a.exportOps(), rnd));
  }
  const all = [];
  const seenKeys = new Set();
  for (const g of gs) for (const op of g.exportOps()) if (!seenKeys.has(`${op.r}.${op.c}`)) { seenKeys.add(`${op.r}.${op.c}`); all.push(op); }
  const expected = replay(all);
  for (const g of gs) {
    assert.deepEqual(g.snapshot(), expected, `convergência (seed ${seed})`);
    assert.equal(g.exportOps().length, all.length);
    checkInvariants(g);
  }
  return all.length;
}

test('fuzz: 3 réplicas, operações aleatórias, entrega desordenada → converge, sem ciclos nem duplicados', () => {
  let ops = 0;
  for (let seed = 1; seed <= 150; seed++) ops += runFuzz(seed);
  assert.ok(ops > 2000, `poucas operações exercitadas: ${ops}`);
});

test('fuzz: 5 réplicas e mais passos', () => {
  for (let seed = 1000; seed < 1030; seed++) runFuzz(seed, { steps: 150, replicas: 5 });
});
