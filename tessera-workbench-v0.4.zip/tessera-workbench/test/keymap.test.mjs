import test from 'node:test';
import assert from 'node:assert/strict';
import { keyToCommand, applyCommand } from '../apps/pwa/public/workspace/assets/keymap.js';
import { createCoreHandler } from '../apps/pwa/public/workspace/assets/protocol.js';
import { createMemoryStore } from '../apps/pwa/public/workspace/assets/persistence.js';
import { createEditorController } from '../apps/pwa/public/workspace/assets/editor-controller.js';
import { FakeRope } from '../test-support/fake-rope.mjs';

test('setas, com e sem modificadores', () => {
  assert.deepEqual(keyToCommand({ key: 'ArrowLeft' }), { type: 'move', dir: 'left', extend: false });
  assert.deepEqual(keyToCommand({ key: 'ArrowRight', shiftKey: true }), { type: 'move', dir: 'right', extend: true });
  assert.deepEqual(keyToCommand({ key: 'ArrowLeft', ctrlKey: true }), { type: 'move', dir: 'wordLeft', extend: false });
  assert.deepEqual(keyToCommand({ key: 'ArrowRight', altKey: true, shiftKey: true }), { type: 'move', dir: 'wordRight', extend: true });
  assert.deepEqual(keyToCommand({ key: 'ArrowLeft', metaKey: true }), { type: 'move', dir: 'home', extend: false });
  assert.deepEqual(keyToCommand({ key: 'ArrowRight', metaKey: true }), { type: 'move', dir: 'end', extend: false });
  assert.deepEqual(keyToCommand({ key: 'ArrowUp', metaKey: true }), { type: 'move', dir: 'docStart', extend: false });
  assert.deepEqual(keyToCommand({ key: 'ArrowDown', metaKey: true, shiftKey: true }), { type: 'move', dir: 'docEnd', extend: true });
  assert.equal(keyToCommand({ key: 'ArrowUp', ctrlKey: true }), null);
  assert.equal(keyToCommand({ key: 'ArrowDown', altKey: true }), null);
});

test('Home/End e Ctrl+Home/End', () => {
  assert.equal(keyToCommand({ key: 'Home' }).dir, 'home');
  assert.equal(keyToCommand({ key: 'End' }).dir, 'end');
  assert.equal(keyToCommand({ key: 'Home', ctrlKey: true }).dir, 'docStart');
  assert.equal(keyToCommand({ key: 'End', ctrlKey: true, shiftKey: true }).dir, 'docEnd');
});

test('apagar: por carácter, por palavra; Cmd+Backspace fica ao navegador', () => {
  assert.deepEqual(keyToCommand({ key: 'Backspace' }), { type: 'deleteBackward' });
  assert.deepEqual(keyToCommand({ key: 'Backspace', shiftKey: true }), { type: 'deleteBackward' });
  assert.deepEqual(keyToCommand({ key: 'Backspace', ctrlKey: true }), { type: 'deleteWordBackward' });
  assert.deepEqual(keyToCommand({ key: 'Backspace', altKey: true }), { type: 'deleteWordBackward' });
  assert.deepEqual(keyToCommand({ key: 'Delete' }), { type: 'deleteForward' });
  assert.deepEqual(keyToCommand({ key: 'Delete', ctrlKey: true }), { type: 'deleteWordForward' });
  assert.equal(keyToCommand({ key: 'Backspace', metaKey: true }), null);
});

test('selecionar tudo, undo e redo; copiar/colar ficam ao navegador', () => {
  assert.deepEqual(keyToCommand({ key: 'a', ctrlKey: true }), { type: 'selectAll' });
  assert.deepEqual(keyToCommand({ key: 'A', metaKey: true }), { type: 'selectAll' });
  assert.deepEqual(keyToCommand({ key: 'z', ctrlKey: true }), { type: 'undo' });
  assert.deepEqual(keyToCommand({ key: 'Z', metaKey: true, shiftKey: true }), { type: 'redo' });
  assert.deepEqual(keyToCommand({ key: 'y', ctrlKey: true }), { type: 'redo' });
  for (const key of ['c', 'x', 'v']) assert.equal(keyToCommand({ key, ctrlKey: true }), null);
});

test('Enter, teclas normais e AltGr', () => {
  assert.deepEqual(keyToCommand({ key: 'Enter' }), { type: 'lineBreak' });
  assert.deepEqual(keyToCommand({ key: 'Enter', shiftKey: true }), { type: 'lineBreak' });
  assert.equal(keyToCommand({ key: 'Enter', ctrlKey: true }), null);
  assert.equal(keyToCommand({ key: 'a' }), null);
  assert.equal(keyToCommand({ key: 'Tab' }), null);
  // AltGr (Ctrl+Alt) escreve carateres: nunca é atalho
  assert.equal(keyToCommand({ key: 'ArrowLeft', ctrlKey: true, altKey: true, altGraph: true }), null);
  assert.equal(keyToCommand({ key: 'Backspace', ctrlKey: true, altKey: true, altGraph: true }), null);
  assert.equal(keyToCommand({ key: 'z', ctrlKey: true, altKey: true }), null);
});

test('applyCommand aciona o controlador (fim a fim, sem DOM)', async () => {
  const h = createCoreHandler({ createRope: (t) => new FakeRope(t), store: createMemoryStore() });
  const call = async (op, args = {}) => {
    const r = await h.handle({ id: 1, op, ...args });
    if (!r.ok) throw new Error(r.error);
    return r.result;
  };
  await call('open', { docId: 'd', text: 'foo bar baz' });
  const c = createEditorController({ call, docId: 'd' });
  await c.init();
  const doc = async () => (await call('lines', { docId: 'd', startRow: 0, endRow: 10 })).join('\n');
  const press = (e) => { const cmd = keyToCommand(e); assert.ok(cmd, JSON.stringify(e)); return applyCommand(c, cmd); };

  await press({ key: 'End', ctrlKey: true });
  await press({ key: 'Backspace', ctrlKey: true });
  assert.equal(await doc(), 'foo bar ');
  await press({ key: 'ArrowLeft', ctrlKey: true, shiftKey: true });
  assert.equal(await c.getSelectedText(), 'bar ');
  await press({ key: 'Delete' });
  assert.equal(await doc(), 'foo ');
  await press({ key: 'z', ctrlKey: true });
  await press({ key: 'z', ctrlKey: true });
  assert.equal(await doc(), 'foo bar baz');
  await press({ key: 'y', ctrlKey: true });
  assert.equal(await doc(), 'foo bar ');
  assert.throws(() => applyCommand(c, { type: 'x' }), TypeError);
});
