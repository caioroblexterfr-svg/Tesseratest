# Tessera Workbench

IDE espacial, estrutural e *local-first* (Web/PWA + Tauri opcional).
Documentação normativa: [ARCHITECTURE](docs/ARCHITECTURE.md) · [SECURITY](docs/SECURITY.md) · [ROADMAP](docs/ROADMAP.md).

## Estado (Fase 1, arranque)

| Componente | Estado | Verificação |
|---|---|---|
| `crates/tessera-core`: `SumTree`, `Rope` | Implementado, com testes aleatórios contra `Vec`/`String` | **Não compilado** (sem toolchain Rust no ambiente de geração); corra `cargo test` |
| `crates/tessera-intel`: `AuditPatchProposal` + regras ast-grep | Contrato implementado; regras **experimentais** | `cargo test`; `ast-grep test` por fazer |
| `crates/tessera-sandbox`: `SandboxCapabilityPolicy` | Política com negação por omissão; sem executor Wasmtime | `cargo test` |
| `wit/tessera-plugin.wit` | Contrato inicial | Validar com `wasm-tools component wit` |
| `apps/pwa/server/headers.mjs` | Matriz de cabeçalhos como código | `npm test` ✔ (14 testes) |
| `apps/bff` | OAuth Code+PKCE, sessão HttpOnly | `npm test` ✔; **sem DPoP**, sessões em memória |
| `apps/preview-gateway` | Origem de preview separada (demo) | Cabeçalhos verificados com `curl`; **não testado em navegador** |
| `crates/tessera-wasm`: `WasmRope` (wasm-bindgen) | Escrito; valida offsets UTF-8 sem abortar o WASM | **Não compilado**; `scripts/build-wasm.sh` |
| Worker: protocolo + persistência OPFS | Implementado (`protocol.js`, `persistence.js`) | `npm test` ✔ (OPFS com ficheiros simulados; **não testado em navegador real**) |
| Adaptador de editor: `text-units.js`, `edit-adapter.js`, `viewport.js`, op `lines` | Conversão UTF-16 ↔ UTF-8 estrita; (linha, coluna) → `{start,end,text}`; janela de linhas com escala para documentos enormes | `npm test` ✔ (36 testes) |
| `editor-controller.js`: seleção e edição | Inserir, colar (multi-linha), Backspace/Delete (emoji inteiro, junção de linhas), setas, Home/End, shift+setas, selecionar tudo; **undo/redo** (escrita contínua, Backspace e Delete agrupam-se; seleção restaurada), **texto da seleção e cortar**, **grapheme clusters** (emoji compostos, acentos combinados), **movimento/apagar por palavra**, início/fim de linha e de documento, **seleção de palavra/linha**; operações serializadas | `npm test` ✔ (com `text-boundaries`, `keymap`, `click-counter` e um teste de fumo da cola DOM) |
| `view.js` + `editor-input.js`: vista editável | Textarea invisível (teclado/IME/colar), caret, clique, **duplo/triplo clique**, **arrasto com rato/caneta e auto-scroll**, realce (CSS Custom Highlight API), copiar/cortar (Async Clipboard), atalhos de macOS e Windows/Linux (`keymap.js`); 50 000 linhas na demo | **Não testado em navegador** (só um DOM falso em Node); sem seleção por toque nem arrasto por palavra após duplo clique; acessibilidade parcial |
| `workspace-graph.js` + `workspace-protocol.js`: `WorkspaceGraph` | Árvore móvel replicável (algoritmo de *move* de Kleppmann et al.): sem ciclos nem duplicados em concorrência, apagar = lixo, nomes validados contra *path traversal*, duplicados concorrentes com nome determinístico; operações `ws.*` no Worker e registo de operações no OPFS. **Implementação provisória em JS** até ligar o `LoroMovableTree` ([ADR-009](docs/adr/0009-workspace-graph-arvore-movel.md)) | `npm test` ✔ (123 testes no total): convergência contra um oráculo independente (*fuzz* de 3–5 réplicas, entrega desordenada e operações hostis), verificada também por mutação; Worker real em Node com `self` falso; **não testado em navegador** |
| Loro (`LoroText`, `LoroMovableTree`), Tree-sitter, SCIP, Wasmtime, QuickJS-WASM, Canvas | Por fazer (Fases 1–3) | — |

## Arranque

```bash
npm test          # testes Node (cabeçalhos, BFF/PKCE)
npm run dev       # http://localhost:8080/workspace/  (preview em :8081)
cargo test --workspace
```

A página `/workspace/` mostra: `crossOriginIsolated`, bloqueio de Trusted Types, modo de
armazenamento (OPFS ou contingência), o teste de fumo do `WorkspaceGraph` (alterna `/demo/a/nota.txt` ↔
`/demo/b/` a cada arranque e tenta um ciclo) e a mensagem vinda do iframe de preview isolado.

Para testar o login, defina `OAUTH_AUTHORIZE_URL`, `OAUTH_TOKEN_URL`, `OAUTH_CLIENT_ID`,
`OAUTH_CLIENT_SECRET` (e opcionalmente `OAUTH_REDIRECT_URI`) antes de `npm run dev`.

Para ver o `Rope` a correr no Worker: `cargo test --workspace`, depois `./scripts/build-wasm.sh` e
`npm run dev`. Sem a build WASM, a página mostra «Núcleo tessera-core: indisponível».

## Próximos passos

1. Correr `cargo test` e corrigir o que o compilador apontar; correr `build-wasm.sh`.
2. Testar a edição em Chrome/Firefox/Safari (IME, arrasto e auto-scroll, duplo/triplo clique, realce, copiar/cortar, undo, atalhos de palavra incluídos); depois seleção por toque e undo apoiado no CRDT (por autor).
3. Ligar o Loro: `LoroMovableTree` atrás da interface do `WorkspaceGraph` (a suite `test/workspace-graph.test.mjs` é o teste de conformidade) e `LoroText` para o texto; fallback IndexedDB. Depois: interface de árvore de ficheiros e compactação do registo de operações.
4. Validar a CSP/COOP/COEP em Chrome, Firefox e Safari (ver notas em docs/SECURITY.md §3.4).
