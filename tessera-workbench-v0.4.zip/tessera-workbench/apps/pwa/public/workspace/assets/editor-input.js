// Cola DOM do editor: textarea invisível (teclado, IME, colar) + caret desenhado + rato.
// Toda a lógica de edição está em editor-controller.js (testada em Node); aqui só há eventos.
// Limitações v0.3 (por validar em navegadores reais — nada disto foi testado fora de Node):
//  - seleção por rato/caneta com arrasto (com auto-scroll nas margens), duplo clique = palavra,
//    triplo = linha; realce via CSS Custom Highlight API (sem ela, a seleção existe mas não é
//    desenhada); toque só posiciona o caret; arrastar depois de duplo/triplo clique não estende por palavra;
//  - copiar/cortar via Async Clipboard (ClipboardItem com promessa, por causa do Safari);
//    undo/redo com Ctrl/Cmd+Z, Ctrl/Cmd+Shift+Z e Ctrl+Y;
//  - Ctrl/Alt+setas = palavra, Ctrl/Alt+Backspace/Delete = apagar palavra, Cmd+setas e Ctrl+Home/End =
//    linha/documento (as teclas de macOS e Windows/Linux são aceites em todas as plataformas);
//  - acessibilidade parcial: o foco está num <textarea> rotulado, mas o conteúdo das linhas
//    não é anunciado como texto editável (a melhorar com ARIA/Selection API).
import { createClickCounter } from './click-counter.js';
import { applyCommand, keyToCommand } from './keymap.js';
import { edgeScrollDelta } from './viewport.js';

/**
 * @param {{ container: HTMLElement, view: ReturnType<typeof import('./view.js').createWindowedView>,
 *           controller: ReturnType<typeof import('./editor-controller.js').createEditorController>,
 *           lineHeight?: number }} opts
 */
export function attachEditor({ container, controller, view, lineHeight = 20 }) {
  const input = document.createElement('textarea');
  input.className = 'editor-input';
  input.setAttribute('aria-label', 'Editor de texto');
  input.setAttribute('autocomplete', 'off');
  input.setAttribute('autocapitalize', 'off');
  input.setAttribute('autocorrect', 'off');
  input.spellcheck = false;

  const caret = document.createElement('div');
  caret.className = 'editor-caret';
  caret.hidden = true;
  container.append(input, caret);

  let composing = false;

  function caretPosition(lineEl, col) {
    const box = container.getBoundingClientRect();
    const lineRect = lineEl.getBoundingClientRect();
    let x = lineRect.left + parseFloat(getComputedStyle(lineEl).paddingLeft || '0');
    const textNode = lineEl.firstChild;
    if (textNode && col > 0 && lineEl.textContent !== '\u200b') {
      const text = lineEl.textContent;
      const startCol =
        col >= 2 && /[\udc00-\udfff]/.test(text[col - 1]) && /[\ud800-\udbff]/.test(text[col - 2]) ? col - 2 : col - 1;
      const range = document.createRange();
      range.setStart(textNode, startCol);
      range.setEnd(textNode, col);
      const rects = range.getClientRects();
      if (rects.length) x = rects[rects.length - 1].right;
    }
    return { x: x - box.left + container.scrollLeft, y: lineRect.top - box.top + container.scrollTop };
  }

  const HL = 'tessera-selection';
  function updateHighlight() {
    if (typeof CSS === 'undefined' || !CSS.highlights || typeof Highlight === 'undefined') return;
    const { anchor, head } = controller.getSelection();
    const swap = anchor.row > head.row || (anchor.row === head.row && anchor.col > head.col);
    const [start, end] = swap ? [head, anchor] : [anchor, head];
    if (start.row === end.row && start.col === end.col) { CSS.highlights.delete(HL); return; }
    const ranges = [];
    for (const lineEl of container.querySelectorAll('.line')) {
      const row = Number(lineEl.dataset.row);
      if (row < start.row || row > end.row || !lineEl.firstChild) continue;
      const len = lineEl.firstChild.length;
      const from = row === start.row ? Math.min(start.col, len) : 0;
      const to = row === end.row ? Math.min(end.col, len) : len;
      if (to <= from && row === end.row) continue;
      const r = document.createRange();
      r.setStart(lineEl.firstChild, from);
      r.setEnd(lineEl.firstChild, to);
      ranges.push(r);
    }
    if (ranges.length) CSS.highlights.set(HL, new Highlight(...ranges));
    else CSS.highlights.delete(HL);
  }

  function updateCaret() {
    updateHighlight();
    const { head } = controller.getSelection();
    const lineEl = container.querySelector(`.line[data-row="${head.row}"]`);
    if (!lineEl) { caret.hidden = true; return; }
    const { x, y } = caretPosition(lineEl, head.col);
    caret.style.left = `${x}px`;
    caret.style.top = `${y}px`;
    caret.style.height = `${lineHeight}px`;
    caret.hidden = false;
  }
  view.setOnRender(updateCaret);

  async function run(action) {
    try {
      await action();
    } catch (err) {
      console.error('Erro de edição:', err);
    }
    await view.renderNow();
    view.reveal(controller.getSelection().head.row);
    updateCaret();
  }

  function flushInput() {
    const text = input.value;
    input.value = '';
    if (text) run(() => controller.insertText(text));
  }

  input.addEventListener('compositionstart', () => { composing = true; });
  input.addEventListener('compositionend', () => { composing = false; flushInput(); });
  input.addEventListener('input', (e) => { if (!composing && !e.isComposing) flushInput(); });

  input.addEventListener('paste', (e) => {
    e.preventDefault();
    const text = e.clipboardData?.getData('text/plain') ?? '';
    if (text) run(() => controller.insertText(text));
  });

  // Copiar/cortar: o ClipboardItem tem de ser criado de forma síncrona no evento (Safari), com o
  // texto como promessa; sem ClipboardItem recorre-se a writeText.
  function toClipboard(textPromise) {
    if (typeof ClipboardItem !== 'undefined' && navigator.clipboard?.write) {
      const blob = textPromise.then((t) => new Blob([t], { type: 'text/plain' }));
      return navigator.clipboard.write([new ClipboardItem({ 'text/plain': blob })]);
    }
    return textPromise.then((t) => navigator.clipboard.writeText(t));
  }
  for (const kind of ['copy', 'cut']) {
    input.addEventListener(kind, (e) => {
      e.preventDefault();
      const text = kind === 'copy' ? controller.getSelectedText() : controller.cut();
      run(() => text);
      if (navigator.clipboard) {
        toClipboard(text.then((t) => (t === '' ? Promise.reject(new Error('vazio')) : t))).catch(() => {});
      }
    });
  }

  input.addEventListener('keydown', (e) => {
    if (composing || e.isComposing || e.keyCode === 229) return;
    const cmd = keyToCommand({
      key: e.key, ctrlKey: e.ctrlKey, metaKey: e.metaKey, altKey: e.altKey, shiftKey: e.shiftKey,
      altGraph: e.getModifierState?.('AltGraph') === true,
    });
    if (!cmd) return; // copiar/colar/Tab e o resto ficam ao navegador
    e.preventDefault();
    run(() => applyCommand(controller, cmd));
  });

  /** Posição (linha, coluna) sob o ponteiro; fora das linhas desenhadas, fixa ao início/fim visível. */
  function hitTest(e) {
    let node;
    let offset = 0;
    const pos = document.caretPositionFromPoint?.(e.clientX, e.clientY);
    if (pos) {
      node = pos.offsetNode;
      offset = pos.offset;
    } else {
      const r = document.caretRangeFromPoint?.(e.clientX, e.clientY);
      if (r) { node = r.startContainer; offset = r.startOffset; }
    }
    const el = node?.nodeType === Node.ELEMENT_NODE ? node : node?.parentElement;
    const lineEl = el?.closest?.('.line');
    if (lineEl && container.contains(lineEl)) {
      const empty = lineEl.textContent === '\u200b';
      return { row: Number(lineEl.dataset.row), col: empty || node.nodeType !== Node.TEXT_NODE ? 0 : offset };
    }
    const lines = container.querySelectorAll('.line');
    if (!lines.length) return null;
    const first = lines[0];
    const last = lines[lines.length - 1];
    if (e.clientY < first.getBoundingClientRect().top) return { row: Number(first.dataset.row), col: 0 };
    if (e.clientY > last.getBoundingClientRect().bottom) {
      return { row: Number(last.dataset.row), col: last.textContent === '\u200b' ? 0 : last.textContent.length };
    }
    return null;
  }

  // Coordenadas do ponteiro limitadas à área de conteúdo: arrastar para fora do contentor
  // seleciona até à linha visível mais próxima (e o auto-scroll faz o resto).
  function clampedPoint(p) {
    const r = container.getBoundingClientRect();
    const left = r.left + container.clientLeft;
    const top = r.top + container.clientTop;
    return {
      clientX: Math.min(Math.max(p.clientX, left + 1), left + container.clientWidth - 1),
      clientY: Math.min(Math.max(p.clientY, top + 1), top + container.clientHeight - 1),
    };
  }

  const clicks = createClickCounter();
  let dragging = false;
  let lastPointer = null;
  let pending = null;
  let pumping = false;
  let scrolling = false;

  // Arrasto: só a última posição pendente é aplicada (evita fila de movimentos atrasados).
  async function pump() {
    if (pumping) return;
    pumping = true;
    while (pending) {
      const p = pending;
      pending = null;
      await run(() => controller.setCaret(p.row, p.col, true));
    }
    pumping = false;
  }

  // Auto-scroll enquanto o ponteiro está nas margens (ou fora) do contentor; continua sem novos
  // eventos de rato, até o botão ser largado ou o scroll chegar ao limite.
  async function autoScroll() {
    if (scrolling) return;
    scrolling = true;
    try {
      while (dragging && lastPointer) {
        const r = container.getBoundingClientRect();
        const delta = edgeScrollDelta({ y: lastPointer.clientY, top: r.top, bottom: r.bottom });
        if (delta === 0) break;
        const before = container.scrollTop;
        container.scrollTop = before + delta;
        if (container.scrollTop === before) break;
        await view.renderNow();
        const hit = hitTest(clampedPoint(lastPointer));
        if (hit) await run(() => controller.setCaret(hit.row, hit.col, true));
        await new Promise((resolve) => requestAnimationFrame(resolve));
      }
    } finally {
      scrolling = false;
    }
  }

  container.addEventListener('pointerdown', (e) => {
    if (e.target === input || e.button !== 0) return;
    const rect = container.getBoundingClientRect();
    if (e.clientX > rect.left + container.clientWidth || e.clientY > rect.top + container.clientHeight) return; // barras de scroll
    input.focus({ preventScroll: true });
    const hit = hitTest(e);
    if (!hit) return;
    e.preventDefault();
    if (e.shiftKey) clicks.reset();
    const count = e.shiftKey ? 1 : clicks.register({ time: e.timeStamp, x: e.clientX, y: e.clientY });
    if (count === 2) run(() => controller.selectWordAt(hit.row, hit.col));
    else if (count === 3) run(() => controller.selectLineAt(hit.row));
    else run(() => controller.setCaret(hit.row, hit.col, e.shiftKey));
    if (count === 1 && e.pointerType !== 'touch') {
      dragging = true;
      lastPointer = { clientX: e.clientX, clientY: e.clientY };
      container.setPointerCapture?.(e.pointerId);
    }
  });

  container.addEventListener('pointermove', (e) => {
    if (!dragging) return;
    lastPointer = { clientX: e.clientX, clientY: e.clientY };
    const hit = hitTest(clampedPoint(lastPointer));
    if (hit) { pending = hit; pump(); }
    autoScroll();
  });

  const endDrag = (e) => {
    if (!dragging) return;
    dragging = false;
    lastPointer = null;
    pending = null;
    container.releasePointerCapture?.(e.pointerId);
  };
  container.addEventListener('pointerup', endDrag);
  container.addEventListener('pointercancel', endDrag);

  return { focus: () => input.focus({ preventScroll: true }), updateCaret };
}
