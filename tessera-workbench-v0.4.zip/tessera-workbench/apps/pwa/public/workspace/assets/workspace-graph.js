// WorkspaceGraph: árvore de ficheiros/pastas replicável com «mover» seguro (sem ciclos nem duplicados).
// Implementa o algoritmo de A. Kleppmann et al., «A highly-available move operation for replicated
// trees» (IEEE TPDS, 2021): cada alteração é uma operação `mover(nó → pai, nome)` com relógio de
// Lamport; o estado é sempre o resultado de aplicar TODAS as operações por ordem de timestamp.
// Uma operação que chegue fora de ordem desfaz as posteriores, aplica-se e refaz as desfeitas.
// Uma operação que criaria um ciclo (ou aponta para um pai inexistente/ficheiro) fica no registo
// mas é ineficaz — e pode tornar-se eficaz se uma operação anterior chegar mais tarde.
//
// ESTADO: implementação PROVISÓRIA em JS (ADR-009). O alvo é o `LoroMovableTree` (ADR-002); a suite
// test/workspace-graph.test.mjs é o teste de conformidade que a versão Loro tem de satisfazer.
//
// Convenções:
//  - `ROOT` é a raiz; `TRASH` é o lixo. Nenhum dos dois pode ser movido. Apagar = mover para o lixo
//    (assim «mover» e «apagar» concorrentes convergem, e nada se perde).
//  - Nomes são validados contra path traversal e normalizados em NFC (ver `validateName`).
//  - Dois irmãos com o mesmo nome (criados em concorrência) coexistem; a vista dá ao mais antigo o nome
//    e aos outros «nome (2)», «nome (3)»… de forma determinística (igual em todas as réplicas).
//  - Mover um nó para dentro de uma pasta apagada concorrentemente deixa-o escondido no lixo (recuperável).
//  - O registo cresce sem limite (compactação exige saber o que todas as réplicas já viram: por fazer).

export const ROOT = 'root';
export const TRASH = 'trash';
export const MAX_NAME_BYTES = 255;

const REPLICA_RE = /^[A-Za-z0-9]{4,32}$/;
const NODE_RE = /^([A-Za-z0-9]{4,32})-(\d{1,15})$/;
const FORBIDDEN = /[<>:"/\\|?*\u0000-\u001f\u007f-\u009f\u202a-\u202e\u2066-\u2069]/;
const WINDOWS_DEVICE = /^(con|prn|aux|nul|conin\$|conout\$|com[1-9\u00b9\u00b2\u00b3]|lpt[1-9\u00b9\u00b2\u00b3])(\..*)?$/i;

function hasLoneSurrogate(s) {
  for (let i = 0; i < s.length; i++) {
    const u = s.charCodeAt(i);
    if (u >= 0xd800 && u <= 0xdbff) {
      const next = s.charCodeAt(i + 1);
      if (!(next >= 0xdc00 && next <= 0xdfff)) return true;
      i++;
    } else if (u >= 0xdc00 && u <= 0xdfff) return true;
  }
  return false;
}

/**
 * Valida (e normaliza em NFC) o nome de um ficheiro/pasta. Conservador e portável: pretende que o que
 * passa aqui possa ser exportado para Windows, macOS e Linux sem sair da pasta de destino (a lista cobre
 * o essencial; não é uma garantia formal).
 * Rejeita: vazio, '.', '..', separadores (/ \), carateres do Windows (<>:"|?*), controlo, sobreposição
 * bidirecional (spoofing), substitutos soltos, espaço/ponto no fim, nomes de dispositivo do Windows
 * (CON, NUL, COM1, CONIN$…), '.trash' (reservado) e mais de 255 bytes UTF-8.
 * @returns {string} o nome normalizado
 */
export function validateName(name) {
  if (typeof name !== 'string') throw new TypeError('nome deve ser string');
  if (hasLoneSurrogate(name)) throw new RangeError('nome inválido: Unicode malformado');
  const n = name.normalize('NFC');
  if (n === '') throw new RangeError('nome vazio');
  if (n === '.' || n === '..') throw new RangeError('nome inválido: "." e ".." não são permitidos');
  if (FORBIDDEN.test(n)) throw new RangeError('nome inválido: carateres proibidos');
  if (n !== n.trim() || n.endsWith('.')) throw new RangeError('nome inválido: espaço ou ponto no início/fim');
  if (WINDOWS_DEVICE.test(n)) throw new RangeError('nome inválido: nome reservado');
  if (n.toLowerCase() === '.trash') throw new RangeError('nome inválido: nome reservado');
  if (new TextEncoder().encode(n).length > MAX_NAME_BYTES) throw new RangeError('nome demasiado longo');
  return n;
}

const cmpTs = (a, b) => a.c - b.c || (a.r < b.r ? -1 : a.r > b.r ? 1 : 0);

/** Ordem de criação de um nó, a partir do seu id `${réplica}-${contador}`. */
function byBirth(a, b) {
  const [, ra, ca] = NODE_RE.exec(a);
  const [, rb, cb] = NODE_RE.exec(b);
  return Number(ca) - Number(cb) || (ra < rb ? -1 : ra > rb ? 1 : 0);
}

/**
 * Valida uma operação recebida (potencialmente hostil) e devolve uma cópia limpa.
 * @typedef {{ r: string, c: number, node: string, parent: string, name: string, kind: 'file'|'dir' }} MoveOp
 * @returns {MoveOp}
 */
export function validateOp(raw) {
  if (raw === null || typeof raw !== 'object') throw new TypeError('operação inválida');
  const { r, c, node, parent, name, kind } = raw;
  if (typeof r !== 'string' || !REPLICA_RE.test(r)) throw new RangeError('réplica inválida');
  if (!Number.isSafeInteger(c) || c < 1) throw new RangeError('contador inválido');
  if (typeof node !== 'string' || !NODE_RE.test(node)) throw new RangeError('nó inválido');
  if (parent !== ROOT && parent !== TRASH && !(typeof parent === 'string' && NODE_RE.test(parent))) {
    throw new RangeError('pai inválido');
  }
  if (kind !== 'file' && kind !== 'dir') throw new RangeError('tipo inválido');
  if (typeof name !== 'string' || validateName(name) !== name) throw new RangeError('nome inválido');
  return { r, c, node, parent, name, kind };
}

/** @param {{ replicaId: string }} opts `replicaId`: 4–32 carateres alfanuméricos, único por sessão. */
export function createWorkspaceGraph({ replicaId }) {
  if (typeof replicaId !== 'string' || !REPLICA_RE.test(replicaId)) throw new TypeError('replicaId inválido');

  /** @type {Map<string, { parent: string, name: string, kind: 'file'|'dir' }>} */
  const tree = new Map();
  /** @type {Map<string, Set<string>>} índice pai → filhos (mantido em sincronia com `tree`) */
  const kids = new Map();
  /** @type {{ op: MoveOp, old: object|null, effective: boolean }[]} por ordem de timestamp */
  const log = [];
  const seen = new Set();
  let clock = 0;
  const EMPTY = new Set();
  const kidsOf = (id) => kids.get(id) ?? EMPTY;

  function put(node, entry) {
    const prev = tree.get(node);
    if (prev) {
      const set = kids.get(prev.parent);
      set?.delete(node);
      if (set?.size === 0) kids.delete(prev.parent);
    }
    if (entry) {
      tree.set(node, entry);
      let set = kids.get(entry.parent);
      if (!set) kids.set(entry.parent, (set = new Set()));
      set.add(node);
    } else {
      tree.delete(node);
    }
  }

  /** `anc` é `desc` ou um ancestral de `desc`? (percurso limitado: protege contra estado corrompido) */
  function isAncestorOrSelf(anc, desc) {
    let cur = desc;
    for (let guard = tree.size + 2; guard > 0 && cur !== undefined; guard--) {
      if (cur === anc) return true;
      if (cur === ROOT || cur === TRASH) return false;
      cur = tree.get(cur)?.parent;
    }
    return false;
  }

  function isInTrash(id) {
    let cur = id;
    for (let guard = tree.size + 2; guard > 0 && cur !== undefined; guard--) {
      if (cur === TRASH) return true;
      if (cur === ROOT) return false;
      cur = tree.get(cur)?.parent;
    }
    return false;
  }

  /** Aplica `op` ao estado atual e devolve a entrada de registo (com o que é preciso para desfazer). */
  function doOp(op) {
    const current = tree.get(op.node);
    let effective = true;
    if (op.node === ROOT || op.node === TRASH) effective = false;
    else if (current && current.kind !== op.kind) effective = false;
    else if (op.parent !== ROOT && op.parent !== TRASH) {
      const p = tree.get(op.parent);
      if (!p || p.kind !== 'dir') effective = false; // pai desconhecido (ainda) ou ficheiro
      else if (isAncestorOrSelf(op.node, op.parent)) effective = false; // criaria um ciclo
    }
    if (!effective) return { op, old: null, effective };
    put(op.node, { parent: op.parent, name: op.name, kind: op.kind });
    return { op, old: current ?? null, effective };
  }

  function undo(entry) {
    if (!entry.effective) return;
    put(entry.op.node, entry.old); // `old === null` apaga (a operação tinha criado o nó)
  }

  /** Insere `op` no registo pela ordem de timestamp. Devolve false se já era conhecida. */
  function insert(op) {
    const key = `${op.r}.${op.c}`;
    if (seen.has(key)) return false;
    seen.add(key);
    clock = Math.max(clock, op.c);
    let i = log.length;
    while (i > 0 && cmpTs(log[i - 1].op, op) > 0) i--;
    const tail = log.splice(i);
    for (let j = tail.length - 1; j >= 0; j--) undo(tail[j]);
    log.push(doOp(op));
    for (const t of tail) log.push(doOp(t.op));
    return true;
  }

  function commitLocal(fields) {
    const op = { r: replicaId, c: clock + 1, ...fields };
    insert(op);
    if (!log[log.length - 1].effective) throw new Error('operação local ineficaz (erro interno)');
    return { ...op };
  }

  const siblingTaken = (parentId, name, exceptId) => {
    const folded = name.toLowerCase();
    for (const k of kidsOf(parentId)) if (k !== exceptId && tree.get(k).name.toLowerCase() === folded) return true;
    return false;
  };

  function assertWritableDir(parentId) {
    if (parentId === ROOT) return;
    if (parentId === TRASH) throw new RangeError('use remove() para mover para o lixo');
    const p = typeof parentId === 'string' ? tree.get(parentId) : undefined;
    if (!p) throw new RangeError('pasta de destino desconhecida');
    if (p.kind !== 'dir') throw new RangeError('o destino não é uma pasta');
    if (isInTrash(parentId)) throw new RangeError('a pasta de destino está no lixo');
  }

  /** Nomes a mostrar para os filhos de `parentId`: o mais antigo mantém o nome, os outros ganham « (n)». */
  function displayNames(parentId) {
    const ids = [...kidsOf(parentId)].sort(byBirth);
    const used = new Set(ids.map((id) => tree.get(id).name.toLowerCase()));
    const first = new Set();
    const out = new Map();
    for (const id of ids) {
      const raw = tree.get(id).name;
      const folded = raw.toLowerCase();
      if (!first.has(folded)) { first.add(folded); out.set(id, raw); continue; }
      let k = 2;
      let cand;
      do { cand = `${raw} (${k++})`; } while (used.has(cand.toLowerCase()));
      used.add(cand.toLowerCase());
      out.set(id, cand);
    }
    return out;
  }

  function moveNode(id, parentId, name) {
    const e = typeof id === 'string' ? tree.get(id) : undefined;
    if (!e) throw new RangeError('nó desconhecido');
    const n = name === undefined ? e.name : validateName(name);
    assertWritableDir(parentId);
    if (isAncestorOrSelf(id, parentId)) throw new RangeError('movimento criaria um ciclo');
    if (siblingTaken(parentId, n, id)) throw new RangeError('já existe um item com esse nome');
    if (e.parent === parentId && e.name === n) return null;
    return commitLocal({ node: id, parent: parentId, name: n, kind: e.kind });
  }

  const nodeInfo = (id) => {
    const e = tree.get(id);
    return e ? { id, parent: e.parent, name: e.name, displayName: displayNames(e.parent).get(id), kind: e.kind, inTrash: isInTrash(id) } : null;
  };

  return {
    replicaId,

    // ---- alterações locais (devolvem a operação para difundir) ----
    create({ parentId = ROOT, name, kind = 'file' }) {
      const n = validateName(name);
      if (kind !== 'file' && kind !== 'dir') throw new RangeError('tipo inválido');
      assertWritableDir(parentId);
      if (siblingTaken(parentId, n)) throw new RangeError('já existe um item com esse nome');
      const node = `${replicaId}-${clock + 1}`;
      return { id: node, op: commitLocal({ node, parent: parentId, name: n, kind }) };
    },

    /** Mover (e opcionalmente renomear). Devolve `null` se nada muda. */
    move: moveNode,

    rename(id, name) {
      const e = typeof id === 'string' ? tree.get(id) : undefined;
      if (!e) throw new RangeError('nó desconhecido');
      if (isInTrash(id)) throw new RangeError('item no lixo: restaure-o primeiro');
      return moveNode(id, e.parent, name);
    },

    /** Apagar = mover para o lixo (recuperável com `move`). */
    remove(id) {
      const e = typeof id === 'string' ? tree.get(id) : undefined;
      if (!e) throw new RangeError('nó desconhecido');
      if (isInTrash(id)) throw new RangeError('já está no lixo');
      return commitLocal({ node: id, parent: TRASH, name: e.name, kind: e.kind });
    },

    // ---- replicação ----
    /** Aplica uma operação remota (idempotente). Devolve true se era nova; lança se for inválida. */
    apply(op) {
      return insert(validateOp(op));
    },

    /** Aplica várias; operações inválidas são recusadas uma a uma e relatadas. */
    importOps(ops) {
      let applied = 0;
      let duplicates = 0;
      const rejected = [];
      ops.forEach((op, index) => {
        try {
          if (insert(validateOp(op))) applied++;
          else duplicates++;
        } catch (err) {
          rejected.push({ index, error: String(err?.message ?? err) });
        }
      });
      return { applied, duplicates, rejected };
    },

    /** Todas as operações conhecidas, por ordem de timestamp (para sincronizar e persistir). */
    exportOps: () => log.map((e) => ({ ...e.op })),

    // ---- leitura ----
    has: (id) => tree.has(id),
    get: nodeInfo,
    isInTrash,
    size: () => tree.size,

    children(id = ROOT) {
      if (id !== ROOT && id !== TRASH && !tree.has(id)) return [];
      return [...displayNames(id)]
        .map(([nid, name]) => ({ id: nid, name, kind: tree.get(nid).kind }))
        .sort((a, b) => (a.name < b.name ? -1 : a.name > b.name ? 1 : 0));
    },

    /** Caminho absoluto («/src/main.rs»; itens apagados em «/.trash/…»); `null` se o nó não existe. */
    pathOf(id) {
      if (id === ROOT) return '/';
      if (id === TRASH) return '/.trash';
      const parts = [];
      let cur = id;
      for (let guard = tree.size + 2; cur !== ROOT && cur !== TRASH; guard--) {
        const e = typeof cur === 'string' ? tree.get(cur) : undefined;
        if (!e || guard <= 0) return null;
        parts.push(displayNames(e.parent).get(cur));
        cur = e.parent;
      }
      return `${cur === TRASH ? '/.trash' : ''}/${parts.reverse().join('/')}`;
    },

    /** Caminho → id (`null` se não existir; '.', '..' e segmentos vazios nunca resolvem). */
    resolve(path) {
      if (typeof path !== 'string' || !path.startsWith('/')) return null;
      const segs = path.split('/').slice(1);
      if (segs.length && segs[segs.length - 1] === '') segs.pop(); // barra final
      let cur = ROOT;
      if (segs[0] === '.trash') { cur = TRASH; segs.shift(); }
      for (const s of segs) {
        if (s === '' || s === '.' || s === '..') return null;
        let next = null;
        for (const [nid, name] of displayNames(cur)) if (name === s) { next = nid; break; }
        if (next === null) return null;
        cur = next;
      }
      return cur;
    },

    /** Estado canónico (para comparar réplicas e depurar). */
    snapshot: () =>
      [...tree].map(([id, e]) => [id, e.parent, e.name, e.kind]).sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0)),
  };
}
