// Vista virtualizada (Fase 1): desenha apenas as linhas visíveis. A edição está em editor-input.js.
// Só usa textContent e CSSOM (compatível com Trusted Types e com CSP sem 'unsafe-inline').
import { computeWindow } from './viewport.js';

/**
 * @param {{ container: HTMLElement, lineHeight?: number, getLineCount: () => number,
 *           getLines: (start: number, end: number) => Promise<string[]>,
 *           onRender?: () => void }} opts
 */
export function createWindowedView({ container, lineHeight = 20, getLineCount, getLines, onRender }) {
  let onRenderCb = onRender;
  container.classList.add('viewer');
  container.tabIndex = 0;
  container.setAttribute('role', 'region');
  container.setAttribute('aria-label', 'Texto do documento');

  const spacer = document.createElement('div');
  spacer.className = 'viewer-spacer';
  const block = document.createElement('div');
  block.className = 'viewer-block';
  spacer.appendChild(block);
  container.replaceChildren(spacer);

  let token = 0;
  let queued = false;

  async function render() {
    queued = false;
    const my = ++token;
    const w = computeWindow({
      scrollTop: container.scrollTop,
      viewportHeight: container.clientHeight,
      lineHeight,
      lineCount: getLineCount(),
    });
    spacer.style.height = `${w.scrollHeight}px`;
    const lines = await getLines(w.first, w.last);
    if (my !== token) return; // chegou uma resposta mais recente
    const frag = document.createDocumentFragment();
    lines.forEach((text, i) => {
      const el = document.createElement('div');
      el.className = 'line';
      el.style.height = `${lineHeight}px`;
      el.dataset.row = String(w.first + i);
      el.textContent = text === '' ? '\u200b' : text; // mantém a altura de linhas vazias
      frag.appendChild(el);
    });
    block.style.transform = `translateY(${w.offsetTop}px)`;
    block.replaceChildren(frag);
    onRenderCb?.();
  }

  const schedule = () => {
    if (queued) return;
    queued = true;
    requestAnimationFrame(render);
  };
  container.addEventListener('scroll', schedule, { passive: true });
  new ResizeObserver(schedule).observe(container);
  schedule();

  /** Faz scroll para a linha ficar visível (só quando não há escala de scroll). */
  function reveal(row) {
    const { scale } = computeWindow({
      scrollTop: 0, viewportHeight: container.clientHeight, lineHeight, lineCount: getLineCount(),
    });
    if (scale !== 1) return;
    const top = row * lineHeight;
    const bottom = top + lineHeight;
    if (top < container.scrollTop) container.scrollTop = top;
    else if (bottom > container.scrollTop + container.clientHeight) container.scrollTop = bottom - container.clientHeight;
  }

  return { refresh: schedule, renderNow: render, reveal, setOnRender: (fn) => { onRenderCb = fn; } };
}
