// Armazenamento de documentos: OPFS (primário) ou memória/IndexedDB (contingência).
// v0.1: gravação NÃO atómica (truncate + write). A durabilidade forte virá do registo CRDT (Loro).

export function createMemoryStore() {
  const m = new Map();
  return {
    kind: 'memory',
    async load(id) { return m.get(id) ?? null; },
    async save(id, text) { m.set(id, text); },
  };
}

/** @param {() => Promise<any>} getRoot por omissão: navigator.storage.getDirectory() */
export function createOpfsStore(getRoot = () => navigator.storage.getDirectory()) {
  let dirPromise;
  const dir = () => (dirPromise ??= getRoot().then((r) => r.getDirectoryHandle('docs', { create: true })));
  const fileName = (id) => `${id}.txt`;

  return {
    kind: 'opfs',
    async load(id) {
      let fh;
      try {
        fh = await (await dir()).getFileHandle(fileName(id));
      } catch (err) {
        if (err?.name === 'NotFoundError') return null;
        throw err;
      }
      const access = await fh.createSyncAccessHandle(); // só em Workers
      try {
        const buf = new Uint8Array(access.getSize());
        access.read(buf, { at: 0 });
        return new TextDecoder().decode(buf);
      } finally {
        access.close();
      }
    },
    async save(id, text) {
      const fh = await (await dir()).getFileHandle(fileName(id), { create: true });
      const access = await fh.createSyncAccessHandle();
      try {
        const data = new TextEncoder().encode(text);
        access.truncate(0);
        access.write(data, { at: 0 });
        access.flush();
      } finally {
        access.close();
      }
    },
  };
}

/** Deteta OPFS com SyncAccessHandle (falha, p. ex., na Navegação Privada do Safari). */
export async function probeOpfs() {
  try {
    const root = await navigator.storage.getDirectory();
    const fh = await root.getFileHandle('.tessera-probe', { create: true });
    const access = await fh.createSyncAccessHandle();
    access.close();
    await root.removeEntry('.tessera-probe');
    return true;
  } catch {
    return false;
  }
}
