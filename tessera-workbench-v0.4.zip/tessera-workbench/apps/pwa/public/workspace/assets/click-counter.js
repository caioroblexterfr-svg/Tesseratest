// Contagem de cliques consecutivos (1 → 2 → 3 → 1…) para duplo/triplo clique.
// O PointerEvent.detail de `pointerdown` é sempre 0, por isso contamos nós (tempo + distância).

/** @param {{ interval?: number, distance?: number }} [opts] ms entre cliques e px de tolerância */
export function createClickCounter({ interval = 500, distance = 4 } = {}) {
  let last = null;
  let count = 0;
  return {
    /** @param {{ time: number, x: number, y: number }} click @returns {1|2|3} */
    register({ time, x, y }) {
      const chained =
        last !== null &&
        time >= last.time &&
        time - last.time <= interval &&
        Math.hypot(x - last.x, y - last.y) <= distance;
      count = chained ? (count >= 3 ? 1 : count + 1) : 1;
      last = { time, x, y };
      return count;
    },
    reset() { last = null; count = 0; },
  };
}
