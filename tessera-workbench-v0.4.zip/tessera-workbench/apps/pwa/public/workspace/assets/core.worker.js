// Worker do núcleo (módulo). Carrega tessera-wasm por streaming (se existir), escolhe o
// armazenamento (OPFS ou contingência) e serve dois protocolos: documentos (protocol.js) e o grafo
// do espaço de trabalho, operações `ws.*` (workspace-protocol.js — JS puro, não precisa do WASM).
import { createCoreHandler } from './protocol.js';
import { createWorkspaceHandler } from './workspace-protocol.js';
import { createMemoryStore, createOpfsStore, probeOpfs } from './persistence.js';

async function loadCore() {
  try {
    const glue = await import('./tessera_wasm.js');
    const module = await WebAssembly.compileStreaming(fetch('/workspace/assets/tessera_wasm_bg.wasm'));
    await glue.default({ module_or_path: module });
    return (text) => new glue.WasmRope(text);
  } catch {
    return null; // ainda não compilado: execute scripts/build-wasm.sh
  }
}

const createRope = await loadCore();
const opfs = await probeOpfs();
// Contingência (ex.: Safari privado): memória, VOLÁTIL. IndexedDB entra na Fase 1.
const store = opfs ? createOpfsStore() : createMemoryStore();
const storage = opfs ? 'opfs' : 'memória (volátil — contingência)';

const handler = createCoreHandler({
  createRope: createRope ?? (() => { throw new Error('núcleo WASM indisponível'); }),
  store,
});

// Identidade desta sessão no grafo do espaço de trabalho: aleatória a cada arranque do Worker. Não há
// contadores repetidos porque o relógio de Lamport arranca acima de tudo o que foi carregado.
const replicaId = Array.from(crypto.getRandomValues(new Uint8Array(8)), (b) => b.toString(16).padStart(2, '0')).join('');
const workspace = createWorkspaceHandler({ store, replicaId });

self.addEventListener('message', async (ev) => {
  const target = typeof ev.data?.op === 'string' && ev.data.op.startsWith('ws.') ? workspace : handler;
  self.postMessage(await target.handle(ev.data));
});

let timer;
setInterval(() => {
  if ((handler.dirtyCount() > 0 || workspace.isDirty()) && timer === undefined) {
    timer = setTimeout(async () => {
      timer = undefined;
      await handler.handle({ id: 'autosave', op: 'flush' });
      await workspace.handle({ id: 'autosave-ws', op: 'ws.flush' });
    }, 500);
  }
}, 250);

self.postMessage({ type: 'ready', storage, core: createRope ? 'wasm' : 'indisponível' });
