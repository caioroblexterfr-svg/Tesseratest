// Mapa de teclas → comandos do editor, sem DOM: testável em Node.
// Aceita as convenções de macOS e de Windows/Linux em todas as plataformas:
//   Ctrl/Alt+←/→ palavra · Cmd+←/→ início/fim da linha · Cmd+↑/↓ e Ctrl+Home/End início/fim do documento
//   Ctrl/Alt+Backspace/Delete apagam por palavra · Ctrl/Cmd+Z desfaz, +Shift ou Ctrl+Y refaz · Ctrl/Cmd+A tudo.
// Copiar/cortar/colar ficam nos eventos `copy`/`cut`/`paste` do navegador (devolvem `null` aqui).

/**
 * @param {{ key: string, ctrlKey?: boolean, metaKey?: boolean, altKey?: boolean, shiftKey?: boolean, altGraph?: boolean }} e
 * @returns {{ type: string, dir?: string, extend?: boolean } | null} `null` = deixar ao navegador
 */
export function keyToCommand(e) {
  const { key } = e;
  const ctrl = !!e.ctrlKey;
  const meta = !!e.metaKey;
  const alt = !!e.altKey;
  const shift = !!e.shiftKey;
  if (e.altGraph) return null; // AltGr = Ctrl+Alt no Windows: é escrita de carateres, não um atalho
  const word = (ctrl || alt) && !meta;
  const k = key.length === 1 ? key.toLowerCase() : key;

  if ((ctrl || meta) && !alt) {
    if (k === 'a') return { type: 'selectAll' };
    if (k === 'z') return { type: shift ? 'redo' : 'undo' };
    if (k === 'y' && !shift) return { type: 'redo' };
  }

  switch (key) {
    case 'ArrowLeft':
      return { type: 'move', dir: meta ? 'home' : word ? 'wordLeft' : 'left', extend: shift };
    case 'ArrowRight':
      return { type: 'move', dir: meta ? 'end' : word ? 'wordRight' : 'right', extend: shift };
    case 'ArrowUp':
      if (meta) return { type: 'move', dir: 'docStart', extend: shift };
      return ctrl || alt ? null : { type: 'move', dir: 'up', extend: shift };
    case 'ArrowDown':
      if (meta) return { type: 'move', dir: 'docEnd', extend: shift };
      return ctrl || alt ? null : { type: 'move', dir: 'down', extend: shift };
    case 'Home':
      return { type: 'move', dir: ctrl || meta ? 'docStart' : 'home', extend: shift };
    case 'End':
      return { type: 'move', dir: ctrl || meta ? 'docEnd' : 'end', extend: shift };
    case 'Backspace':
      if (meta) return null;
      return { type: word ? 'deleteWordBackward' : 'deleteBackward' };
    case 'Delete':
      if (meta) return null;
      return { type: word ? 'deleteWordForward' : 'deleteForward' };
    case 'Enter':
      return ctrl || meta || alt ? null : { type: 'lineBreak' };
    default:
      return null;
  }
}

/** Executa um comando devolvido por `keyToCommand` no controlador. */
export function applyCommand(controller, cmd) {
  switch (cmd.type) {
    case 'selectAll': return controller.selectAll();
    case 'undo': return controller.undo();
    case 'redo': return controller.redo();
    case 'move': return controller.move(cmd.dir, cmd.extend);
    case 'deleteBackward': return controller.deleteBackward();
    case 'deleteForward': return controller.deleteForward();
    case 'deleteWordBackward': return controller.deleteWordBackward();
    case 'deleteWordForward': return controller.deleteWordForward();
    case 'lineBreak': return controller.insertLineBreak();
    default: throw new TypeError('comando desconhecido');
  }
}
