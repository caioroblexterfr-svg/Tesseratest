// Janela de linhas visíveis para a vista virtualizada (lógica pura, sem DOM).
// Os navegadores limitam a altura de um elemento (~17–33 M px). Acima de MAX_SCROLL_PX
// a altura do "spacer" é reduzida por um fator de escala e o scrollTop é re-mapeado.

export const MAX_SCROLL_PX = 10_000_000;

/**
 * @returns {{ first: number, last: number, offsetTop: number, scrollHeight: number, scale: number }}
 *  `first..last` (último exclusivo) são as linhas a desenhar; `offsetTop` é o deslocamento
 *  vertical (em px de ecrã) a aplicar ao bloco desenhado dentro do contentor.
 */
export function computeWindow({ scrollTop, viewportHeight, lineHeight, lineCount, overscan = 5 }) {
  if (!(lineHeight > 0) || !(viewportHeight >= 0) || !(scrollTop >= 0) || !Number.isInteger(lineCount) || lineCount < 0) {
    throw new RangeError('parâmetros inválidos');
  }
  const totalHeight = lineCount * lineHeight;
  const scale = totalHeight > MAX_SCROLL_PX ? MAX_SCROLL_PX / totalHeight : 1;
  const scrollHeight = totalHeight * scale;

  const maxLogicalTop = Math.max(0, totalHeight - viewportHeight);
  const logicalTop = Math.min(scrollTop / scale, maxLogicalTop);
  const firstVisible = Math.floor(logicalTop / lineHeight);
  const lastVisible = Math.ceil((logicalTop + viewportHeight) / lineHeight);

  const first = Math.max(0, Math.min(firstVisible - overscan, Math.max(0, lineCount - 1)));
  const last = Math.min(lineCount, lastVisible + overscan);
  const offsetTop = Math.min(scrollTop, maxLogicalTop * scale) - (logicalTop - first * lineHeight);
  return { first, last: Math.max(first, last), offsetTop, scrollHeight, scale };
}

/**
 * Velocidade de auto-scroll (px por fotograma; < 0 = para cima) para um ponteiro perto ou fora
 * das margens verticais do contentor. Cresce com a profundidade na zona de margem e satura em `maxSpeed`.
 */
export function edgeScrollDelta({ y, top, bottom, edge = 24, maxSpeed = 32 }) {
  if (![y, top, bottom].every(Number.isFinite) || !(bottom > top)) return 0;
  const zone = Math.min(edge, (bottom - top) / 2);
  const speed = (depth) => Math.min(maxSpeed, Math.max(1, Math.ceil((depth / zone) * maxSpeed)));
  if (y < top + zone) return -speed(top + zone - y);
  if (y > bottom - zone) return speed(y - (bottom - zone));
  return 0;
}
