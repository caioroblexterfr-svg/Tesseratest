// Protocolo pedido/resposta do Worker do núcleo. Sem dependências do navegador → testável em Node.
// Pedido:   { id, op, ...args }      Resposta: { id, ok: true, result } | { id, ok: false, error }
// Offsets em bytes UTF-8 (ver crates/tessera-wasm).

const DOC_ID = /^[\w.-]{1,64}$/;
const isUint = (n) => Number.isSafeInteger(n) && n >= 0;

// O prefixo `__` é reservado ao sistema (ex.: o registo do espaço de trabalho, `__workspace__`).
function checkDocId(docId) {
  if (typeof docId !== 'string' || !DOC_ID.test(docId) || /^\.+$/.test(docId) || docId.startsWith('__')) {
    throw new RangeError('docId inválido');
  }
  return docId;
}

/**
 * @param {{ createRope: (text: string) => any, store: { load(id): Promise<string|null>, save(id, text): Promise<void> } }} deps
 */
export function createCoreHandler({ createRope, store }) {
  const docs = new Map();
  const dirty = new Set();

  const get = (docId) => {
    const rope = docs.get(checkDocId(docId));
    if (!rope) throw new Error('documento não aberto');
    return rope;
  };
  const info = (rope) => ({ len: rope.len(), lines: rope.lineCount() });

  const ops = {
    async open({ docId, text }) {
      checkDocId(docId);
      if (docs.has(docId)) return { ...info(docs.get(docId)), restored: true };
      const saved = await store.load(docId);
      const initial = saved ?? (typeof text === 'string' ? text : '');
      const rope = createRope(initial);
      docs.set(docId, rope);
      if (saved === null && initial !== '') dirty.add(docId);
      return { ...info(rope), restored: saved !== null };
    },

    async replace({ docId, start, end, text }) {
      if (!isUint(start) || !isUint(end) || start > end) throw new RangeError('intervalo inválido');
      if (typeof text !== 'string') throw new TypeError('text deve ser string');
      const rope = get(docId);
      rope.replace(start, end, text);
      dirty.add(docId);
      return info(rope);
    },

    async slice({ docId, start, end }) {
      if (!isUint(start) || !isUint(end) || start > end) throw new RangeError('intervalo inválido');
      return get(docId).slice(start, end);
    },

    async offsetToPoint({ docId, offset }) {
      if (!isUint(offset)) throw new RangeError('offset inválido');
      const [row, column] = get(docId).offsetToPoint(offset);
      return { row, column };
    },

    async pointToOffset({ docId, row, column }) {
      if (!isUint(row) || !isUint(column)) throw new RangeError('ponto inválido');
      return get(docId).pointToOffset(row, column);
    },

    /** Linhas `startRow..endRow` (exclusivo), sem o '\n' final. Linhas além do fim são omitidas. */
    async lines({ docId, startRow, endRow }) {
      if (!isUint(startRow) || !isUint(endRow) || startRow > endRow) throw new RangeError('intervalo inválido');
      const rope = get(docId);
      const total = rope.lineCount();
      const end = Math.min(endRow, total);
      if (startRow >= end) return [];
      const from = rope.pointToOffset(startRow, 0);
      const to = end >= total ? rope.len() : rope.pointToOffset(end, 0);
      const out = rope.slice(from, to).split('\n');
      if (end < total) out.pop(); // o texto terminava em '\n' → elemento vazio a mais
      return out;
    },

    async flush() {
      const ids = [...dirty];
      for (const id of ids) {
        await store.save(id, docs.get(id).toText());
        dirty.delete(id);
      }
      return { saved: ids.length };
    },
  };

  async function handle(msg) {
    const id = msg?.id;
    try {
      const fn = Object.hasOwn(ops, msg?.op) ? ops[msg.op] : null;
      if (!fn) throw new TypeError('operação desconhecida');
      return { id, ok: true, result: await fn(msg) };
    } catch (err) {
      return { id, ok: false, error: String(err?.message ?? err) };
    }
  }

  return { handle, dirtyCount: () => dirty.size };
}
