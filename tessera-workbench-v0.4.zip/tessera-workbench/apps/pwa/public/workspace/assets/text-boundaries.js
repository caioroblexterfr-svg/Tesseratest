// Fronteiras de texto em colunas UTF-16: grapheme clusters e palavras. Lógica pura, testável em Node.
// Usa Intl.Segmenter (Chrome 87+, Safari 14.1+, Firefox 125+); sem ele recorre a pontos de código
// e a uma regex de palavras (aproximação: acentos combinados e emoji compostos contam como vários).
//
// Todas as funções recebem uma linha (sem '\n') e uma coluna e devolvem uma coluna válida.

const hasSegmenter = typeof Intl !== 'undefined' && typeof Intl.Segmenter === 'function';
const graphemeSeg = hasSegmenter ? new Intl.Segmenter(undefined, { granularity: 'grapheme' }) : null;
const wordSeg = hasSegmenter ? new Intl.Segmenter(undefined, { granularity: 'word' }) : null;

const isHigh = (u) => u >= 0xd800 && u <= 0xdbff;
const isLow = (u) => u >= 0xdc00 && u <= 0xdfff;

// Abaixo de U+0300 não há combinadores, ZWJ, seletores de variação nem pares substitutos:
// entre dois destes carateres há sempre uma fronteira de cluster → caminho rápido sem Segmenter.
const SIMPLE_LIMIT = 0x300;
const simple = (line, i) => i < 0 || i >= line.length || line.charCodeAt(i) < SIMPLE_LIMIT;

// ---- alternativas sem Intl.Segmenter (exportadas só para testes) ----
function* fallbackGraphemes(text) {
  let i = 0;
  for (const ch of text) {
    yield { index: i, segment: ch };
    i += ch.length;
  }
}
function* fallbackWords(text) {
  for (const m of text.matchAll(/[\p{L}\p{N}_]+|\s+|[^\p{L}\p{N}_\s]+/gu)) {
    yield { index: m.index, segment: m[0], isWordLike: /[\p{L}\p{N}]/u.test(m[0]) };
  }
}
export const __fallback = { graphemes: fallbackGraphemes, words: fallbackWords };

const segmentGraphemes = (text) => (graphemeSeg ? graphemeSeg.segment(text) : fallbackGraphemes(text));
const segmentWords = (text) => (wordSeg ? wordSeg.segment(text) : fallbackWords(text));

/** Fronteiras ordenadas numa janela em torno de `col` (linhas enormes não são segmentadas por inteiro). */
function boundariesNear(line, col, radius = 256) {
  let from = Math.max(0, col - radius);
  let to = Math.min(line.length, col + radius);
  if (from > 0 && isLow(line.charCodeAt(from)) && isHigh(line.charCodeAt(from - 1))) from--;
  if (to < line.length && isLow(line.charCodeAt(to)) && isHigh(line.charCodeAt(to - 1))) to++;
  const text = line.slice(from, to);
  const out = [];
  for (const s of segmentGraphemes(text)) out.push(from + s.index);
  out.push(from + text.length);
  return out;
}

const clamp = (line, col) => Math.max(0, Math.min(col, line.length));

/** Maior fronteira de cluster <= col (se `col` cai a meio de um cluster, recua para o início). */
export function snapBoundary(line, col) {
  col = clamp(line, col);
  if (col === 0 || col === line.length) return col;
  if (simple(line, col - 1) && simple(line, col)) return col;
  let best = 0;
  for (const b of boundariesNear(line, col)) {
    if (b > col) break;
    best = b;
  }
  return best;
}

/** Maior fronteira de cluster < col (0 se col <= 0). */
export function prevBoundary(line, col) {
  col = clamp(line, col);
  if (col === 0) return 0;
  if (simple(line, col - 2) && simple(line, col - 1) && simple(line, col)) return col - 1;
  let best = 0;
  for (const b of boundariesNear(line, col)) {
    if (b >= col) break;
    best = b;
  }
  return best;
}

/** Menor fronteira de cluster > col (line.length se col >= length). */
export function nextBoundary(line, col) {
  col = clamp(line, col);
  if (col === line.length) return col;
  if (simple(line, col - 1) && simple(line, col) && simple(line, col + 1)) return col + 1;
  for (const b of boundariesNear(line, col)) if (b > col) return b;
  return line.length;
}

// Clusters de emoji (ZWJ, bandeiras, seletor de variação, caixa de tecla) apagam-se por inteiro com
// Backspace; acentos combinados apagam só o último ponto de código (como nos campos de texto nativos).
const SEQUENCE = /\p{Extended_Pictographic}|\p{Regional_Indicator}|[\u200d\ufe0f\u20e3]/u;

/** Início do que o Backspace deve apagar antes de `col`. */
export function backspaceBoundary(line, col) {
  col = clamp(line, col);
  if (col === 0) return 0;
  const start = prevBoundary(line, col);
  if (SEQUENCE.test(line.slice(start, col))) return start;
  return col >= 2 && isLow(line.charCodeAt(col - 1)) && isHigh(line.charCodeAt(col - 2)) ? col - 2 : col - 1;
}

/** Início da palavra anterior (salta espaços e pontuação). */
export function wordLeft(line, col) {
  col = clamp(line, col);
  let target = 0;
  for (const s of segmentWords(line)) {
    if (s.index >= col) break;
    if (s.isWordLike) target = s.index;
  }
  return target;
}

/** Fim da palavra seguinte (salta espaços e pontuação). */
export function wordRight(line, col) {
  col = clamp(line, col);
  for (const s of segmentWords(line)) {
    const end = s.index + s.segment.length;
    if (end <= col) continue;
    if (s.isWordLike) return end;
  }
  return line.length;
}

/** Intervalo [start,end) da palavra (ou do espaço/pontuação) em `col`, para duplo clique. */
export function wordRangeAt(line, col) {
  if (line.length === 0) return { start: 0, end: 0 };
  col = clamp(line, col);
  let prev = null;
  for (const s of segmentWords(line)) {
    const end = s.index + s.segment.length;
    // Clique logo a seguir ao fim de uma palavra: prefere essa palavra ao que vem depois.
    if (col === s.index && prev?.isWordLike && !s.isWordLike) return { start: prev.start, end: prev.end };
    if (col < end) return { start: s.index, end };
    prev = { start: s.index, end, isWordLike: s.isWordLike };
  }
  return prev ? { start: prev.start, end: prev.end } : { start: 0, end: 0 };
}
