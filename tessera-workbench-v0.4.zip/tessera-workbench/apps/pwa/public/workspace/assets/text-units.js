// Conversão entre unidades UTF-16 (JavaScript/DOM) e bytes UTF-8 (tessera-core).
// Todas as funções são estritas: índices a meio de um par substituto (UTF-16) ou a meio de
// um carácter (UTF-8) lançam RangeError em vez de produzir offsets silenciosamente errados.

/** Comprimento UTF-8 de `str` (surrogates isolados contam como U+FFFD = 3 bytes, como o TextEncoder). */
export function utf8Length(str) {
  let n = 0;
  for (const ch of str) {
    const c = ch.codePointAt(0);
    n += c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
  }
  return n;
}

const isHigh = (u) => u >= 0xd800 && u <= 0xdbff;
const isLow = (u) => u >= 0xdc00 && u <= 0xdfff;

/** Índice UTF-16 → offset em bytes UTF-8 dentro de `str`. */
export function utf16ToUtf8(str, index16) {
  if (!Number.isInteger(index16) || index16 < 0 || index16 > str.length) {
    throw new RangeError('índice UTF-16 fora dos limites');
  }
  if (index16 > 0 && index16 < str.length && isHigh(str.charCodeAt(index16 - 1)) && isLow(str.charCodeAt(index16))) {
    throw new RangeError('índice UTF-16 a meio de um par substituto');
  }
  return utf8Length(str.slice(0, index16));
}

/** Offset em bytes UTF-8 → índice UTF-16 dentro de `str`. */
export function utf8ToUtf16(str, byteIndex) {
  if (!Number.isInteger(byteIndex) || byteIndex < 0) throw new RangeError('offset UTF-8 inválido');
  let bytes = 0;
  let units = 0;
  if (byteIndex === 0) return 0;
  for (const ch of str) {
    const c = ch.codePointAt(0);
    bytes += c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
    units += ch.length;
    if (bytes === byteIndex) return units;
    if (bytes > byteIndex) throw new RangeError('offset UTF-8 a meio de um carácter');
  }
  throw new RangeError('offset UTF-8 fora dos limites');
}
