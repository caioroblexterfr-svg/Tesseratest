import { createWindowedView } from './view.js';
import { createLineSource, toByteEdit } from './edit-adapter.js';
import { createEditorController } from './editor-controller.js';
import { attachEditor } from './editor-input.js';

// Verificações de arranque: isolamento, Trusted Types, Worker/OPFS e canal com o preview.
const list = document.getElementById('status');

function row(label, value, ok) {
  const li = document.createElement('li');
  if (ok === true) li.className = 'ok';
  if (ok === false) li.className = 'bad';
  li.textContent = `${label}: ${value}`;
  list.appendChild(li);
}

row('crossOriginIsolated', String(window.crossOriginIsolated), window.crossOriginIsolated === true);

// Trusted Types: atribuir string a innerHTML tem de lançar TypeError.
try {
  document.createElement('div').innerHTML = 'x';
  row('Trusted Types (innerHTML com string)', 'NÃO bloqueado', false);
} catch (e) {
  row('Trusted Types (innerHTML com string)', `bloqueado (${e.name})`, true);
}

// Política de Workers: só scripts da mesma origem em /workspace/assets/.
const workerPolicy = window.trustedTypes?.createPolicy('tessera-worker', {
  createScriptURL(input) {
    const url = new URL(input, location.href);
    if (url.origin !== location.origin || !url.pathname.startsWith('/workspace/assets/')) {
      throw new TypeError('URL de Worker não permitido');
    }
    return url.href;
  },
});

const workerUrl = '/workspace/assets/core.worker.js';
const worker = new Worker(workerPolicy ? workerPolicy.createScriptURL(workerUrl) : workerUrl, { type: 'module' });

let nextId = 1;
const pending = new Map();
const call = (op, args = {}) =>
  new Promise((resolve, reject) => {
    const id = nextId++;
    pending.set(id, { resolve, reject });
    worker.postMessage({ id, op, ...args });
  });

worker.addEventListener('message', async (ev) => {
  const d = ev.data;
  if (d?.type === 'ready') {
    row('Armazenamento local', d.storage, d.storage === 'opfs' ? true : undefined);
    row('Núcleo tessera-core', d.core, d.core === 'wasm' ? true : undefined);
    await workspaceDemo(); // JS puro: funciona mesmo sem o WASM compilado
    if (d.core === 'wasm') { await smokeTest(); await viewerDemo(); }
    return;
  }
  const p = pending.get(d?.id);
  if (!p) return;
  pending.delete(d.id);
  d.ok ? p.resolve(d.result) : p.reject(new Error(d.error));
});
worker.addEventListener('error', () => row('Worker', 'erro ao arrancar', false));

// Teste de fumo idempotente do WorkspaceGraph (árvore móvel): garante /demo/{a,b}, alterna o ficheiro
// nota.txt entre as duas pastas a cada arranque (prova que `move` persiste) e tenta um ciclo.
async function workspaceDemo() {
  try {
    const ensure = async (parentPath, name, kind) => {
      const path = `${parentPath === '/' ? '' : parentPath}/${name}`;
      const found = await call('ws.resolve', { path });
      if (found) return found;
      const parentId = await call('ws.resolve', { path: parentPath });
      return (await call('ws.create', { parentId, name, kind })).id;
    };
    const demo = await ensure('/', 'demo', 'dir');
    const a = await ensure('/demo', 'a', 'dir');
    const b = await ensure('/demo', 'b', 'dir');
    const note = (await call('ws.resolve', { path: '/demo/a/nota.txt' }))
      ?? (await call('ws.resolve', { path: '/demo/b/nota.txt' }))
      ?? (await call('ws.create', { parentId: a, name: 'nota.txt' })).id;
    const before = await call('ws.path', { nodeId: note });
    await call('ws.move', { nodeId: note, parentId: before.startsWith('/demo/a/') ? b : a });
    const after = await call('ws.path', { nodeId: note });
    let cycle = 'NÃO rejeitado';
    try { await call('ws.move', { nodeId: demo, parentId: a }); } catch { cycle = 'rejeitado'; }
    await call('ws.flush');
    row('WorkspaceGraph (árvore móvel)', `${before} → ${after}; mover /demo para dentro de si: ${cycle}`, before !== after && cycle === 'rejeitado');
  } catch (err) {
    row('WorkspaceGraph (árvore móvel)', err.message, false);
  }
}

// Teste de fumo idempotente do núcleo (usa o documento "smoke").
async function smokeTest() {
  try {
    await call('open', { docId: 'smoke', text: '' });
    await call('replace', { docId: 'smoke', start: 0, end: (await call('open', { docId: 'smoke' })).len, text: 'olá\nmundo' });
    const slice = await call('slice', { docId: 'smoke', start: 5, end: 10 });
    const point = await call('offsetToPoint', { docId: 'smoke', offset: 8 });
    const back = await call('pointToOffset', { docId: 'smoke', row: point.row, column: point.column });
    const saved = await call('flush');
    row('Rope (WASM)', `slice="${slice}", offset 8 → ${point.row}:${point.column} → ${back}, gravados=${saved.saved}`,
      slice === 'mundo' && back === 8);
  } catch (err) {
    row('Rope (WASM)', err.message, false);
  }
}

// 1) Adaptador UTF-16 → UTF-8 (documento descartável, resultado determinístico).
// 2) Documento grande (50 000 linhas) editável numa vista virtualizada.
async function viewerDemo() {
  try {
    const probe = await call('open', { docId: 'smoke-utf', text: '' });
    await call('replace', { docId: 'smoke-utf', start: 0, end: probe.len, text: 'olá\na😀b' });
    const source = createLineSource(call, 'smoke-utf');
    const edit = await toByteEdit(source, { startRow: 1, startCol: 1, endRow: 1, endCol: 3, text: '' });
    const picked = await call('slice', { docId: 'smoke-utf', start: edit.start, end: edit.end });
    row('Adaptador UTF-16 → UTF-8', `😀 → bytes ${edit.start}..${edit.end}`, picked === '😀');

    const text = Array.from({ length: 50_000 }, (_, i) => `linha ${i + 1} — olá 日本 😀`).join('\n');
    await call('open', { docId: 'demo-grande', text }); // se já existir, restaura a versão gravada
    const controller = createEditorController({ call, docId: 'demo-grande' });
    await controller.init();
    const view = createWindowedView({
      container: document.getElementById('viewer'),
      getLineCount: () => controller.lineCount(),
      getLines: (start, end) => call('lines', { docId: 'demo-grande', startRow: start, endRow: end }),
    });
    attachEditor({ container: document.getElementById('viewer'), controller, view });
    row('Editor', `${controller.lineCount()} linhas — clique/arraste na vista e escreva (setas, Backspace, Delete, Enter, colar, copiar/cortar, Ctrl+Z)`);
  } catch (err) {
    row('Editor', err.message, false);
  }
}

// Canal com o preview: o iframe sandbox (sem allow-same-origin) tem origem opaca ("null"),
// por isso validamos a janela de origem (event.source) e o valor "null", não um URL.
const frame = document.getElementById('preview');
window.addEventListener('message', (ev) => {
  if (ev.source !== frame.contentWindow || ev.origin !== 'null') return;
  const d = ev.data;
  if (!d || d.type !== 'console' || typeof d.text !== 'string') return;
  row(`preview › ${String(d.level).slice(0, 10)}`, d.text.slice(0, 200), d.text.includes('bloqueado'));
});
