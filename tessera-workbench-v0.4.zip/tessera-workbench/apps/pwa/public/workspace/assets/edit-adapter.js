// Traduz edições expressas em (linha, coluna UTF-16) — o que o DOM conhece — para
// pedidos { start, end, text } em bytes UTF-8 — o que o núcleo espera.
import { utf16ToUtf8 } from './text-units.js';

/**
 * Fonte de linhas apoiada no protocolo do Worker.
 * @param {(op: string, args?: object) => Promise<any>} call
 */
export function createLineSource(call, docId) {
  return {
    async lineAt(row) {
      const [text] = await call('lines', { docId, startRow: row, endRow: row + 1 });
      if (text === undefined) throw new RangeError('linha inexistente');
      return text;
    },
    rowStart: (row) => call('pointToOffset', { docId, row, column: 0 }),
  };
}

async function toOffset(source, row, col16) {
  const [text, start] = await Promise.all([source.lineAt(row), source.rowStart(row)]);
  return start + utf16ToUtf8(text, col16);
}

/**
 * @param {{ lineAt(row): Promise<string>, rowStart(row): Promise<number> }} source
 * @param {{ startRow: number, startCol: number, endRow: number, endCol: number, text: string }} edit
 *   Colunas em unidades UTF-16 (como `Selection`/`StaticRange` do DOM).
 * @returns {Promise<{ start: number, end: number, text: string }>} offsets em bytes UTF-8
 */
export async function toByteEdit(source, { startRow, startCol, endRow, endCol, text }) {
  if (startRow > endRow || (startRow === endRow && startCol > endCol)) {
    throw new RangeError('intervalo invertido');
  }
  const [start, end] = await Promise.all([
    toOffset(source, startRow, startCol),
    toOffset(source, endRow, endCol),
  ]);
  return { start, end, text };
}
