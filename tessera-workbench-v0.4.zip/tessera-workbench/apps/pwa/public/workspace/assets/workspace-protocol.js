// Protocolo do WorkspaceGraph no Worker: operações `ws.*`. Sem dependências do navegador → testável em Node.
// Pedido:   { id, op: 'ws.…', ...args }      Resposta: { id, ok: true, result } | { id, ok: false, error }
// `id` é só o número do pedido (correlação): os nós identificam-se por `nodeId` (como os documentos, por `docId`).
//
// O grafo é carregado (e validado) na primeira operação. A persistência é o registo de operações em JSON
// `{ v: 1, ops }`, gravado na chave reservada `__workspace__` (o prefixo `__` está vedado a documentos
// em protocol.js). Um registo corrompido NÃO é descartado em silêncio: as operações falham com erro.
import { createWorkspaceGraph, ROOT } from './workspace-graph.js';

export const WORKSPACE_STORE_ID = '__workspace__';
const MAX_IMPORT_OPS = 200_000;

/**
 * @param {{ store: { load(id): Promise<string|null>, save(id, text): Promise<void> }, replicaId: string }} deps
 */
export function createWorkspaceHandler({ store, replicaId }) {
  let graph = null;
  let loading = null;
  let dirty = false;

  async function load() {
    const g = createWorkspaceGraph({ replicaId });
    const saved = await store.load(WORKSPACE_STORE_ID);
    if (saved !== null) {
      let data;
      try {
        data = JSON.parse(saved);
      } catch {
        throw new Error('registo do espaço de trabalho ilegível (JSON inválido)');
      }
      if (data?.v !== 1 || !Array.isArray(data.ops)) throw new Error('registo do espaço de trabalho com formato desconhecido');
      const r = g.importOps(data.ops);
      if (r.rejected.length) throw new Error(`registo do espaço de trabalho corrompido (${r.rejected.length} operações inválidas)`);
    }
    return g;
  }

  async function ready() {
    if (graph) return graph;
    loading ??= load().then(
      (g) => (graph = g),
      (err) => { loading = null; throw err; }, // permite nova tentativa depois de reparar o registo
    );
    return loading;
  }

  const ops = {
    async 'ws.create'({ parentId, name, kind }) {
      const g = await ready();
      const { id } = g.create({ parentId: parentId ?? ROOT, name, kind: kind ?? 'file' });
      dirty = true;
      return { id };
    },
    async 'ws.move'({ nodeId, parentId, name }) {
      const op = (await ready()).move(nodeId, parentId, name ?? undefined);
      if (op) dirty = true;
      return { moved: op !== null };
    },
    async 'ws.rename'({ nodeId, name }) {
      const op = (await ready()).rename(nodeId, name);
      if (op) dirty = true;
      return { renamed: op !== null };
    },
    async 'ws.remove'({ nodeId }) {
      (await ready()).remove(nodeId);
      dirty = true;
      return { removed: true };
    },
    async 'ws.children'({ nodeId }) { return (await ready()).children(nodeId ?? ROOT); },
    async 'ws.get'({ nodeId }) { return (await ready()).get(nodeId); },
    async 'ws.path'({ nodeId }) { return (await ready()).pathOf(nodeId); },
    async 'ws.resolve'({ path }) { return (await ready()).resolve(path); },
    async 'ws.export'() { return { ops: (await ready()).exportOps() }; },
    async 'ws.import'({ ops: incoming }) {
      if (!Array.isArray(incoming) || incoming.length > MAX_IMPORT_OPS) throw new RangeError('ops inválidas');
      const r = (await ready()).importOps(incoming);
      if (r.applied > 0) dirty = true;
      return { applied: r.applied, duplicates: r.duplicates, rejectedCount: r.rejected.length, rejected: r.rejected.slice(0, 10) };
    },
    async 'ws.flush'() {
      if (!graph || !dirty) return { saved: false };
      dirty = false;
      try {
        await store.save(WORKSPACE_STORE_ID, JSON.stringify({ v: 1, ops: graph.exportOps() }));
      } catch (err) {
        dirty = true;
        throw err;
      }
      return { saved: true };
    },
  };

  async function handle(msg) {
    const id = msg?.id;
    try {
      const fn = Object.hasOwn(ops, msg?.op) ? ops[msg.op] : null;
      if (!fn) throw new TypeError('operação desconhecida');
      return { id, ok: true, result: await fn(msg) };
    } catch (err) {
      return { id, ok: false, error: String(err?.message ?? err) };
    }
  }

  return { handle, isDirty: () => dirty };
}
