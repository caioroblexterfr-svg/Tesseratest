// Controlador de edição: seleção + operações de edição/movimento, sem DOM.
// Posições são (linha, coluna UTF-16), como no DOM; as edições passam por toByteEdit → `replace`.
// Todas as operações públicas são serializadas (uma de cada vez, pela ordem de chamada).
// Inclui histórico local (undo/redo com agrupamento de escrita contínua) e texto da seleção (copiar/cortar).
// Limitações v0.3: palavras segundo UAX #29 (Intl.Segmenter), sem regras por linguagem de programação; o histórico é só desta
// sessão e do cliente (o undo apoiado no CRDT, por autor, chega com o Loro — ver ROADMAP).
import { createLineSource, toByteEdit } from './edit-adapter.js';
import {
  backspaceBoundary, nextBoundary, prevBoundary, snapBoundary, wordLeft, wordRight, wordRangeAt,
} from './text-boundaries.js';

// Movimento por grapheme cluster (setas, Delete, cliques); Backspace apaga emoji compostos por inteiro
// e só o último ponto de código em acentos combinados; Ctrl/Alt+setas movem por palavra.
const prevCol = prevBoundary;
const nextCol = nextBoundary;
const snapCol = snapBoundary;
const cmp = (a, b) => a.row - b.row || a.col - b.col;
/** Posição final de `text` inserido em `start` (colunas UTF-16). */
const endOf = (start, text) => {
  const parts = text.split('\n');
  return parts.length === 1
    ? { row: start.row, col: start.col + text.length }
    : { row: start.row + parts.length - 1, col: parts[parts.length - 1].length };
};
const MAX_HISTORY = 1000;

/** @param {{ call: (op: string, args?: object) => Promise<any>, docId: string }} deps */
export function createEditorController({ call, docId }) {
  const source = createLineSource(call, docId);
  let lineCount = 1;
  let anchor = { row: 0, col: 0 };
  let head = { row: 0, col: 0 };
  let goalCol = null; // coluna preferida em movimentos verticais
  let queue = Promise.resolve();
  const undoStack = [];
  let redoStack = [];
  let canMerge = false; // a próxima edição pode fundir-se com a última entrada?

  const serial = (fn) => {
    const p = queue.then(fn);
    queue = p.catch(() => {});
    return p;
  };
  const hasSel = () => cmp(anchor, head) !== 0;
  const sel = () => (cmp(anchor, head) <= 0 ? { start: anchor, end: head } : { start: head, end: anchor });

  /** Substitui [start,end) por text; não mexe na seleção nem no histórico. */
  async function rawReplace(start, end, text) {
    const byteEdit = await toByteEdit(source, {
      startRow: start.row, startCol: start.col, endRow: end.row, endCol: end.col, text,
    });
    lineCount = (await call('replace', { docId, ...byteEdit })).lines;
  }

  /** Texto entre duas posições (start <= end). */
  async function getText(start, end) {
    if (cmp(start, end) === 0) return '';
    const lines = await call('lines', { docId, startRow: start.row, endRow: end.row + 1 });
    if (lines.length === 0) return '';
    if (start.row === end.row) return lines[0].slice(start.col, end.col);
    lines[0] = lines[0].slice(start.col);
    lines[lines.length - 1] = lines[lines.length - 1].slice(0, end.col);
    return lines.join('\n');
  }

  function record(entry) {
    const last = undoStack[undoStack.length - 1];
    redoStack = [];
    if (canMerge && last && last.kind === entry.kind) {
      if (entry.kind === 'type' && cmp(endOf(last.start, last.inserted), entry.start) === 0) {
        last.inserted += entry.inserted;
        last.after = entry.after;
        return;
      }
      if (entry.kind === 'backspace' && cmp(entry.end, last.start) === 0) {
        last.start = entry.start;
        last.removed = entry.removed + last.removed;
        last.after = entry.after;
        return;
      }
      if (entry.kind === 'delete' && cmp(entry.start, last.start) === 0) {
        last.removed += entry.removed;
        last.after = entry.after;
        return;
      }
    }
    undoStack.push(entry);
    if (undoStack.length > MAX_HISTORY) undoStack.shift();
    canMerge = true;
  }

  async function applyEdit(start, end, text, kind = 'edit') {
    const before = { anchor: { ...anchor }, head: { ...head } };
    const removed = await getText(start, end);
    await rawReplace(start, end, text);
    const caret = endOf(start, text);
    anchor = { ...caret };
    head = { ...caret };
    goalCol = null;
    record({
      kind, start: { ...start }, end: { ...end }, removed, inserted: text, before,
      after: { anchor: { ...caret }, head: { ...caret } },
    });
  }

  const boundary = () => { canMerge = false; };

  async function insertText(text) {
    text = String(text).replace(/\r\n?/g, '\n');
    if (text === '' && !hasSel()) return;
    const { start, end } = sel();
    const typing = !hasSel() && !text.includes('\n');
    await applyEdit(start, end, text, typing ? 'type' : 'edit');
  }

  async function deleteBackward() {
    if (hasSel()) { const { start, end } = sel(); return applyEdit(start, end, ''); }
    const { row, col } = head;
    if (col > 0) {
      const line = await source.lineAt(row);
      return applyEdit({ row, col: backspaceBoundary(line, col) }, head, '', 'backspace');
    }
    if (row > 0) {
      const prev = await source.lineAt(row - 1);
      return applyEdit({ row: row - 1, col: prev.length }, { row, col: 0 }, '', 'backspace');
    }
  }

  async function deleteForward() {
    if (hasSel()) { const { start, end } = sel(); return applyEdit(start, end, ''); }
    const { row, col } = head;
    const line = await source.lineAt(row);
    if (col < line.length) return applyEdit(head, { row, col: nextCol(line, col) }, '', 'delete');
    if (row < lineCount - 1) return applyEdit(head, { row: row + 1, col: 0 }, '', 'delete');
  }

  async function deleteWordBackward() {
    if (hasSel()) { const { start, end } = sel(); return applyEdit(start, end, '', 'edit'); }
    const { row, col } = head;
    if (col > 0) {
      const line = await source.lineAt(row);
      return applyEdit({ row, col: wordLeft(line, col) }, head, '', 'edit');
    }
    return deleteBackward(); // início da linha: junta com a anterior
  }

  async function deleteWordForward() {
    if (hasSel()) { const { start, end } = sel(); return applyEdit(start, end, '', 'edit'); }
    const { row, col } = head;
    const line = await source.lineAt(row);
    if (col < line.length) return applyEdit(head, { row, col: wordRight(line, col) }, '', 'edit');
    return deleteForward(); // fim da linha: junta com a seguinte
  }

  async function move(dir, extend = false) {
    boundary();
    if (!extend && hasSel() && (dir === 'left' || dir === 'right')) {
      const s = sel();
      head = { ...(dir === 'left' ? s.start : s.end) };
      anchor = { ...head };
      goalCol = null;
      return;
    }
    let { row, col } = head;
    const line = await source.lineAt(row);
    switch (dir) {
      case 'left':
        if (col > 0) col = prevCol(line, col);
        else if (row > 0) { row--; col = (await source.lineAt(row)).length; }
        goalCol = null;
        break;
      case 'right':
        if (col < line.length) col = nextCol(line, col);
        else if (row < lineCount - 1) { row++; col = 0; }
        goalCol = null;
        break;
      case 'up':
      case 'down': {
        const target = dir === 'up' ? row - 1 : row + 1;
        if (target < 0) { row = 0; col = 0; goalCol = null; }
        else if (target >= lineCount) { row = lineCount - 1; col = (await source.lineAt(row)).length; goalCol = null; }
        else {
          goalCol ??= col;
          row = target;
          col = snapCol(await source.lineAt(row), goalCol);
        }
        break;
      }
      case 'wordLeft':
        if (col > 0) col = wordLeft(line, col);
        else if (row > 0) { row--; col = (await source.lineAt(row)).length; }
        goalCol = null;
        break;
      case 'wordRight':
        if (col < line.length) col = wordRight(line, col);
        else if (row < lineCount - 1) { row++; col = 0; }
        goalCol = null;
        break;
      case 'docStart': row = 0; col = 0; goalCol = null; break;
      case 'docEnd': row = lineCount - 1; col = (await source.lineAt(row)).length; goalCol = null; break;
      case 'home': col = 0; goalCol = null; break;
      case 'end': col = line.length; goalCol = null; break;
      default: throw new TypeError('direção desconhecida');
    }
    head = { row, col };
    if (!extend) anchor = { ...head };
  }

  async function setCaret(row, col, extend = false) {
    boundary();
    row = Math.max(0, Math.min(row, lineCount - 1));
    col = snapCol(await source.lineAt(row), col);
    head = { row, col };
    if (!extend) anchor = { ...head };
    goalCol = null;
  }

  async function selectWordAt(row, col) {
    boundary();
    row = Math.max(0, Math.min(row, lineCount - 1));
    const line = await source.lineAt(row);
    const { start, end } = wordRangeAt(line, snapCol(line, col));
    anchor = { row, col: start };
    head = { row, col: end };
    goalCol = null;
  }

  async function selectLineAt(row) {
    boundary();
    row = Math.max(0, Math.min(row, lineCount - 1));
    anchor = { row, col: 0 };
    head = row < lineCount - 1 ? { row: row + 1, col: 0 } : { row, col: (await source.lineAt(row)).length };
    goalCol = null;
  }

  async function selectAll() {
    boundary();
    const last = lineCount - 1;
    anchor = { row: 0, col: 0 };
    head = { row: last, col: (await source.lineAt(last)).length };
    goalCol = null;
  }

  async function getSelectedText() {
    if (!hasSel()) return '';
    const { start, end } = sel();
    return getText(start, end);
  }

  async function cut() {
    const text = await getSelectedText();
    if (text !== '') { const { start, end } = sel(); await applyEdit(start, end, '', 'edit'); }
    return text;
  }

  async function undo() {
    boundary();
    const e = undoStack.pop();
    if (!e) return false;
    await rawReplace(e.start, endOf(e.start, e.inserted), e.removed);
    anchor = { ...e.before.anchor };
    head = { ...e.before.head };
    goalCol = null;
    redoStack.push(e);
    return true;
  }

  async function redo() {
    boundary();
    const e = redoStack.pop();
    if (!e) return false;
    await rawReplace(e.start, endOf(e.start, e.removed), e.inserted);
    anchor = { ...e.after.anchor };
    head = { ...e.after.head };
    goalCol = null;
    undoStack.push(e);
    return true;
  }

  return {
    init: () => serial(async () => { lineCount = (await call('open', { docId })).lines; }),
    insertText: (t) => serial(() => insertText(t)),
    insertLineBreak: () => serial(() => insertText('\n')),
    deleteBackward: () => serial(deleteBackward),
    deleteForward: () => serial(deleteForward),
    move: (dir, extend) => serial(() => move(dir, extend)),
    setCaret: (r, c, extend) => serial(() => setCaret(r, c, extend)),
    selectAll: () => serial(selectAll),
    selectWordAt: (r, c) => serial(() => selectWordAt(r, c)),
    selectLineAt: (r) => serial(() => selectLineAt(r)),
    deleteWordBackward: () => serial(deleteWordBackward),
    deleteWordForward: () => serial(deleteWordForward),
    getSelectedText: () => serial(getSelectedText),
    cut: () => serial(cut),
    undo: () => serial(undo),
    redo: () => serial(redo),
    canUndo: () => undoStack.length > 0,
    canRedo: () => redoStack.length > 0,
    getSelection: () => ({ anchor: { ...anchor }, head: { ...head } }),
    lineCount: () => lineCount,
  };
}
