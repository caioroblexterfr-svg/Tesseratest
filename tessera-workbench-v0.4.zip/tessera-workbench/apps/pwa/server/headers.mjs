// Matriz normativa de cabeçalhos (docs/SECURITY.md §3.4) como funções puras e testáveis.
import { randomBytes } from 'node:crypto';

export const newNonce = () => randomBytes(16).toString('base64');

const join = (parts) => parts.filter(Boolean).join('; ');

/**
 * Aplicação principal: /workspace/*
 * Desvios face à matriz do SECURITY.md (a validar em navegador real):
 *  - `frame-src <previewOrigin>`: sem isto, `default-src 'self'` bloqueia o iframe de preview.
 *  - `worker-src 'self'`: não depender de 'strict-dynamic' para Workers dedicados.
 *  - `upgrade-insecure-requests` só fora de dev (em http://localhost causaria upgrades indevidos).
 */
export function workspaceHeaders(nonce, { dev = false, previewOrigin = '' } = {}) {
  return {
    'Content-Security-Policy': join([
      "default-src 'self'",
      `script-src 'nonce-${nonce}' 'strict-dynamic' 'wasm-unsafe-eval'`,
      "worker-src 'self'",
      previewOrigin ? `frame-src ${previewOrigin}` : "frame-src 'none'",
      "object-src 'none'",
      "base-uri 'none'",
      dev ? '' : 'upgrade-insecure-requests',
      "require-trusted-types-for 'script'",
      'trusted-types tessera-sanitize tessera-worker',
    ]),
    'Cross-Origin-Opener-Policy': 'same-origin',
    'Cross-Origin-Embedder-Policy': 'credentialless',
    'Cross-Origin-Resource-Policy': 'same-origin',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Cache-Control': 'no-store',
  };
}

/**
 * Ativos estáticos de /workspace/assets/* (scripts, Workers, CSS, WASM).
 * A CSP da resposta do script do Worker governa o próprio Worker (a validar em navegadores).
 */
export function assetHeaders() {
  return {
    'Content-Security-Policy':
      "default-src 'none'; script-src 'self' 'wasm-unsafe-eval'; connect-src 'self'; base-uri 'none'",
    'Cross-Origin-Embedder-Policy': 'credentialless',
    'Cross-Origin-Resource-Policy': 'same-origin',
    'X-Content-Type-Options': 'nosniff',
  };
}

/** Rotas /auth/*: sem COEP e sem COOP restritivo, para não quebrar o fluxo OAuth. */
export function authHeaders(nonce, { dev = false } = {}) {
  return {
    'Content-Security-Policy': join([
      "default-src 'self'",
      `script-src 'nonce-${nonce}' 'strict-dynamic'`,
      "object-src 'none'",
      "base-uri 'none'",
      dev ? '' : 'upgrade-insecure-requests',
    ]),
    'Cross-Origin-Resource-Policy': 'same-origin',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Cache-Control': 'no-store',
  };
}

/**
 * Origem de pré-visualização (domínio separado, sem cookies da app).
 * Desvio face à matriz: COEP `credentialless` + CORP `cross-origin`, porque um documento
 * com COEP não consegue incorporar um iframe cross-origin que não opte por COEP/CORP.
 */
export function previewHeaders(nonce) {
  return {
    'Content-Security-Policy': join([
      "default-src 'none'",
      `script-src 'nonce-${nonce}'`,
      "base-uri 'none'",
    ]),
    'Cross-Origin-Opener-Policy': 'same-origin',
    'Cross-Origin-Embedder-Policy': 'credentialless',
    'Cross-Origin-Resource-Policy': 'cross-origin',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Cache-Control': 'no-store',
  };
}
