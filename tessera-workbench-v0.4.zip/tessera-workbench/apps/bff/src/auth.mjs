// BFF OAuth 2.1 (cliente confidencial): Authorization Code + PKCE (S256), state ligado ao
// navegador, tokens APENAS no servidor, cookie de sessão opaco HttpOnly.
// Pendente (Fase 3): DPoP (RFC 9449), session store persistente, rotação/refresh, proxy /api/*.
import { randomBytes, createHash } from 'node:crypto';

const b64url = (buf) => buf.toString('base64url');

export function createPkce() {
  const verifier = b64url(randomBytes(32));
  const challenge = b64url(createHash('sha256').update(verifier).digest());
  return { verifier, challenge };
}

export function parseCookies(header = '') {
  const out = {};
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

/**
 * @param {object} cfg
 * @param {string} [cfg.authorizeUrl] @param {string} [cfg.tokenUrl]
 * @param {string} [cfg.clientId] @param {string} [cfg.clientSecret]
 * @param {string} [cfg.redirectUri] @param {string} [cfg.scope]
 * @param {boolean} [cfg.secureCookies=true]
 * @param {string} [cfg.postLoginPath='/workspace/']
 */
export function createAuth(cfg) {
  const secure = cfg.secureCookies !== false;
  const SID = secure ? '__Host-tessera_sid' : 'tessera_sid';
  const PRE = secure ? '__Host-tessera_oauth' : 'tessera_oauth';
  const pending = new Map(); // state -> { verifier, createdAt }
  const sessions = new Map(); // sid -> { tokens, createdAt }
  const configured = Boolean(cfg.authorizeUrl && cfg.tokenUrl && cfg.clientId && cfg.redirectUri);

  const cookie = (name, value, maxAge) =>
    `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}` +
    (secure ? '; Secure' : '');

  const text = (res, status, body, extra = {}) => {
    res.writeHead(status, { 'Content-Type': 'text/plain; charset=utf-8', ...extra });
    res.end(body);
  };

  async function login(req, res) {
    if (!configured) return text(res, 503, 'OAuth não configurado');
    const state = b64url(randomBytes(24));
    const { verifier, challenge } = createPkce();
    pending.set(state, { verifier, createdAt: Date.now() });
    const u = new URL(cfg.authorizeUrl);
    u.search = new URLSearchParams({
      response_type: 'code',
      client_id: cfg.clientId,
      redirect_uri: cfg.redirectUri,
      scope: cfg.scope ?? 'openid',
      state,
      code_challenge: challenge,
      code_challenge_method: 'S256',
    }).toString();
    res.writeHead(303, { Location: u.toString(), 'Set-Cookie': cookie(PRE, state, 600) });
    res.end();
  }

  async function callback(req, res, url) {
    const state = url.searchParams.get('state');
    const code = url.searchParams.get('code');
    const bound = parseCookies(req.headers.cookie)[PRE];
    const entry = state && pending.get(state);
    if (!entry || !code || bound !== state || Date.now() - entry.createdAt > 10 * 60_000) {
      return text(res, 400, 'Pedido de autorização inválido');
    }
    pending.delete(state); // uso único
    const resp = await fetch(cfg.tokenUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        redirect_uri: cfg.redirectUri,
        client_id: cfg.clientId,
        client_secret: cfg.clientSecret ?? '',
        code_verifier: entry.verifier,
      }),
    });
    if (!resp.ok) return text(res, 502, 'Falha na troca do código');
    const tokens = await resp.json();
    const sid = b64url(randomBytes(32));
    sessions.set(sid, { tokens, createdAt: Date.now() });
    res.writeHead(303, {
      Location: cfg.postLoginPath ?? '/workspace/',
      'Set-Cookie': [cookie(SID, sid, 8 * 3600), cookie(PRE, '', 0)],
    });
    res.end();
  }

  function session(req, res) {
    const sid = parseCookies(req.headers.cookie)[SID];
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ authenticated: Boolean(sid && sessions.has(sid)) })); // nunca tokens
  }

  function logout(req, res) {
    const site = req.headers['sec-fetch-site'];
    if (req.method !== 'POST' || (site && site !== 'same-origin')) return text(res, 403, 'Proibido');
    const sid = parseCookies(req.headers.cookie)[SID];
    if (sid) sessions.delete(sid);
    res.writeHead(204, { 'Set-Cookie': cookie(SID, '', 0) });
    res.end();
  }

  /** Devolve true se tratou o pedido. */
  async function handle(req, res, url) {
    try {
      if (req.method === 'GET' && url.pathname === '/auth/login') return await login(req, res), true;
      if (req.method === 'GET' && url.pathname === '/auth/callback') return await callback(req, res, url), true;
      if (req.method === 'GET' && url.pathname === '/auth/session') return session(req, res), true;
      if (url.pathname === '/auth/logout') return logout(req, res), true;
    } catch {
      text(res, 500, 'Erro interno de autenticação');
      return true;
    }
    return false;
  }

  return { handle, _pending: pending, _sessions: sessions };
}
