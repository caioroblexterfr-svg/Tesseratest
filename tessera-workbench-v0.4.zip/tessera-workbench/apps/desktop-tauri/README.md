# apps/desktop-tauri

Reservado para a **Fase 4**: *companion* nativo opcional (Tauri v2) para compiladores locais,
LSPs nativos e `tessera-sandbox` local. Atualizador assinado obrigatório.
Ver docs/ARCHITECTURE.md §7 (ADR-004).
