// Página de demonstração servida pela origem de preview (sem cookies da aplicação).
export function previewPage(nonce) {
  return `<!doctype html>
<html lang="pt"><head><meta charset="utf-8"><title>Preview</title></head>
<body>
<p>Preview isolado.</p>
<script nonce="${nonce}">
  let parentDom;
  try { parentDom = top.document.body ? 'ACESSÍVEL (falha!)' : 'vazio'; }
  catch (e) { parentDom = 'bloqueado (' + e.name + ')'; }
  parent.postMessage({ type: 'console', level: 'log', text: 'olá do preview; DOM do pai: ' + parentDom }, '*');
</script>
</body></html>`;
}
