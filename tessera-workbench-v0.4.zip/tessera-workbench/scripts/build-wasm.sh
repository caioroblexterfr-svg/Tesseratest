#!/usr/bin/env bash
# Compila tessera-wasm e gera a ligação JS para o Worker.
# Requisitos: rustup target add wasm32-unknown-unknown ; cargo install wasm-bindgen-cli
# (a versão do CLI tem de coincidir com a do crate `wasm-bindgen` em Cargo.lock).
set -euo pipefail
cd "$(dirname "$0")/.."
cargo build -p tessera-wasm --release --target wasm32-unknown-unknown
wasm-bindgen --target web --no-typescript \
  --out-dir apps/pwa/public/workspace/assets --out-name tessera_wasm \
  target/wasm32-unknown-unknown/release/tessera_wasm.wasm
echo "OK → apps/pwa/public/workspace/assets/tessera_wasm{.js,_bg.wasm}"
