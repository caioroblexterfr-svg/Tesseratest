// Servidor de desenvolvimento: app (8080) + origem de preview separada (8081).
// Uso: npm run dev   →   http://localhost:8080/workspace/
import http from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { newNonce, workspaceHeaders, assetHeaders, authHeaders, previewHeaders } from '../apps/pwa/server/headers.mjs';
import { createAuth } from '../apps/bff/src/auth.mjs';
import { previewPage } from '../apps/preview-gateway/src/page.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const publicDir = path.join(root, 'apps/pwa/public/workspace');
const APP_PORT = Number(process.env.APP_PORT ?? 8080);
const PREVIEW_PORT = Number(process.env.PREVIEW_PORT ?? 8081);
const APP_ORIGIN = `http://localhost:${APP_PORT}`;
const PREVIEW_ORIGIN = `http://localhost:${PREVIEW_PORT}`;

const TYPES = {
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.wasm': 'application/wasm', // obrigatório para compileStreaming
};

const auth = createAuth({
  authorizeUrl: process.env.OAUTH_AUTHORIZE_URL,
  tokenUrl: process.env.OAUTH_TOKEN_URL,
  clientId: process.env.OAUTH_CLIENT_ID,
  clientSecret: process.env.OAUTH_CLIENT_SECRET,
  redirectUri: process.env.OAUTH_REDIRECT_URI ?? `${APP_ORIGIN}/auth/callback`,
  secureCookies: false, // só em dev (http); em produção: true
});

const app = http.createServer(async (req, res) => {
  const url = new URL(req.url, APP_ORIGIN);
  try {
    if (url.pathname === '/') {
      res.writeHead(302, { Location: '/workspace/' });
      return res.end();
    }

    if (url.pathname.startsWith('/auth/')) {
      const nonce = newNonce();
      for (const [k, v] of Object.entries(authHeaders(nonce, { dev: true }))) res.setHeader(k, v);
      if (await auth.handle(req, res, url)) return;
      res.writeHead(404);
      return res.end('Not found');
    }

    if (url.pathname === '/workspace' || url.pathname === '/workspace/') {
      const nonce = newNonce();
      const html = (await readFile(path.join(publicDir, 'index.html'), 'utf8'))
        .replaceAll('{{NONCE}}', nonce)
        .replaceAll('{{PREVIEW_URL}}', `${PREVIEW_ORIGIN}/preview/demo`);
      res.writeHead(200, {
        'Content-Type': 'text/html; charset=utf-8',
        ...workspaceHeaders(nonce, { dev: true, previewOrigin: PREVIEW_ORIGIN }),
      });
      return res.end(html);
    }

    const m = /^\/workspace\/assets\/([\w.-]+)$/.exec(url.pathname); // sem '/' nem '..'
    if (m) {
      const file = path.join(publicDir, 'assets', m[1]);
      const body = await readFile(file);
      res.writeHead(200, {
        'Content-Type': TYPES[path.extname(file)] ?? 'application/octet-stream',
        ...assetHeaders(),
      });
      return res.end(body);
    }

    res.writeHead(404);
    res.end('Not found');
  } catch (err) {
    res.writeHead(err?.code === 'ENOENT' ? 404 : 500);
    res.end(err?.code === 'ENOENT' ? 'Not found' : 'Erro interno');
  }
});

const preview = http.createServer((req, res) => {
  const url = new URL(req.url, PREVIEW_ORIGIN);
  if (url.pathname === '/preview/demo') {
    const nonce = newNonce();
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', ...previewHeaders(nonce) });
    return res.end(previewPage(nonce));
  }
  res.writeHead(404);
  res.end('Not found');
});

app.listen(APP_PORT, () => console.log(`app      ${APP_ORIGIN}/workspace/`));
preview.listen(PREVIEW_PORT, () => console.log(`preview  ${PREVIEW_ORIGIN}/preview/demo`));
