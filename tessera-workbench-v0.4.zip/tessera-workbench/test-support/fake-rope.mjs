// Rope falso com semântica de bytes UTF-8 (o real é o WasmRope), só para testes.
export class FakeRope {
  constructor(text) { this.buf = Buffer.from(text, 'utf8'); }
  len() { return this.buf.length; }
  lineCount() { return this.buf.toString().split('\n').length; }
  replace(s, e, t) {
    if (e > this.buf.length) throw new Error('intervalo fora dos limites');
    this.buf = Buffer.concat([this.buf.subarray(0, s), Buffer.from(t), this.buf.subarray(e)]);
  }
  slice(s, e) { return this.buf.subarray(s, e).toString(); }
  offsetToPoint(o) {
    const before = this.buf.subarray(0, o).toString();
    const row = before.split('\n').length - 1;
    return [row, Buffer.byteLength(before.slice(before.lastIndexOf('\n') + 1))];
  }
  pointToOffset(r, c) {
    const lines = this.buf.toString().split('\n');
    let off = 0;
    for (let i = 0; i < r && i < lines.length; i++) off += Buffer.byteLength(lines[i]) + 1;
    return Math.min(off + c, this.buf.length);
  }
  toText() { return this.buf.toString(); }
}
