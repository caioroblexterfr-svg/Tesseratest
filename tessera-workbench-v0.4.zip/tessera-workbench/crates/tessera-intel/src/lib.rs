//! tessera-intel — SCIP, regras estruturais (ast-grep) e auditoria de patches.
//!
//! Nesta versão só existe o contrato de auditoria ([`audit`]); os restantes
//! módulos entram na Fase 2 (ver docs/ROADMAP.md).

pub mod audit;
