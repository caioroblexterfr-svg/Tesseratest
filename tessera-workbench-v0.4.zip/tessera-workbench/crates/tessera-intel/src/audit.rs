//! `AuditPatchProposal`: invariantes de segurança sobre propostas de alteração.
//!
//! Regras (ver docs/ARCHITECTURE.md §12 e docs/SECURITY.md §6):
//! 1. Se o ast-grep detetar *novo* error-masking, **nenhuma** proposta é aplicada
//!    automaticamente (qualquer origem).
//! 2. Propostas de agentes MCP exigem aprovação HITL explícita.
//! 3. Alterações digitadas pelo humano não precisam de HITL (o humano é o revisor).

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Origin {
    Human,
    AstGrep,
    McpAgent,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct LintWarning {
    pub rule_id: String,
    pub message: String,
    /// `true` se a regra pertence à família anti-error-masking.
    pub is_error_masking: bool,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DenyReason {
    NewErrorMasking,
    MissingHitlApproval,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Verdict {
    Allow,
    Deny(DenyReason),
}

#[derive(Clone, Debug)]
pub struct AuditPatchProposal {
    pub origin: Origin,
    /// Diff sintático (difftastic) serializado.
    pub ast_diff: String,
    pub lint_warnings: Vec<LintWarning>,
    /// Símbolos SCIP reutilizados/afetados.
    pub scip_refs: Vec<String>,
    pub hitl_approved: bool,
}

impl AuditPatchProposal {
    pub fn can_auto_apply(&self) -> Verdict {
        if self.lint_warnings.iter().any(|w| w.is_error_masking) {
            return Verdict::Deny(DenyReason::NewErrorMasking);
        }
        if self.origin == Origin::McpAgent && !self.hitl_approved {
            return Verdict::Deny(DenyReason::MissingHitlApproval);
        }
        Verdict::Allow
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn proposal(origin: Origin, hitl: bool, masking: bool) -> AuditPatchProposal {
        let lint_warnings = if masking {
            vec![LintWarning {
                rule_id: "ts-empty-catch".into(),
                message: "catch vazio".into(),
                is_error_masking: true,
            }]
        } else {
            vec![]
        };
        AuditPatchProposal {
            origin,
            ast_diff: String::new(),
            lint_warnings,
            scip_refs: vec![],
            hitl_approved: hitl,
        }
    }

    #[test]
    fn agent_without_hitl_is_denied() {
        let p = proposal(Origin::McpAgent, false, false);
        assert_eq!(p.can_auto_apply(), Verdict::Deny(DenyReason::MissingHitlApproval));
    }

    #[test]
    fn agent_with_hitl_is_allowed() {
        assert_eq!(proposal(Origin::McpAgent, true, false).can_auto_apply(), Verdict::Allow);
    }

    #[test]
    fn error_masking_always_denied() {
        for origin in [Origin::Human, Origin::AstGrep, Origin::McpAgent] {
            let p = proposal(origin, true, true);
            assert_eq!(p.can_auto_apply(), Verdict::Deny(DenyReason::NewErrorMasking));
        }
    }

    #[test]
    fn human_edit_is_allowed() {
        assert_eq!(proposal(Origin::Human, false, false).can_auto_apply(), Verdict::Allow);
    }
}
