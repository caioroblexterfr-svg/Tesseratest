//! Ligação JS ↔ `tessera-core`.
//!
//! IMPORTANTE: todos os offsets são em **bytes UTF-8** (não em unidades UTF-16 de JS).
//! O adaptador de editor no Worker tem de converter. Offsets inválidos (fora do texto ou
//! a meio de um carácter) devolvem erro em vez de abortar o módulo WASM.

use tessera_core::{Point, Rope};
use wasm_bindgen::prelude::*;

#[wasm_bindgen]
pub struct WasmRope {
    inner: Rope,
}

fn check_range(rope: &Rope, start: usize, end: usize) -> Result<(), JsError> {
    if start > end || end > rope.len() {
        return Err(JsError::new("intervalo fora dos limites"));
    }
    if !rope.is_char_boundary(start) || !rope.is_char_boundary(end) {
        return Err(JsError::new("offset não está numa fronteira de carácter UTF-8"));
    }
    Ok(())
}

#[wasm_bindgen]
impl WasmRope {
    #[wasm_bindgen(constructor)]
    pub fn new(text: &str) -> WasmRope {
        WasmRope {
            inner: Rope::from(text),
        }
    }

    /// Comprimento em bytes UTF-8.
    #[allow(clippy::len_without_is_empty)]
    pub fn len(&self) -> usize {
        self.inner.len()
    }

    #[wasm_bindgen(js_name = lineCount)]
    pub fn line_count(&self) -> usize {
        self.inner.line_count()
    }

    pub fn replace(&mut self, start: usize, end: usize, text: &str) -> Result<(), JsError> {
        check_range(&self.inner, start, end)?;
        self.inner.replace(start..end, text);
        Ok(())
    }

    pub fn slice(&self, start: usize, end: usize) -> Result<String, JsError> {
        check_range(&self.inner, start, end)?;
        Ok(self.inner.slice(start..end))
    }

    /// Devolve `[linha, coluna]` (coluna em bytes).
    #[wasm_bindgen(js_name = offsetToPoint)]
    pub fn offset_to_point(&self, offset: usize) -> Result<Vec<u32>, JsError> {
        check_range(&self.inner, offset, offset)?;
        let p = self.inner.offset_to_point(offset);
        Ok(vec![p.row as u32, p.column as u32])
    }

    #[wasm_bindgen(js_name = pointToOffset)]
    pub fn point_to_offset(&self, row: usize, column: usize) -> usize {
        self.inner.point_to_offset(Point::new(row, column))
    }

    #[wasm_bindgen(js_name = toText)]
    pub fn to_text(&self) -> String {
        self.inner.to_string()
    }
}
