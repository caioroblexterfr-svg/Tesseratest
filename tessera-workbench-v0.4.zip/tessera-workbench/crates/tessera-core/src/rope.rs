//! Rope: texto armazenado como `SumTree<Chunk>`.
//!
//! * `clone()` é um snapshot O(1) (partilha estrutural).
//! * Conversão offset de bytes ↔ (linha, coluna em bytes) em O(log N).
//! * Todos os offsets são em **bytes** e têm de cair em fronteiras de carateres UTF-8
//!   (caso contrário, as operações entram em pânico).

use crate::sum_tree::{Bias, Item, SumTree, Summary};
use std::fmt;
use std::ops::Range;

const DEFAULT_MAX_CHUNK: usize = 512;
const MIN_MAX_CHUNK: usize = 4;

/// Posição linha/coluna (0-based; coluna em bytes dentro da linha).
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, PartialOrd, Ord)]
pub struct Point {
    pub row: usize,
    pub column: usize,
}

impl Point {
    pub fn new(row: usize, column: usize) -> Self {
        Self { row, column }
    }
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct TextSummary {
    pub len: usize,
    pub chars: usize,
    /// Número de '\n'.
    pub rows: usize,
    /// Bytes depois do último '\n' (ou o comprimento total se não houver '\n').
    pub last_col: usize,
}

impl TextSummary {
    pub fn of(text: &str) -> Self {
        let mut s = TextSummary {
            len: text.len(),
            chars: text.chars().count(),
            rows: 0,
            last_col: text.len(),
        };
        if let Some(p) = text.rfind('\n') {
            s.rows = text.bytes().filter(|&b| b == b'\n').count();
            s.last_col = text.len() - p - 1;
        }
        s
    }
}

impl Summary for TextSummary {
    fn add_summary(&mut self, other: &Self) {
        self.len += other.len;
        self.chars += other.chars;
        if other.rows > 0 {
            self.rows += other.rows;
            self.last_col = other.last_col;
        } else {
            self.last_col += other.last_col;
        }
    }
}

#[derive(Clone, Debug)]
pub struct Chunk {
    pub text: String,
}

impl Item for Chunk {
    type Summary = TextSummary;
    fn summary(&self) -> TextSummary {
        TextSummary::of(&self.text)
    }
}

fn split_text(text: &str, max: usize) -> Vec<Chunk> {
    let mut out = Vec::new();
    let mut i = 0;
    while i < text.len() {
        let mut j = (i + max).min(text.len());
        while !text.is_char_boundary(j) {
            j -= 1;
        }
        out.push(Chunk {
            text: text[i..j].to_string(),
        });
        i = j;
    }
    out
}

#[derive(Clone)]
pub struct Rope {
    tree: SumTree<Chunk>,
    max_chunk: usize,
}

impl Default for Rope {
    fn default() -> Self {
        Self::new()
    }
}

impl Rope {
    pub fn new() -> Self {
        Self::with_chunk_size(DEFAULT_MAX_CHUNK)
    }

    /// Tamanho máximo de cada chunk em bytes (mínimo 4). Útil em testes.
    pub fn with_chunk_size(max_chunk: usize) -> Self {
        assert!(max_chunk >= MIN_MAX_CHUNK, "chunk demasiado pequeno");
        Self {
            tree: SumTree::new(),
            max_chunk,
        }
    }

    pub fn from_str_with_chunk_size(text: &str, max_chunk: usize) -> Self {
        let mut rope = Self::with_chunk_size(max_chunk);
        rope.replace(0..0, text);
        rope
    }

    /// Comprimento em bytes.
    pub fn len(&self) -> usize {
        self.tree.summary().len
    }

    pub fn is_empty(&self) -> bool {
        self.len() == 0
    }

    /// Número de carateres Unicode.
    pub fn char_count(&self) -> usize {
        self.tree.summary().chars
    }

    /// Número de linhas (um texto vazio tem 1 linha).
    pub fn line_count(&self) -> usize {
        self.tree.summary().rows + 1
    }

    /// `true` se `offset` está dentro do texto e cai numa fronteira de carácter UTF-8.
    /// Use-o para validar offsets vindos de fora (ex.: JS) antes de editar/fatiar.
    pub fn is_char_boundary(&self, offset: usize) -> bool {
        if offset > self.len() {
            return false;
        }
        if offset == 0 || offset == self.len() {
            return true;
        }
        match self.tree.locate(|x| x.len, offset, Bias::Left) {
            None => false,
            Some(loc) => self
                .tree
                .get(loc.index)
                .map_or(false, |c| c.text.is_char_boundary(loc.remainder)),
        }
    }

    /// Substitui `range` (bytes) por `text`.
    pub fn replace(&mut self, range: Range<usize>, text: &str) {
        let (start, end) = (range.start, range.end);
        assert!(start <= end && end <= self.len(), "intervalo fora dos limites");

        if self.tree.is_empty() {
            let new = split_text(text, self.max_chunk);
            self.tree.replace(0, 0, &new);
            return;
        }

        let s = self
            .tree
            .locate(|x| x.len, start, Bias::Left)
            .expect("início dentro do texto");
        let (e_index, e_rem) = if end == start {
            (s.index, s.remainder)
        } else {
            let e = self
                .tree
                .locate(|x| x.len, end, Bias::Right)
                .expect("fim dentro do texto");
            (e.index, e.remainder)
        };

        let touched = self.tree.range_items(s.index, e_index + 1);
        let first = &touched[0];
        let last = &touched[touched.len() - 1];

        let mut combined = String::with_capacity(first.text.len() + text.len() + last.text.len());
        combined.push_str(&first.text[..s.remainder]);
        combined.push_str(text);
        combined.push_str(&last.text[e_rem..]);

        let new = split_text(&combined, self.max_chunk);
        self.tree.replace(s.index, e_index + 1, &new);
    }

    /// Copia `range` (bytes) para uma `String`.
    pub fn slice(&self, range: Range<usize>) -> String {
        let (start, end) = (range.start, range.end);
        assert!(start <= end && end <= self.len(), "intervalo fora dos limites");
        if start == end {
            return String::new();
        }
        let s = self
            .tree
            .locate(|x| x.len, start, Bias::Left)
            .expect("início dentro do texto");
        let e = self
            .tree
            .locate(|x| x.len, end, Bias::Right)
            .expect("fim dentro do texto");
        let chunks = self.tree.range_items(s.index, e.index + 1);

        let mut out = String::with_capacity(end - start);
        if chunks.len() == 1 {
            out.push_str(&chunks[0].text[s.remainder..e.remainder]);
            return out;
        }
        out.push_str(&chunks[0].text[s.remainder..]);
        for c in &chunks[1..chunks.len() - 1] {
            out.push_str(&c.text);
        }
        out.push_str(&chunks[chunks.len() - 1].text[..e.remainder]);
        out
    }

    /// Offset (bytes) → linha/coluna, em O(log N).
    pub fn offset_to_point(&self, offset: usize) -> Point {
        assert!(offset <= self.len(), "offset fora dos limites");
        match self.tree.locate(|x| x.len, offset, Bias::Left) {
            None => Point::default(),
            Some(loc) => {
                let chunk = self.tree.get(loc.index).expect("índice válido");
                let mut s = loc.prefix.clone();
                s.add_summary(&TextSummary::of(&chunk.text[..loc.remainder]));
                Point {
                    row: s.rows,
                    column: s.last_col,
                }
            }
        }
    }

    /// Linha/coluna → offset (bytes). Linha além do fim → fim do texto;
    /// coluna além do fim da linha → fim da linha.
    pub fn point_to_offset(&self, p: Point) -> usize {
        let total_rows = self.tree.summary().rows;
        if p.row > total_rows {
            return self.len();
        }
        let row_start = if p.row == 0 {
            0
        } else {
            let loc = self
                .tree
                .locate(|x| x.rows, p.row, Bias::Right)
                .expect("linha dentro do texto");
            let chunk = self.tree.get(loc.index).expect("índice válido");
            let mut seen = 0;
            let mut pos = chunk.text.len();
            for (i, b) in chunk.text.bytes().enumerate() {
                if b == b'\n' {
                    seen += 1;
                    if seen == loc.remainder {
                        pos = i + 1;
                        break;
                    }
                }
            }
            loc.prefix.len + pos
        };
        (row_start + p.column).min(self.line_end(row_start))
    }

    /// Offset do '\n' que termina a linha iniciada em `row_start` (ou o fim do texto).
    fn line_end(&self, row_start: usize) -> usize {
        let loc = match self.tree.locate(|x| x.len, row_start, Bias::Left) {
            Some(l) => l,
            None => return 0,
        };
        let mut base = row_start - loc.remainder;
        let mut idx = loc.index;
        let mut rem = loc.remainder;
        loop {
            let chunk = match self.tree.get(idx) {
                Some(c) => c,
                None => return base,
            };
            if let Some(p) = chunk.text[rem..].find('\n') {
                return base + rem + p;
            }
            base += chunk.text.len();
            idx += 1;
            rem = 0;
        }
    }
}

impl fmt::Display for Rope {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        for chunk in self.tree.items() {
            f.write_str(&chunk.text)?;
        }
        Ok(())
    }
}

impl From<&str> for Rope {
    fn from(text: &str) -> Self {
        let mut rope = Rope::new();
        rope.replace(0..0, text);
        rope
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::test_util::Lcg;

    fn char_to_byte(s: &str, c: usize) -> usize {
        s.char_indices().nth(c).map(|(i, _)| i).unwrap_or(s.len())
    }

    fn ref_point(s: &str, off: usize) -> Point {
        let before = &s[..off];
        let row = before.bytes().filter(|&b| b == b'\n').count();
        let col = match before.rfind('\n') {
            Some(p) => off - p - 1,
            None => off,
        };
        Point { row, column: col }
    }

    #[test]
    fn empty_rope() {
        let r = Rope::new();
        assert_eq!(r.len(), 0);
        assert!(r.is_empty());
        assert_eq!(r.line_count(), 1);
        assert_eq!(r.to_string(), "");
        assert_eq!(r.offset_to_point(0), Point::new(0, 0));
        assert_eq!(r.point_to_offset(Point::new(3, 3)), 0);
    }

    #[test]
    fn basic_edits() {
        let mut r = Rope::from("olá mundo");
        assert_eq!(r.len(), "olá mundo".len());
        r.replace(5..10, "Tessera");
        assert_eq!(r.to_string(), "olá Tessera");
        r.replace(0..0, ">> ");
        r.replace(r.len()..r.len(), "!");
        assert_eq!(r.to_string(), ">> olá Tessera!");
        assert_eq!(r.slice(3..7), "olá");
    }

    #[test]
    fn char_boundaries() {
        let r = Rope::from_str_with_chunk_size("aé日", 4); // a=1, é=2, 日=3 → 6 bytes
        let ok: Vec<usize> = (0..=7).filter(|&i| r.is_char_boundary(i)).collect();
        assert_eq!(ok, vec![0, 1, 3, 6]);
    }

    #[test]
    fn snapshot_is_independent() {
        let mut r = Rope::from("abc\ndef");
        let snap = r.clone();
        r.replace(0..3, "XYZW");
        assert_eq!(snap.to_string(), "abc\ndef");
        assert_eq!(r.to_string(), "XYZW\ndef");
    }

    #[test]
    fn points_roundtrip_simple() {
        let r = Rope::from_str_with_chunk_size("ab\ncde\n\nf", 4);
        assert_eq!(r.line_count(), 4);
        assert_eq!(r.offset_to_point(0), Point::new(0, 0));
        assert_eq!(r.offset_to_point(3), Point::new(1, 0));
        assert_eq!(r.offset_to_point(5), Point::new(1, 2));
        assert_eq!(r.offset_to_point(8), Point::new(3, 0));
        assert_eq!(r.point_to_offset(Point::new(1, 2)), 5);
        assert_eq!(r.point_to_offset(Point::new(2, 9)), 7);
        assert_eq!(r.point_to_offset(Point::new(9, 0)), r.len());
    }

    #[test]
    fn randomized_against_string() {
        let alphabet = ["a", "b", "\n", "é", "日", " ", "xyz\n", "linha comprida "];
        let mut rng = Lcg(7);
        let mut rope = Rope::with_chunk_size(8);
        let mut reference = String::new();

        for step in 0..2000 {
            let nchars = reference.chars().count();
            let a = rng.below(nchars + 1);
            let b = (a + rng.below(25)).min(nchars);
            let (sa, sb) = (char_to_byte(&reference, a), char_to_byte(&reference, b));

            let mut ins = String::new();
            for _ in 0..rng.below(12) {
                ins.push_str(alphabet[rng.below(alphabet.len())]);
            }

            rope.replace(sa..sb, &ins);
            reference.replace_range(sa..sb, &ins);
            assert_eq!(rope.len(), reference.len());

            if step % 25 == 0 {
                assert_eq!(rope.to_string(), reference);
                assert_eq!(rope.char_count(), reference.chars().count());
                assert_eq!(
                    rope.line_count(),
                    reference.bytes().filter(|&b| b == b'\n').count() + 1
                );

                let n = reference.chars().count();
                for _ in 0..10 {
                    let off = char_to_byte(&reference, rng.below(n + 1));
                    let p = ref_point(&reference, off);
                    assert_eq!(rope.offset_to_point(off), p, "offset {off}");
                    assert_eq!(rope.point_to_offset(p), off, "ponto {p:?}");
                }
                for _ in 0..10 {
                    let x = char_to_byte(&reference, rng.below(n + 1));
                    let y = char_to_byte(&reference, rng.below(n + 1));
                    let (x, y) = if x <= y { (x, y) } else { (y, x) };
                    assert_eq!(rope.slice(x..y).as_str(), &reference[x..y]);
                }
            }
        }
    }
}
