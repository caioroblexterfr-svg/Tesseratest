//! tessera-core — estruturas de dados do núcleo semântico.
//!
//! * [`sum_tree::SumTree`]: árvore B+ imutável (copy-on-write) com sumários agregados.
//! * [`rope::Rope`]: texto como `SumTree<Chunk>`; `clone()` é um snapshot O(1).

pub mod rope;
pub mod sum_tree;

pub use rope::{Point, Rope};
pub use sum_tree::{Bias, Item, Located, SumTree, Summary};

#[cfg(test)]
pub(crate) mod test_util {
    /// Gerador pseudo-aleatório determinístico (sem dependências).
    pub struct Lcg(pub u64);

    impl Lcg {
        pub fn next_u64(&mut self) -> u64 {
            self.0 = self
                .0
                .wrapping_mul(6364136223846793005)
                .wrapping_add(1442695040888963407);
            self.0 >> 33
        }

        /// Valor em `0..n` (n > 0).
        pub fn below(&mut self, n: usize) -> usize {
            (self.next_u64() as usize) % n
        }
    }
}
