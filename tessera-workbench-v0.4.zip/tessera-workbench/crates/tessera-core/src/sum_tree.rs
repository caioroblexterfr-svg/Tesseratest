//! SumTree: árvore B+ imutável (copy-on-write) em que cada nó agrega um `Summary`.
//!
//! * `clone()` é O(1) (partilha a raiz via `Arc`) → snapshots instantâneos.
//! * `replace` copia apenas o caminho afetado: O(log N + k).
//! * Altura uniforme: todas as folhas estão à mesma profundidade.
//! * Limitação da v0.1: apagar não reequilibra nós sub-ocupados (a altura nunca
//!   cresce por apagar; só cresce quando a raiz divide).

use std::sync::Arc;

const MAX_CHILDREN: usize = 16;

pub trait Summary: Clone + Default {
    fn add_summary(&mut self, other: &Self);
}

pub trait Item: Clone {
    type Summary: Summary;
    fn summary(&self) -> Self::Summary;
}

/// Desempate quando o alvo cai exatamente na fronteira entre dois itens.
/// `Left`: o alvo pertence ao item seguinte (`alvo < d`).
/// `Right`: o alvo pertence ao item anterior (`alvo <= d`).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Bias {
    Left,
    Right,
}

/// Resultado de [`SumTree::locate`].
#[derive(Clone, Debug)]
pub struct Located<S> {
    /// Índice do item.
    pub index: usize,
    /// Quanto do alvo sobra dentro desse item (na dimensão usada).
    pub remainder: usize,
    /// Soma dos sumários de todos os itens anteriores.
    pub prefix: S,
}

enum Kind<T: Item> {
    Leaf(Vec<T>),
    Internal(Vec<Arc<Node<T>>>),
}

struct Node<T: Item> {
    kind: Kind<T>,
    summary: T::Summary,
    count: usize,
}

fn zero<T: Item>() -> T::Summary {
    <T::Summary as Default>::default()
}

fn fits(target: usize, d: usize, bias: Bias) -> bool {
    match bias {
        Bias::Left => target < d,
        Bias::Right => target <= d,
    }
}

impl<T: Item> Node<T> {
    fn leaf(items: Vec<T>) -> Arc<Node<T>> {
        let mut summary = zero::<T>();
        for item in &items {
            summary.add_summary(&item.summary());
        }
        Arc::new(Node {
            count: items.len(),
            summary,
            kind: Kind::Leaf(items),
        })
    }

    fn internal(children: Vec<Arc<Node<T>>>) -> Arc<Node<T>> {
        let mut summary = zero::<T>();
        let mut count = 0;
        for child in &children {
            summary.add_summary(&child.summary);
            count += child.count;
        }
        Arc::new(Node {
            count,
            summary,
            kind: Kind::Internal(children),
        })
    }
}

/// Divide em grupos de tamanho ≤ MAX_CHILDREN, distribuídos de forma uniforme.
fn balanced_groups<X: Clone>(items: Vec<X>) -> Vec<Vec<X>> {
    let n = items.len();
    if n == 0 {
        return Vec::new();
    }
    let groups = (n + MAX_CHILDREN - 1) / MAX_CHILDREN;
    let size = (n + groups - 1) / groups;
    items.chunks(size).map(|c| c.to_vec()).collect()
}

fn pack_leaves<T: Item>(items: Vec<T>) -> Vec<Arc<Node<T>>> {
    balanced_groups(items)
        .into_iter()
        .map(|g| Node::leaf(g))
        .collect()
}

fn pack_internal<T: Item>(nodes: Vec<Arc<Node<T>>>) -> Vec<Arc<Node<T>>> {
    balanced_groups(nodes)
        .into_iter()
        .map(|g| Node::internal(g))
        .collect()
}

/// Substitui os itens `start..end` (relativos a `node`) por `new`.
/// Devolve os nós que substituem `node`, todos ao mesmo nível (0, 1 ou vários).
fn replace_in<T: Item>(node: &Node<T>, start: usize, end: usize, new: &[T]) -> Vec<Arc<Node<T>>> {
    match &node.kind {
        Kind::Leaf(items) => {
            let mut merged: Vec<T> = Vec::with_capacity(items.len() + new.len());
            merged.extend_from_slice(&items[..start]);
            merged.extend_from_slice(new);
            merged.extend_from_slice(&items[end..]);
            pack_leaves(merged)
        }
        Kind::Internal(children) => {
            // Filho que recebe os itens novos: o primeiro com `start < off + count`,
            // ou o último se `start` estiver no fim.
            let mut ins_idx = children.len() - 1;
            let mut off = 0usize;
            for (i, child) in children.iter().enumerate() {
                if start < off + child.count {
                    ins_idx = i;
                    break;
                }
                off += child.count;
            }

            let empty: &[T] = &[];
            let mut result: Vec<Arc<Node<T>>> = Vec::new();
            let mut off = 0usize;
            for (i, child) in children.iter().enumerate() {
                let cnt = child.count;
                let lo = start.clamp(off, off + cnt) - off;
                let hi = end.clamp(off, off + cnt) - off;
                let here: &[T] = if i == ins_idx { new } else { empty };
                if hi > lo || !here.is_empty() {
                    result.extend(replace_in(child, lo, hi, here));
                } else {
                    result.push(child.clone());
                }
                off += cnt;
            }
            pack_internal(result)
        }
    }
}

fn collect_range<T: Item>(node: &Node<T>, from: usize, to: usize, out: &mut Vec<T>) {
    match &node.kind {
        Kind::Leaf(items) => out.extend(items[from..to].iter().cloned()),
        Kind::Internal(children) => {
            let mut off = 0usize;
            for child in children {
                let cnt = child.count;
                let lo = from.clamp(off, off + cnt) - off;
                let hi = to.clamp(off, off + cnt) - off;
                if hi > lo {
                    collect_range(child, lo, hi, out);
                }
                off += cnt;
            }
        }
    }
}

pub struct SumTree<T: Item> {
    root: Option<Arc<Node<T>>>,
}

impl<T: Item> Clone for SumTree<T> {
    fn clone(&self) -> Self {
        Self {
            root: self.root.clone(),
        }
    }
}

impl<T: Item> Default for SumTree<T> {
    fn default() -> Self {
        Self::new()
    }
}

impl<T: Item> SumTree<T> {
    pub fn new() -> Self {
        Self { root: None }
    }

    pub fn from_items(items: Vec<T>) -> Self {
        let mut tree = Self::new();
        tree.replace(0, 0, &items);
        tree
    }

    pub fn is_empty(&self) -> bool {
        self.root.is_none()
    }

    /// Número de itens.
    pub fn count(&self) -> usize {
        self.root.as_ref().map_or(0, |r| r.count)
    }

    /// Sumário agregado de toda a árvore.
    pub fn summary(&self) -> T::Summary {
        match &self.root {
            Some(r) => r.summary.clone(),
            None => zero::<T>(),
        }
    }

    /// Número de níveis (0 = vazia, 1 = só folha).
    pub fn height(&self) -> usize {
        let mut h = 0;
        let mut node = match &self.root {
            Some(r) => &**r,
            None => return 0,
        };
        loop {
            h += 1;
            match &node.kind {
                Kind::Leaf(_) => return h,
                Kind::Internal(children) => node = &*children[0],
            }
        }
    }

    pub fn get(&self, index: usize) -> Option<T> {
        if index >= self.count() {
            return None;
        }
        self.range_items(index, index + 1).into_iter().next()
    }

    pub fn items(&self) -> Vec<T> {
        self.range_items(0, self.count())
    }

    /// Itens `from..to`, em O(log N + k).
    pub fn range_items(&self, from: usize, to: usize) -> Vec<T> {
        assert!(from <= to && to <= self.count(), "intervalo fora dos limites");
        let mut out = Vec::with_capacity(to - from);
        if let Some(root) = &self.root {
            collect_range(root, from, to, &mut out);
        }
        out
    }

    /// Substitui os itens `start..end` por `new`, copiando só o caminho afetado.
    pub fn replace(&mut self, start: usize, end: usize, new: &[T]) {
        assert!(
            start <= end && end <= self.count(),
            "intervalo fora dos limites"
        );
        let mut nodes = match &self.root {
            Some(root) => replace_in(root, start, end, new),
            None => pack_leaves(new.to_vec()),
        };
        while nodes.len() > 1 {
            nodes = pack_internal(nodes);
        }
        match nodes.pop() {
            None => self.root = None,
            Some(mut root) => {
                // Colapsa raízes com um único filho.
                loop {
                    let next = match &root.kind {
                        Kind::Internal(children) if children.len() == 1 => children[0].clone(),
                        _ => break,
                    };
                    root = next;
                }
                self.root = Some(root);
            }
        }
    }

    /// Localiza o item que contém `target` numa dimensão arbitrária do sumário.
    /// Devolve `None` se a árvore estiver vazia ou `target` exceder o total.
    pub fn locate<D>(&self, dim: D, target: usize, bias: Bias) -> Option<Located<T::Summary>>
    where
        D: Fn(&T::Summary) -> usize,
    {
        let mut node: &Node<T> = &**self.root.as_ref()?;
        let mut target = target;
        let mut index = 0usize;
        let mut prefix = zero::<T>();
        loop {
            match &node.kind {
                Kind::Leaf(items) => {
                    let n = items.len();
                    for (i, item) in items.iter().enumerate() {
                        let s = item.summary();
                        let d = dim(&s);
                        if fits(target, d, bias) || (i + 1 == n && target == d) {
                            return Some(Located {
                                index: index + i,
                                remainder: target,
                                prefix,
                            });
                        }
                        if i + 1 == n {
                            return None;
                        }
                        target -= d;
                        prefix.add_summary(&s);
                    }
                    return None;
                }
                Kind::Internal(children) => {
                    let n = children.len();
                    let mut next: Option<&Node<T>> = None;
                    for (i, child) in children.iter().enumerate() {
                        let d = dim(&child.summary);
                        if fits(target, d, bias) || (i + 1 == n && target == d) {
                            next = Some(&**child);
                            break;
                        }
                        if i + 1 == n {
                            return None;
                        }
                        target -= d;
                        index += child.count;
                        prefix.add_summary(&child.summary);
                    }
                    match next {
                        Some(c) => node = c,
                        None => return None,
                    }
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::test_util::Lcg;

    #[derive(Clone, Debug, PartialEq)]
    struct Num(usize);

    #[derive(Clone, Default, Debug, PartialEq)]
    struct Sum {
        total: usize,
    }

    impl Summary for Sum {
        fn add_summary(&mut self, other: &Self) {
            self.total += other.total;
        }
    }

    impl Item for Num {
        type Summary = Sum;
        fn summary(&self) -> Sum {
            Sum { total: self.0 }
        }
    }

    fn nums(rng: &mut Lcg, n: usize) -> Vec<Num> {
        (0..n).map(|_| Num(1 + rng.below(5))).collect()
    }

    #[test]
    fn empty_tree() {
        let t: SumTree<Num> = SumTree::new();
        assert!(t.is_empty());
        assert_eq!(t.count(), 0);
        assert_eq!(t.height(), 0);
        assert!(t.locate(|s| s.total, 0, Bias::Left).is_none());
    }

    #[test]
    fn bulk_build_is_shallow() {
        let mut rng = Lcg(1);
        let t = SumTree::from_items(nums(&mut rng, 10_000));
        assert_eq!(t.count(), 10_000);
        assert!(t.height() <= 5, "altura = {}", t.height());
    }

    #[test]
    fn snapshots_are_independent() {
        let mut rng = Lcg(2);
        let mut t = SumTree::from_items(nums(&mut rng, 100));
        let snap = t.clone();
        let before = snap.items();
        t.replace(10, 50, &[Num(7)]);
        assert_eq!(snap.items(), before);
        assert_eq!(t.count(), 61);
    }

    #[test]
    fn randomized_against_vec() {
        let mut rng = Lcg(42);
        let mut tree = SumTree::from_items(nums(&mut rng, 500));
        let mut reference: Vec<Num> = tree.items();

        for step in 0..3000 {
            let len = reference.len();
            let a = rng.below(len + 1);
            let b = (a + rng.below(40)).min(len);
            let k = rng.below(60);
            let new = nums(&mut rng, k);

            tree.replace(a, b, &new);
            drop(reference.splice(a..b, new));

            assert_eq!(tree.count(), reference.len());
            let total: usize = reference.iter().map(|n| n.0).sum();
            assert_eq!(tree.summary().total, total);

            if step % 100 == 0 {
                assert_eq!(tree.items(), reference);
                if total > 0 {
                    let target = rng.below(total);
                    let loc = tree
                        .locate(|s| s.total, target, Bias::Left)
                        .expect("alvo dentro do total");
                    let mut cum = 0;
                    let mut expected = 0;
                    for (i, n) in reference.iter().enumerate() {
                        if target < cum + n.0 {
                            expected = i;
                            break;
                        }
                        cum += n.0;
                    }
                    assert_eq!(loc.index, expected);
                    assert_eq!(loc.remainder, target - cum);
                    assert_eq!(loc.prefix.total, cum);
                }
            }
        }
    }
}
