//! tessera-sandbox — modelo de capacidades para execução de código não confiável.
//!
//! Nesta versão: apenas a política (`SandboxCapabilityPolicy`), com negação por omissão.
//! O executor Wasmtime (épocas, limites de memória, core dumps) entra na Fase 3.

pub mod policy;

pub use policy::{PolicyError, SandboxCapabilityPolicy};
