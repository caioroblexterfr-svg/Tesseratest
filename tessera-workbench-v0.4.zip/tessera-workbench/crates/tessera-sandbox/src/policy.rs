use std::path::{Component, Path};

/// Política de capacidades. `Default` = **nada permitido** (negação por omissão),
/// mas com limites de recursos finitos.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SandboxCapabilityPolicy {
    /// Diretórios pré-abertos (relativos à raiz do projeto, sem `..`).
    pub preopened_dirs: Vec<String>,
    /// Anfitriões HTTP de saída permitidos (`exemplo.com` ou `*.exemplo.com`).
    pub allowed_hosts: Vec<String>,
    /// Limite da memória linear, em páginas de 64 KiB.
    pub max_memory_pages: u32,
    /// Prazo da interrupção por épocas, em milissegundos.
    pub epoch_deadline_ms: u64,
    /// Orçamento de *fuel* (só para depuração determinística); `None` = desligado.
    pub fuel_budget: Option<u64>,
}

#[derive(Debug, PartialEq, Eq)]
pub enum PolicyError {
    PathTraversal(String),
    AbsolutePath(String),
    EmptyHost,
    ZeroMemory,
    ZeroEpochDeadline,
}

impl Default for SandboxCapabilityPolicy {
    fn default() -> Self {
        Self {
            preopened_dirs: Vec::new(),
            allowed_hosts: Vec::new(),
            max_memory_pages: 1024, // 64 MiB
            epoch_deadline_ms: 5_000,
            fuel_budget: None,
        }
    }
}

impl SandboxCapabilityPolicy {
    pub fn validate(&self) -> Result<(), PolicyError> {
        for dir in &self.preopened_dirs {
            let path = Path::new(dir);
            if path.is_absolute() || dir.starts_with('/') || dir.starts_with('\\') {
                return Err(PolicyError::AbsolutePath(dir.clone()));
            }
            for comp in path.components() {
                if matches!(comp, Component::ParentDir | Component::Prefix(_) | Component::RootDir) {
                    return Err(PolicyError::PathTraversal(dir.clone()));
                }
            }
            if dir.split(['/', '\\']).any(|part| part == "..") {
                return Err(PolicyError::PathTraversal(dir.clone()));
            }
        }
        if self.allowed_hosts.iter().any(|h| h.trim().is_empty()) {
            return Err(PolicyError::EmptyHost);
        }
        if self.max_memory_pages == 0 {
            return Err(PolicyError::ZeroMemory);
        }
        if self.epoch_deadline_ms == 0 {
            return Err(PolicyError::ZeroEpochDeadline);
        }
        Ok(())
    }

    /// `true` se `host` está explicitamente permitido. `*.x.com` cobre subdomínios,
    /// mas não `x.com` em si.
    pub fn allows_host(&self, host: &str) -> bool {
        let host = host.to_ascii_lowercase();
        self.allowed_hosts.iter().any(|allowed| {
            let allowed = allowed.to_ascii_lowercase();
            match allowed.strip_prefix('*') {
                Some(suffix) if suffix.starts_with('.') => {
                    host.len() > suffix.len() && host.ends_with(suffix)
                }
                _ => host == allowed,
            }
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn default_denies_everything() {
        let p = SandboxCapabilityPolicy::default();
        assert!(p.validate().is_ok());
        assert!(p.preopened_dirs.is_empty());
        assert!(!p.allows_host("example.com"));
    }

    #[test]
    fn rejects_traversal_and_absolute_paths() {
        let mut p = SandboxCapabilityPolicy::default();
        p.preopened_dirs = vec!["src/../../etc".into()];
        assert!(matches!(p.validate(), Err(PolicyError::PathTraversal(_))));
        p.preopened_dirs = vec!["/etc".into()];
        assert!(matches!(p.validate(), Err(PolicyError::AbsolutePath(_))));
        p.preopened_dirs = vec!["src".into(), "tests/fixtures".into()];
        assert!(p.validate().is_ok());
    }

    #[test]
    fn host_matching() {
        let p = SandboxCapabilityPolicy {
            allowed_hosts: vec!["api.exemplo.com".into(), "*.cdn.exemplo.com".into()],
            ..Default::default()
        };
        assert!(p.allows_host("API.exemplo.com"));
        assert!(p.allows_host("a.cdn.exemplo.com"));
        assert!(!p.allows_host("cdn.exemplo.com"));
        assert!(!p.allows_host("evilcdn.exemplo.com.atacante.io"));
        assert!(!p.allows_host("exemplo.com"));
    }

    #[test]
    fn rejects_zero_limits() {
        let p = SandboxCapabilityPolicy { max_memory_pages: 0, ..Default::default() };
        assert_eq!(p.validate(), Err(PolicyError::ZeroMemory));
        let p = SandboxCapabilityPolicy { epoch_deadline_ms: 0, ..Default::default() };
        assert_eq!(p.validate(), Err(PolicyError::ZeroEpochDeadline));
    }
}
