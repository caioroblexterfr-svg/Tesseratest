# SECURITY.md — Tessera Workbench

> Estado: rascunho normativo v0.1 · Ver também [ARCHITECTURE.md](./ARCHITECTURE.md) e [ROADMAP.md](./ROADMAP.md)

## 1. Modelo de ameaças

Um IDE Web/PWA concentra propriedade intelectual, tokens de repositórios, manipulação dinâmica de UI e execução de código arbitrário (do utilizador, de repositórios externos ou de LLMs). O código é tratado como **potencialmente hostil**.

| Fronteira | Ameaças principais | Controlo principal |
|---|---|---|
| 1. Site e sessão | Roubo de tokens por XSS, npm comprometido, extensões, CDN alterada | BFF + cookie HttpOnly |
| 2. Plataforma Web/PWA | XSS refletido/armazenado/DOM, Spectre, injeção de scripts | CSP estrita, Trusted Types, COOP/COEP |
| 3. Execução de código | Escape de iframe, DoS, acesso a ficheiros/rede, fork bomb | Três níveis de sandbox |
| 4. Agentes de IA / MCP | Tool poisoning, DPMA, Intent Inversion | Defesas no cliente + HITL |

## 2. Autenticação e sessões (RFC 10017, RFC 9700)

**Premissa:** o navegador é hostil. Qualquer token em `localStorage`, `sessionStorage`, IndexedDB ou em variáveis JS fica acessível a XSS. O armazenamento em Service Workers dá proteção apenas parcial.

**Regras obrigatórias**

1. **Padrão BFF** (*Backend-for-Frontend*). Rejeitam-se o *Browser-Based OAuth Client* (BBOC) e o *Token-Mediating Backend* (TMB), que ainda expõe access tokens ao JS.
2. Fluxo **Authorization Code + PKCE** (clientes públicos e confidenciais). Fluxo implícito (`response_type=token`) **proibido**.
3. `redirect_uri` com **correspondência exata**.
4. O BFF é cliente OAuth 2.1 **confidencial**; access e refresh tokens existem **apenas no servidor**.
5. **DPoP (RFC 9449)** quando os servidores de recursos o suportarem.
6. O cliente recebe apenas um **cookie opaco** `HttpOnly; Secure` sobre HTTPS.
7. O Service Worker **nunca** armazena credenciais ou tokens.

**Risco residual:** *proxying* de pedidos dentro da sessão ativa durante um XSS. Mitigado pelas secções 3 e 4.

## 3. Plataforma Web/PWA

### 3.1 CSP estrita

- `nonce` criptográfico por pedido + `'strict-dynamic'`; **sem allowlists de domínios**.
- `'unsafe-inline'` não incluído; `'unsafe-eval'` **proibido**.
- `'wasm-unsafe-eval'` apenas, para `WebAssembly.compileStreaming()` (tessera-core, Loro, Tree-sitter).
- Exceção transitória: `'trusted-types-eval'` (Chrome 145+, Firefox 148+, Safari 26+) só durante migração de dependências; objetivo final é zero exceções.

### 3.2 Trusted Types

`require-trusted-types-for 'script'; trusted-types tessera-sanitize tessera-worker`

- Sinks perigosos (`innerHTML`, `document.write`, `eval`, `HTMLScriptElement.text/src`) lançam `TypeError` com strings simples.
- Apenas `TrustedHTML` / `TrustedScript` / `TrustedScriptURL` de políticas registadas e auditadas (DOMPurify; validação estrita de URLs de Workers).
- **Sem política `default` permissiva.**

**Ciclo de ativação (5 passos):** `Report-Only` → recolher relatórios (`effectiveDirective`, `sample`, `sourceFile`) → remediar sinks → ativar bloqueio → monitorização permanente.

### 3.3 Isolamento de origem cruzada

`window.crossOriginIsolated === true` em `/workspace/*` (necessário para `SharedArrayBuffer`, WASM multi-thread, temporizadores de alta resolução).

- `Cross-Origin-Opener-Policy: same-origin`
- `Cross-Origin-Embedder-Policy: credentialless` (Chrome 96+/Firefox) ou `require-corp` com `Cross-Origin-Resource-Policy: cross-origin` nos ativos, para Safari.

**Conflito conhecido com OAuth:** com COOP/COEP, `window.closed` devolve `true` de imediato em pop-ups (caso StackBlitz). **Solução:** separação de rotas.

| Rota | COOP/COEP | Fluxo |
|---|---|---|
| `/auth/*` (BFF) | Omitidos / `same-origin-allow-popups` | Navegação de topo (sem pop-up) |
| `/workspace/*` | Ativos | Só depois de o cookie HttpOnly estar definido |

### 3.4 Matriz de cabeçalhos por origem

| Cabeçalho | `/workspace/*` | `/auth/*` | `*.preview` |
|---|---|---|---|
| **CSP** | `default-src 'self'; script-src 'nonce-{R}' 'strict-dynamic' 'wasm-unsafe-eval'; object-src 'none'; base-uri 'none'; upgrade-insecure-requests; require-trusted-types-for 'script'; trusted-types tessera-sanitize tessera-worker` | `default-src 'self'; script-src 'nonce-{R}' 'strict-dynamic'; object-src 'none'; base-uri 'none'; upgrade-insecure-requests` | Política própria; nunca partilha nonces nem origem com a app |
| **COOP** | `same-origin` | `same-origin-allow-popups` ou omitido | `same-origin` |
| **COEP** | `credentialless` ou `require-corp` (+CORP) | Omitido | Omitido / `unsafe-none` (ou `credentialless` se testar SAB) |
| **CORP** | `same-origin` | `same-origin` | `cross-origin` só se sob `require-corp` |
| **Sessão** | Cookie opaco HttpOnly+Secure; zero tokens no DOM/storage | Code+PKCE; tokens só no BFF | **Proibidos** cookies/sessões partilhados com o domínio principal |

## 4. Execução de código não confiável

**Notas de implementação (a validar em navegadores reais; ver `apps/pwa/server/headers.mjs`):**

- `frame-src <origem-preview>` tem de constar da CSP de `/workspace/*`; com `default-src 'self'` o iframe de preview seria bloqueado.
- Sugere-se `worker-src 'self'`, para os Workers dedicados não dependerem de `'strict-dynamic'`.
- A matriz acima prevê COEP omitido na origem de preview. Um documento com COEP **não consegue incorporar** um iframe cross-origin que não opte por COEP/CORP, pelo que a implementação usa COEP `credentialless` + CORP `cross-origin` no preview.
- Um iframe `sandbox` sem `allow-same-origin` tem origem opaca: as suas mensagens chegam com `event.origin === "null"`. A verificação estrita de origem passa a ser `event.source === iframe.contentWindow` + `origin === "null"` (ou transferência de `MessagePort`).
- `upgrade-insecure-requests` só em produção (não em `http://localhost`).

### Nível 1 — Pré-visualização HTML/CSS/JS em iframe

- **Proibido** `srcdoc` sem isolamento completo (herda a origem do hospedeiro).
- **Proibido** `sandbox="allow-scripts allow-same-origin"` (permite ler nonces via `top.document` ou remover o próprio sandbox).
- Servir de **origem separada e não confiável** (subdomínio efémero por sessão) com `sandbox="allow-scripts allow-forms"` e **sem** `allow-same-origin`.
- Comunicação só por `MessageChannel`/`postMessage`, com verificação estrita de origem e esquema.

### Nível 2 — Plugins e Live Eval JS

- **Proibidas** sandboxes baseadas em `Proxy` na mesma thread.
- **QuickJS compilado para WASM** dentro de um **Web Worker** dedicado (modelo adotado pela Figma).
- Memória linear isolada: sem acesso a globais nem DOM.
- Ciclos infinitos terminados com `worker.terminate()`.

### Nível 3 — Programas, testes e ferramentas (servidor ou companion)

- **Excluído** `node:wasi` (a própria documentação do Node avisa que o isolamento do FS pode ser contornado).
- **Wasmtime** (Cranelift) com **WASI Preview 2 + Component Model**.
- Autoridade por capacidades, contratos WIT, **negação por omissão**:
  - `wasi:filesystem`: diretórios pré-abertos limitados à pasta do projeto.
  - `wasi:http/outgoing-handler`: allowlist de domínios e limites de concorrência.
  - Sem `fork()`, `exec()` nem sinais POSIX arbitrários.
- **Limites de recursos:** páginas máximas de memória linear + **interrupção por épocas** (~10 % de sobrecarga). `fuel` (`store.set_fuel()`) reservado a depuração determinística e *core dumps*.
- **Lembrete:** nenhuma sandbox é infalível (ex.: CVE-2023-26489 no Wasmtime 6.0.1; CVE-2024-32006 no WasmEdge 0.13.5). Exige-se **pinning de versões em CI** e subscrição dos avisos da Bytecode Alliance (embargo de 90 dias).

### Grafo do espaço de trabalho (nomes e réplicas)

- Todo o nome de ficheiro/pasta passa por `validateName` (NFC; sem `..`, separadores, carateres de controlo ou de sobreposição bidirecional, nomes de dispositivo do Windows; máx. 255 bytes), tanto em escritas locais como em operações recebidas. Uma operação remota com nome inválido é recusada, não normalizada.
- Operações recebidas são tratadas como não confiáveis (`validateOp`). **Não são autenticadas**: duas operações diferentes com a mesma chave `(réplica, contador)` fazem as réplicas divergir. O BFF tem de autenticar quem sincroniza e atribuir o identificador de réplica (ADR-009).

## 5. Cadeia de fornecimento

- Dependências Rust e npm com versões fixas e lockfiles verificados em CI.
- Fixar Wasmtime e `cosmic-text` (regressões em Wayland/WebGPU).
- Pacotes e contentores de servidores MCP assinados; verificação ao nível da implantação, não só de *hash* num transporte (ver §6).
- Atualizador do Tauri com assinatura obrigatória (não desativável).

## 6. Agentes de IA e MCP (`tessera-mcp-client`)

**Ameaças:** *tool poisoning* e DPMA (instruções ocultas em descrições, parâmetros ou metadados de ferramentas); *Intent Inversion* (servidor semi-honesto infere dados privados dos padrões de invocação). Em estudos citados na especificação (MCPTox), as taxas de sucesso chegaram a 72,8 % com recusas inferiores a 3 %, e a **validação no cliente pesa mais do que a escolha do modelo**.

**Quatro defesas obrigatórias no cliente**

1. **Sanitizar metadados:** normalizar, truncar a limites estritos e delimitar como **dados não confiáveis**; bloquear diretivas imperativas.
2. **Sem autoridade ambiente:** subconjunto mínimo de capacidades declaradas; exclusão absoluta de ficheiros de segredos e configurações críticas.
3. **Minimização contra Intent Inversion:** enviar só fragmentos pseudonimizados ou símbolos SCIP necessários; nunca caminhos locais completos nem identificadores de negócio supérfluos.
4. **HITL obrigatório** para qualquer efeito secundário (escrita de ficheiros, execução no runner WASI, HTTP externo), sobre plano estruturado e *diff* difftastic.

**Integridade:** servidores MCP locais de terceiros correm confinados em sandboxes WASI P2 ou contentores isolados.

**Política de patches (`AuditPatchProposal`):** aplicação automática proibida se o ast-grep detetar novo *error-masking* ou se faltar aprovação HITL.

## 7. Lista de verificação de lançamento

- [ ] `/workspace/*`: `crossOriginIsolated === true`; sem `'unsafe-inline'`/`'unsafe-eval'`; atribuir string a `innerHTML` lança `TypeError`.
- [ ] Fluxo OAuth: PKCE obrigatório, `redirect_uri` exato, `/auth/*` isolado de COOP/COEP, **nenhum** token em memória JS, localStorage, IndexedDB, OPFS ou Service Worker.
- [ ] Testes adversariais: leitura de `window.parent` e nonces a partir do preview; loop infinito em QuickJS; abertura de ficheiros fora dos pré-abertos, rede não autorizada e esgotamento de CPU/RAM no Wasmtime.
- [ ] `tessera-mcp-client` com casos inspirados no MCPTox; HITL cumprido; assinatura de integridade na implantação.
- [ ] Versões do Wasmtime e do `cosmic-text` fixadas em CI; subscrição ativa de avisos de segurança.

## 8. Divulgação de vulnerabilidades

> *A preencher pela equipa:* endereço de contacto de segurança, chave PGP, janela de resposta e política de divulgação coordenada.
