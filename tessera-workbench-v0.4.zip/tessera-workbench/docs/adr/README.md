# Registo de decisões de arquitetura (ADRs)

Formato: `NNNN-titulo-curto.md` com as secções **Contexto**, **Decisão**, **Consequências**, **Estado**.

| ID | Decisão | Estado |
|---|---|---|
| ADR-001 | Núcleo em Rust/WASM num Worker; SumTree/Rope | Aceite |
| ADR-002 | Loro 1.0 como CRDT primário + `CrdtTextAdapter` para Yjs | Aceite |
| ADR-003 | OPFS primário; IndexedDB como contingência | Aceite |
| ADR-004 | PWA principal; Tauri v2 como companion | Aceite |
| ADR-005 | Renderização dual (WebGPU + DOM virtualizado) | Aceite |
| ADR-006 | BFF obrigatório (RFC 10017) | Aceite |
| ADR-007 | Sandboxes em três níveis | Aceite |
| ADR-008 | Spatial como modo integrado, não substituto do editor | Aceite |
| [ADR-009](0009-workspace-graph-arvore-movel.md) | `WorkspaceGraph`: árvore móvel replicável (Kleppmann), implementação provisória em JS até ao `LoroMovableTree` | Proposta |

As linhas sem ligação ainda não têm ficheiro (ver ARCHITECTURE.md §6–§9 para o contexto).
