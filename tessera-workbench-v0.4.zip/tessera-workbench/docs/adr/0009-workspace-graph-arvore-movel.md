# ADR-009 — `WorkspaceGraph` como árvore móvel replicável (implementação provisória em JS)

## Contexto

- O critério de aceitação da Fase 1 exige **0 ciclos ou duplicações em movimentações concorrentes** (ROADMAP).
- O alvo é o `LoroMovableTree` (ADR-002), em Rust/WASM. Esse caminho ainda não foi compilado nem ligado, e o
  `WorkspaceGraph` precisa de um contrato e de testes já, para que a UI e o Worker se possam apoiar nele.
- Um CRDT ingénuo de pastas falha em concorrência: «A move X para dentro de Y» e «B move Y para dentro de X»
  produzem um ciclo; «A move F para D1» e «B move F para D2» produzem duplicados ou perdas.

## Decisão

1. **Interface estável** (`apps/pwa/public/workspace/assets/workspace-graph.js`). Escrita local
   (`create`, `move`, `rename`, `remove`) devolve operações; replicação por `apply`/`importOps`/`exportOps`;
   leitura por `children`, `pathOf`, `resolve`, `get`, `snapshot`. O Worker expõe-na como operações `ws.*`
   (`workspace-protocol.js`).
2. **Implementação provisória**: o algoritmo de *move* de Kleppmann et al., «A highly-available move operation
   for replicated trees» (IEEE TPDS, 2021). Cada alteração é uma operação `mover(nó → pai, nome)` com relógio de
   Lamport; o estado é a aplicação de **todas** as operações por ordem de timestamp. Uma operação fora de ordem
   desfaz as posteriores, aplica-se e refaz as desfeitas. Uma operação que criaria um ciclo é **ineficaz** (fica no
   registo e pode tornar-se eficaz se uma anterior chegar mais tarde). O estado não depende da ordem de entrega.
3. **Regras do modelo**
   - `ROOT` e `TRASH` não se movem. **Apagar = mover para `TRASH`** (recuperável; «mover» e «apagar»
     concorrentes convergem). Criar numa pasta apagada concorrentemente deixa o item escondido no lixo.
   - Ficheiros não têm filhos; o tipo (`file`/`dir`) de um nó não muda; pai desconhecido torna a operação ineficaz
     até o pai chegar.
   - **Nomes** (`validateName`): NFC; rejeita vazio, `.`/`..`, `/` `\`, carateres do Windows `<>:"|?*`, controlo,
     sobreposição bidirecional, substitutos soltos, espaço/ponto no fim, nomes de dispositivo do Windows
     (`CON`, `NUL`, `COM1`, `CONIN$`…), `.trash` e mais de 255 bytes. O objetivo é que o que passa possa ser
     exportado para Windows, macOS e Linux sem sair da pasta de destino (a lista cobre o essencial; não é uma
     garantia formal). Localmente, irmãos não podem repetir o nome (sem distinguir
     maiúsculas).
   - Irmãos com o mesmo nome criados em concorrência **coexistem**; a vista dá o nome ao mais antigo e
     «nome (2)», «nome (3)»… aos outros, de forma determinística (igual em todas as réplicas).
   - Operações recebidas são validadas como não confiáveis (`validateOp`) e reduzidas aos campos conhecidos.
4. **Persistência**: o registo de operações em JSON (`{ v: 1, ops }`) na chave reservada `__workspace__` do
   armazenamento local (o prefixo `__` está vedado a documentos). Um registo corrompido faz as operações falhar;
   nada é descartado em silêncio.
5. **A suite `test/workspace-graph.test.mjs` é o teste de conformidade** de qualquer motor por trás da interface:
   cenários de convergência, validação de nomes e de operações, operações hostis e *fuzz* de 3–5 réplicas com
   entrega desordenada e duplicada, comparado com um oráculo independente (dobragem ordenada, sem desfazer/refazer).

## Consequências

- ✔ O critério «0 ciclos ou duplicações» é verificável já, sem toolchain Rust nem rede.
- ✔ A migração para Loro troca o motor sem mexer na interface, no protocolo do Worker nem nos testes.
- ✘ O registo cresce sem limite; a compactação exige saber o que todas as réplicas já viram (por fazer).
  Importar registos fora de ordem custa O(n²) no pior caso (um registo ordenado, como o exportado, é linear).
- ✘ **Sem autenticação de operações**: uma réplica que envie duas operações diferentes com a mesma chave
  `(réplica, contador)` faz as réplicas divergirem (ficam com a primeira que virem). A defesa é do BFF: autenticar
  quem sincroniza e atribuir-lhe o identificador de réplica (SECURITY.md §2).
- ✘ A lista de nomes proibidos é deliberadamente conservadora (portabilidade): pode ser relaxada numa única
  função se for demasiado restritiva.
- ✘ Não cobre texto (`LoroText`), *snapshots* nem *time-travel*: isso continua a ser trabalho do Loro.

## Estado

Proposta (provisória). Implementado em JS e testado em Node (suites `workspace-graph`, `workspace-protocol` e
`core-worker`); **não testado em navegador**. Substituir quando o `LoroMovableTree` estiver ligado.
