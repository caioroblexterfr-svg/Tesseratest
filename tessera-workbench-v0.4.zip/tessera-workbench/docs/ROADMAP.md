# ROADMAP.md — Tessera Workbench

> Estado: rascunho v0.1 · Ver também [ARCHITECTURE.md](./ARCHITECTURE.md) e [SECURITY.md](./SECURITY.md)

Cada fase termina apenas quando **todos** os critérios de aceitação (*Definition of Done*) estão verificados.

## Visão geral

```
Fase 1            Fase 2                 Fase 3                    Fase 4
Núcleo local ───► Canvas + SCIP + Eval ─► BFF + Web hardening ────► MCP + DX + Tauri
                                          + WASI P2
```

## Fase 1 — Núcleo local-first e editor estrutural

**Entregáveis**

- [ ] `tessera-core`: Rope/SumTree e Loro em Web Worker
- [ ] Adaptador OPFS (`FileSystemSyncAccessHandle`) com contingência IndexedDB para Navegação Privada do Safari
- [ ] Tree-sitter e regras base ast-grep
- [ ] PWA instalável

**Critérios de aceitação**

- Edição responsiva de ficheiros extensos sem bloquear o fio principal
- Operação 100 % offline validada após reinício do navegador
- 0 ciclos ou duplicações em movimentações concorrentes no `LoroMovableTree` (já verificado para a implementação provisória do `WorkspaceGraph`, ADR-009; falta repetir com o Loro)

## Fase 2 — Canvas espacial, SCIP e Live Eval

**Entregáveis**

- [ ] Canvas espacial integrado (WebGPU/WebGL2 + DOM virtualizado): *bubble spacer*, *budding*, elisão vertical, cartões ADR
- [ ] Leitor/indexador SCIP
- [ ] Live Eval em QuickJS-WASM
- [ ] *Typed holes*
- [ ] Vista difftastic

**Critérios de aceitação**

- «Ir para Definição» via SCIP, sem heurísticas textuais
- JS isolado em QuickJS-WASM com terminação forçada de ciclos infinitos via Worker
- Sincronia contínua entre separadores convencionais e canvas

## Fase 3 — Blindagem Web, BFF e WASI Preview 2

**Entregáveis**

- [ ] BFF (RFC 10017/9700, PKCE, DPoP, cookies HttpOnly)
- [ ] Separação `/auth/*` vs `/workspace/*` para COOP/COEP
- [ ] `preview-gateway` em origem separada, sem `srcdoc` nem `allow-same-origin`
- [ ] `tessera-sandbox` em Wasmtime WASI P2, com limites de páginas e épocas

**Critérios de aceitação**

- Auditoria limpa em Report-Only, seguida de bloqueio ativo (`require-trusted-types-for 'script'`)
- `crossOriginIsolated === true` em `/workspace/*`
- Zero tokens no navegador
- Pentest confirma: sem leitura do DOM pai a partir do preview; Wasmtime contido fora dos diretórios pré-abertos

## Fase 4 — Agentes MCP auditados, DX Core 4 e Tauri v2

**Entregáveis**

- [ ] `tessera-mcp-client`: sanitização anti-poisoning, minimização contra Intent Inversion, portão HITL
- [ ] Regras YAML anti-*error-masking* e anti-duplicação
- [ ] Painel DX Core 4
- [ ] Companion Tauri v2 assinado e depuração por *core dumps* Wasm

**Critérios de aceitação**

- Bloqueio automático de escritas/comandos MCP sem revisão difftastic e aprovação HITL
- Painel que emparelha velocidade com *churn* a 14 dias e duplicação
- Binários Tauri v2 com atualizador assinado validados em Desktop e móvel

## 5. Métricas de sucesso do produto

| Tema | Indicador | Par de qualidade |
|---|---|---|
| Velocidade | Tempo de ciclo; frequência de entrega | Taxa de falha de alterações; *churn* 14 d |
| Manutenção | Rácio refatorado/movido | Duplicação; incidência de *error-masking* |
| Cognição | Navegações repetidas; tempo de compreensão | Escala de carga cognitiva e satisfação |
| IA | Utilização de agentes | Rejeições em HITL; novos error-masking bloqueados |

## 6. Riscos e pontos em aberto

| # | Risco / questão | Mitigação / próximo passo |
|---|---|---|
| R1 | Impacto real em *churn* não comprovado empiricamente | Telemetria equilibrada; estudos A/B internos |
| R2 | Estatísticas da secção 2 do ARCHITECTURE vêm de fontes secundárias | Reverificar em fontes primárias antes de uso público |
| R3 | Ecossistema Loro jovem; WASM > 1 MB; *snapshots* podem bloquear a UI | Worker assíncrono, cache por SW, `CrdtTextAdapter` para Yjs |
| R4 | COOP/COEP vs OAuth e recursos sem CORP | Separação de rotas; auditoria de ativos de terceiros |
| R5 | `credentialless` ausente no Safari | `require-corp` + CORP nos ativos; testes em Safari |
| R6 | Assimetria das WebViews do Tauri (WebKitGTK em Linux) | Tauri apenas opcional; matriz de testes por SO |
| R7 | Regressões tipográficas (`cosmic-text` em Wayland) | *Pinning* em CI; testes de regressão visual |
| R8 | Falhas de implementação em sandboxes (CVEs em runtimes WASM) | *Pinning*, avisos da Bytecode Alliance, defesa em profundidade |
| R9 | Acessibilidade/IME em canvas | Renderização dual com DOM virtualizado no foco |
| R10 | OPFS indisponível em Safari privado | Fallback IndexedDB com aviso de volatilidade |

## 7. Próximos passos imediatos

1. Criar o monorepo com a estrutura de `ARCHITECTURE.md §11`.
2. Esqueleto Rust workspace (`tessera-core`, `tessera-intel`, `tessera-sandbox`) com CI e *pinning* de versões.
3. Prova de conceito: Rope em Worker + OPFS + Loro (critérios da Fase 1).
4. Registar ADR-001 a ADR-008 em `docs/adr/`.
