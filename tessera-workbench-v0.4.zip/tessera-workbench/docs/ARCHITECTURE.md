# ARCHITECTURE.md — Tessera Workbench

> Estado: rascunho normativo v0.1 · Idioma: pt-PT · Documentos relacionados: [SECURITY.md](./SECURITY.md), [ROADMAP.md](./ROADMAP.md)

## 1. Visão

O Tessera Workbench é um IDE **espacial, estrutural e local-first**, entregue como Web/PWA, com *companion* nativo opcional em Tauri v2. O objetivo é ampliar a capacidade cognitiva e produtiva do programador, tanto na criação de sistemas de raiz como na evolução de bases de código maduras, **com ou sem IA**.

### Princípios

1. **Paridade humano/IA.** Toda a capacidade central funciona sem modelo de IA. Os agentes usam exatamente as mesmas primitivas semânticas e de verificação que o humano.
2. **Estrutura antes de texto.** Revisão, pesquisa e refatoração operam sobre árvores de sintaxe e índices de símbolos, não sobre linhas cruas.
3. **Local-first.** Tudo funciona offline; a rede é opcional.
4. **Segurança em profundidade.** Quatro fronteiras independentes (site, plataforma, execução de código, agentes). Ver SECURITY.md.
5. **Métricas equilibradas.** Nenhum indicador de velocidade é mostrado sem o seu par de qualidade.
6. **Desligar a IA custa zero.** Subsistema de agentes inativo, sem impacto em rede, memória ou latência.

## 2. Problema e evidência

Criar e manter software é limitado pela memória de trabalho e pelo custo de reconstruir contexto, não pela velocidade de escrita.

| Indicador | Valor reportado | Fonte (conforme especificação de origem) |
|---|---|---|
| Tempo a ler/navegar código | 60–90 % | Literatura de interfaces espaciais |
| Tempo em navegação entre fragmentos | ~35 % | Idem |
| Tempo de comunicação/coordenação ignorado por DORA | ~47 % | Análise de indústria 2026 |
| Programadores que usam IA | 90 % (DORA 2025) | DORA 2025 |
| Efeito em programadores experientes (OSS) | −20 % de velocidade | METR |
| Refatoração/código movido 2021→2024 | ~25 % → <10 % | GitClear |
| Duplicação de blocos vs. 2022–23 | +81 % | GitClear (2026) |
| *Error-masking* | +47 % | GitClear (2026) |
| Confiança elevada no código gerado | 3,1 % | Stack Overflow 2025 |

**Ressalva.** Não existe ensaio empírico que prove que esta combinação de ferramentas reduz *churn*. O impacto deve ser medido continuamente via telemetria equilibrada (secção 10). Os números acima devem ser reverificados nas fontes primárias antes de serem citados externamente.

## 3. Visão geral em camadas

```
┌──────────────────────────────────────────────────────────────┐
│ Camada 1 · Interface dual (apps/pwa)                         │
│  Editor tradicional ◄──► Canvas espacial (bubbles) + Live Eval│
│  Viewport: WebGPU/WebGL2 · Foco: DOM virtualizado (a11y/IME) │
├──────────────────────────────────────────────────────────────┤
│ Camada 2 · Núcleo semântico (Rust → WASM, em Web Worker)     │
│  SumTree/Rope · Tree-sitter · SCIP · ast-grep · difftastic   │
├──────────────────────────────────────────────────────────────┤
│ Camada 3 · Persistência local-first                          │
│  OPFS (SyncAccessHandle) · Loro 1.0 (CRDT) · IndexedDB (fallback)│
├──────────────────────────────────────────────────────────────┤
│ Camada 4 · Segurança em profundidade                         │
│  BFF · CSP estrita · Trusted Types · COOP/COEP · Sandboxes   │
│  (origem separada · QuickJS-WASM · Wasmtime WASI P2)         │
└──────────────────────────────────────────────────────────────┘
        Opcional: apps/desktop-tauri (companion nativo)
```

## 4. Núcleo semântico (`crates/tessera-core`, `crates/tessera-intel`)

### 4.1 Texto, estado imutável

- **SumTree**: árvore B+ *copy-on-write*, segura para concorrência. Folhas guardam itens ordenados; cada nó interno agrega um `Summary` da subárvore.
- **Rope** = `SumTree<Chunk>`. Conversão entre *offsets* de bytes e linha/coluna em O(log N).
- A mesma primitiva unifica o estado do workspace: árvore de ficheiros, *git blame*, diagnósticos e histórico de sessões, todos com *snapshots* instantâneos.

**Unidades de offset.** O `Rope` usa **bytes UTF-8**; o JavaScript usa unidades UTF-16. O adaptador de editor (DOM virtualizado) converte entre ambos na fronteira do Worker. A camada WASM valida offsets (fora do texto ou a meio de um carácter) e devolve erro em vez de abortar o módulo.

### 4.2 Execução em Worker

Todo o motor (SumTree/Rope, Tree-sitter incremental, consultas semânticas) corre num **Web Worker dedicado** em Rust/WASM. O fio principal fica livre para interface.

## 5. Renderização dual desacoplada

| Elemento | Técnica | Motivo |
|---|---|---|
| Viewport panorâmico (dezenas de bubbles, ligações de fluxo, minimapa) | WebGPU com *fallback* WebGL2 | Fluidez de pan/zoom |
| Bubble/editor com foco de teclado | Adaptador DOM virtualizado sincronizado com o Rope | Leitores de ecrã, seleção nativa, IME móvel, correção ortográfica |

**Riscos identificados.** (a) Canvas puro dificulta acessibilidade e IME; (b) regressões do `cosmic-text` 0.14.x em Wayland com escalas ≠ `rems(1.25)`. Mitigação: renderização dual e *pinning* de versão em CI.

Referência de pilha gráfica (inspirada em GPUI/Zed): Taffy (layout), cosmic-text (modelação tipográfica), atlas de glifos em GPU, desenho instanciado, `accesskit` para acessibilidade.

## 6. Persistência local-first

### 6.1 Escolha do motor CRDT (ADR-002)

| Critério | Yjs | Automerge v2 | **Loro 1.0** |
|---|---|---|---|
| Ecossistema | Muito maduro (y-codemirror, y-monaco, …) | Médio (Automerge Repo) | Jovem, exige integradores próprios |
| Desempenho/memória | Bom; ~2× texto | Mais pesado (3–5×) | Lidera B4; documentos 2–5× menores |
| Time-travel | Exige snapshots externos | DAG estilo Git | Nativo |
| Movimentação em árvore | Sem `move` nativo | Sem foco | `LoroMovableTree` sem ciclos nem duplicados |
| Custo | — | Parse inicial lento | WASM > 1 MB |

**Decisão: arquitetura de responsabilidade particionada.**

- **Loro 1.0** é o motor primário para: árvore de ficheiros (`LoroMovableTree`), layout do canvas espacial e registo temporal de sessões.
- Limite conhecido: `LoroMovableList` move um elemento de cada vez, sem intervalos.
- Serialização e geração de *snapshots* correm **sempre no Worker**.
- O módulo WASM é carregado por *streaming* binário e guardado em *cache* pelo Service Worker (nunca embutido em base64, que acrescenta ~30 %).
- Interface `CrdtTextAdapter` permite acoplar `Y.Text` opcionalmente, para organizações que queiram reutilizar editores y-codemirror/y-monaco.

### 6.2 Armazenamento: OPFS (ADR-003)

- **OPFS** como camada primária, com `FileSystemSyncAccessHandle` (apenas em Worker) para I/O síncrono de alta cadência: índices SCIP, registos CRDT, árvores de código.
- Suporte: Chrome/Edge 86+, Firefox 111+, Safari 15.2+ (`getFile()` desde 15.4).
- **Fallback:** na Navegação Privada do Safari o OPFS não está disponível. O arranque deteta-o, ativa modo sobre **IndexedDB** e avisa explicitamente que a sessão é volátil.

## 7. Plataforma: PWA primeiro, Tauri v2 como companion (ADR-004)

| Parâmetro | PWA | Tauri v2 | Electron |
|---|---|---|---|
| Instalação | Sem instalador | ~1 a 4 MB | ~106 a 165 MB |
| Memória (Win11, 1 janela) | No navegador | ~142 MB | ~149 MB |
| Arranque a frio | Imediato (SW) | 0,3–0,8 s | 1,5–3,0 s |
| Fidelidade gráfica | Uniforme | Depende da WebView do SO | Alta |
| Alcance | Desktop e móvel | Win/macOS/Linux/Android/iOS | Só Desktop |

A poupança de RAM do Tauri em Windows é marginal (~5 %), porque a WebView2 usa Chromium; em Linux há risco com WebKitGTK. **Decisão:** a PWA é a plataforma principal e autossuficiente; o Tauri v2 é um *companion* opcional para quem precisa de compiladores locais, LSPs nativos ou Wasmtime local sem latência de rede, com IPC tipado e atualizações assinadas.

> Os números de tamanho/memória provêm de testes independentes de terceiros (incluindo amostras N=1). Revalidar com *benchmarks* próprios na Fase 4.

## 8. Interface espacial

Modo **integrado lado a lado** com o editor de separadores (lição do *Debugger Canvas*): o programador nunca é forçado a abandonar a leitura linear.

- **Bubble**: vista editável e leve de função, método, estrutura ou teste, com *breadcrumb* semântico (pacote/módulo/classe).
- **Bubble spacer**: espaçamento automático sem sobreposição; desloca vizinhas pela menor distância euclidiana quando uma função cresce; *reflow* sem corte horizontal.
- **Elisão vertical** para aumentar a densidade de funções visíveis.
- **Budding**: escrever código fora do âmbito léxico na base de uma bubble gera uma nova bubble ligada ao mesmo módulo/classe.
- **Typed holes** (inspirado em Hazel): lacunas não quebram a análise do módulo; o verificador mostra o tipo esperado e permite avaliação parcial.
- **Live Eval e watches** (inspirado em Light Table): resultados inline, incluindo saídas gráficas.
- **Cartões ADR/notas** ancorados junto às bubbles (estudo Synectic), persistidos no CRDT.
- **Depuração**: abre cada função da cadeia no canvas, com variáveis locais congeláveis em snapshots comparativos; *core dumps* Wasmtime e *replay* determinístico para testar correções sobre estados passados.

## 9. Inteligência semântica e Guardião Anti-Churn

| Ferramenta | Função |
|---|---|
| **SCIP** | Índice Protobuf com símbolos legíveis (pacote+versão). Alimenta «Ir para Definição», «Encontrar Referências» e navegação entre `.proto`/`.wit` e implementações, inclusive entre repositórios |
| **ast-grep** | Pesquisa, lint e reescrita estrutural com meta-variáveis (regras YAML) |
| **difftastic** | Diff sintático (>50 linguagens) para revisão com menos ruído de formatação |

**Guardião Anti-Churn** (conjunto de regras YAML nativo):

1. Deteção de `catch`/tratamento que silencia exceções (*error-masking*).
2. Deteção de assinaturas ou corpos duplicados contra o catálogo SCIP, antes de fundir código novo.
3. *Codemods* de refatoração com pré-visualização *dry-run*.

Ganhos reportados do SCIP face ao LSIF (Sourcegraph/Glean): índices ~8× menores e 3× mais rápidos na Glean; parte do ganho de CI de 10× deve-se também ao indexador.

## 10. Orquestração de IA e telemetria (DX Core 4)

Com IA ativa, o paradigma é **orquestração estrutural**:

1. O agente consulta o índice SCIP para reutilizar abstrações existentes.
2. A proposta é validada por Tree-sitter.
3. Passa pelas regras ast-grep anti-*error-masking*.
4. Chega à vista de revisão difftastic.
5. Efeitos secundários exigem aprovação HITL (ver SECURITY.md §6).

**Painel opcional (DX Core 4 + DX AI Measurement Framework)** — pares obrigatórios velocidade ↔ qualidade ↔ sinal qualitativo:

| Velocidade | Qualidade | Sinal qualitativo |
|---|---|---|
| Tempo de ciclo, frequência de entrega | Taxa de falha de alterações, *churn* a 14 dias | Carga cognitiva, satisfação |
| Linhas refatoradas/movidas | Linhas duplicadas, *error-masking*, cobertura de testes | Uso de IA cruzado com escalas breves |

## 11. Estrutura canónica do repositório

| Caminho | Responsabilidade | Tecnologia | Execução |
|---|---|---|---|
| `docs/` | ARCHITECTURE, SECURITY, ROADMAP, ADRs | Markdown | Git |
| `wit/` | Contratos WIT de capacidades | WASI P2 / WIT | Compilação/ligação |
| `crates/tessera-core/` | SumTree, Rope, snapshots, Loro, adaptador Y.Text | Rust | WASM (Worker) e nativo |
| `crates/tessera-intel/` | Tree-sitter, SCIP, regras ast-grep, difftastic | Rust | WASM (Worker) e CLI |
| `crates/tessera-sandbox/` | Wasmtime, políticas WIT, limites, épocas/fuel, core dumps | Rust | Servidor e companion |
| `apps/pwa/` | UI dual, Worker OPFS, QuickJS-WASM, `tessera-mcp-client` | TypeScript | Navegador |
| `apps/bff/` | Cliente OAuth confidencial, sessões, proxy Git/LLM/MCP | TS ou Rust | Servidor HTTPS |
| `apps/preview-gateway/` | Origem isolada para pré-visualização | Gateway estático | Origem não confiável |
| `apps/desktop-tauri/` | Wrapper nativo opcional | Tauri v2 | Desktop/móvel |

## 12. Modelo de dados e invariantes

| Entidade | Estrutura | Persistência | Invariantes |
|---|---|---|---|
| `WorkspaceGraph` | `node_id, parent_id, path_segment, metadata` | `LoroMovableTree` em OPFS (hoje: implementação provisória em JS, registo de operações em OPFS — [ADR-009](adr/0009-workspace-graph-arvore-movel.md)) | Sem ciclos nem duplicados; validação contra *path traversal* |
| `SpatialCanvas` | `SpatialBubble{bubble_id, symbol_scip_id, file_id, x, y, w, h, elision_state, adr_cards[]}` | `LoroMap`/`LoroMovableList` no Worker | Bubble spacer impede sobreposição |
| `TextDocument` | Rope + estado CRDT + marcadores de typed holes | OPFS + deltas binários via BFF | Snapshots imutáveis; time-travel e reversão granular humano/IA |
| `ScipIndexArtifact` | `scip.Index` (Document, Occurrence, SymbolInformation) | OPFS / memória | IDs determinísticos por versão; indexação sem escrever no código |
| `SandboxCapabilityPolicy` | `preopened_dirs[], allowed_hosts[], max_memory_pages, epoch_deadline_ms, fuel_budget` | `.wit` + política assinada | Negação por omissão; sem autoridade ambiente |
| `AuditPatchProposal` | `origin (humano\|ast-grep\|mcp-agent), ast_diff, lint_warnings[], scip_refs[], hitl_approved` | Sessão + registo local | Proíbe aplicação se houver novo error-masking ou sem HITL (agentes) |

## 13. Registo de decisões (ADRs)

| ID | Decisão | Estado |
|---|---|---|
| ADR-001 | Núcleo em Rust/WASM num Worker; SumTree/Rope | Aceite |
| ADR-002 | Loro 1.0 como CRDT primário + `CrdtTextAdapter` para Yjs | Aceite |
| ADR-003 | OPFS primário; IndexedDB como contingência | Aceite |
| ADR-004 | PWA principal; Tauri v2 como companion | Aceite |
| ADR-005 | Renderização dual (WebGPU + DOM virtualizado) | Aceite |
| ADR-006 | BFF obrigatório (RFC 10017) | Aceite |
| ADR-007 | Sandboxes em três níveis | Aceite |
| ADR-008 | Spatial como modo integrado, não substituto do editor | Aceite |

## 14. Riscos e questões em aberto

Ver [ROADMAP.md §6](./ROADMAP.md).
